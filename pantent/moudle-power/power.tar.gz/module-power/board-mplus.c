/* Copyright [2010-2019] <LeadCoreTech Corp>
**
** This software is licensed under the terms of the GNU General Public
** License version 2, as published by the Free Software Foundation, and
** may be copied, distributed, and modified under those terms.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** Copyright (c) 2010-2019 LeadCoreTech Corp.
**
** PURPOSE: comip machine.
**
** CHANGE HISTORY:
**
** Version  Date        Author      Description
** 1.0.0    2016-3-17    Y.W    created
**
*/
#include <mach/timer.h>
#include <mach/gpio.h>
#include <plat/mfp.h>
#include <plat/i2c.h>
#include <plat/cpu.h>
#include <plat/comip-pmic.h>
#include <plat/comip-backlight.h>
#include <plat/comip-thermal.h>
#include <plat/comip-battery.h>
#if defined(CONFIG_COMIP_LC1160)
#include <plat/lc1160.h>
#include <plat/lc1160-pmic.h>
#include <plat/lc1160_adc.h>
#include <plat/lc1160-pwm.h>
#endif
#include <plat/usb.h>
#if defined(CONFIG_SPI_COMIP) || defined(CONFIG_SPI_COMIP_MODULE)
#include <linux/spi/spi.h>
#include <plat/spi.h>
#include <mach/devices.h>
#endif

#if defined(CONFIG_FINGERPRINT_INC7183)
#include <plat/icn7000_spi.h>
#endif

#if defined(CONFIG_FINGERPRINT_CHIPONE)
#include <plat/fpsensor.h>
#endif

#if defined(CONFIG_SERIAL_SC16IS7X2) || defined(CONFIG_SERIAL_SC16IS7X2_MODULE)
#include <linux/sc16is7x2.h>
#endif

#if defined(CONFIG_TOUCHSCREEN_FT5X06)
#include <plat/ft5x06_ts.h>
#endif

#if defined(CONFIG_TOUCHSCREEN_S3402)
#include <plat/s3402_ts.h>
#endif


#ifdef CONFIG_LIGHT_PROXIMITY_STK3X1X
#include "plat/stk3x1x.h"
#endif

#ifdef CONFIG_SENSORS_LSM330
#include "plat/lsm330.h"
#endif
#ifdef CONFIG_BAT_ID_BQ2022A
#include <plat/bq2022a-batid.h>
#endif

#if defined(CONFIG_SENSORS_AK09911)
#include <plat/akm09911.h>
#endif

#ifdef CONFIG_LIGHT_PROXIMITY_LTR55XALS
#include <plat/ltr558als.h>
#endif
#ifdef CONFIG_SENSORS_INV_MPU6880
#include <linux/mpu.h>
#endif
#if defined(CONFIG_GPIO_PCA953X)
#include <linux/i2c/pca953x.h>
#endif
#if defined (CONFIG_SENSORS_IST8303)
#include <plat/ist8303.h>
#endif

#ifdef CONFIG_SENSORS_BMI055
#include <plat/bmi055.h>
#endif

#include "board-mplus.h"

#include "board-common.c"

#ifdef CONFIG_FM23_DSP
#include <linux/platform_data/fm23.h>
#endif

#ifdef CONFIG_ADC3001_CHIP
#include <linux/platform_data/adc3001.h>
#endif

#ifdef CONFIG_TYPE_C_DET_PI5USB30216A
#include <misc/pi5usb30216a.h>
#endif

#ifdef CONFIG_POWER_DAC_AD5321
#include <misc/ad5321.h>
#endif

#if defined(CONFIG_DTT_MODULES_SYSFS)
#include <plat/mplus_modules.h>
#endif

#include <linux/platform_data/Audio_Switch.h>

#ifdef CONFIG_LEDS_LM3642
#include <linux/platform_data/leds-lm3642.h>
#endif

#ifdef CONFIG_LEDS_LM3646
#include <linux/platform_data/leds-lm3646.h>
#endif

#ifdef CONFIG_VIBR_DRV2625
#include <plat/drv2625-vibrator.h>
#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI) || defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
#include <linux/aw9523.h>
#endif

#ifdef CONFIG_FAN_PWM
#include <linux/fan.h>
#endif
#include <plat/mplus-board-id.h>

#ifdef CONFIG_TOUCHSCREEN_CYPRESS_CYTTSP5
/* cyttsp */
#include <linux/cyttsp5_bus.h>
#include <linux/cyttsp5_core.h>
#include <linux/cyttsp5_btn.h>
#include <linux/cyttsp5_mt.h>
#include <linux/cyttsp5_proximity.h>
#include <linux/cyttsp5_platform.h>

#define CYTTSP5_USE_I2C 1

#ifdef CYTTSP5_USE_I2C
#define CYTTSP5_I2C_NAME "cyttsp5_i2c_adapter"
#define CYTTSP5_I2C_TCH_ADR 0x24
#define CYTTSP5_LDR_TCH_ADR 0x24
#define CYTTSP5_I2C_IRQ_GPIO mfp_to_gpio(CYTTSP5_INT_PIN)/* J6.9, C19, GPMC_AD14/GPIO_38 */
#define CYTTSP5_I2C_RST_GPIO mfp_to_gpio(CYTTSP5_RST_PIN)/* J6.10, D18, GPMC_AD13/GPIO_37 */
#endif

#define CYTTSP5_HID_DESC_REGISTER 1

#define CY_VKEYS_X 720
#define CY_VKEYS_Y 1280

#define CY_MAXX 480
#define CY_MAXY 800
#define CY_MINX 0
#define CY_MINY 0

#define CY_ABS_MIN_X CY_MINX
#define CY_ABS_MIN_Y CY_MINY
#define CY_ABS_MAX_X CY_MAXX
#define CY_ABS_MAX_Y CY_MAXY
#define CY_ABS_MIN_P 0
#define CY_ABS_MAX_P 255
#define CY_ABS_MIN_W 0
#define CY_ABS_MAX_W 255
#define CY_PROXIMITY_MIN_VAL    0
#define CY_PROXIMITY_MAX_VAL    1

#define CY_ABS_MIN_T 0

#define CY_ABS_MAX_T 15

#define CY_IGNORE_VALUE 0xFFFF

/* Button to keycode conversion */
static u16 cyttsp5_btn_keys[] = {
    /* use this table to map buttons to keycodes (see input.h) */
    KEY_HOMEPAGE,       /* 172 */ /* Previously was KEY_HOME (102) */
    /* New Android versions use KEY_HOMEPAGE */
    KEY_MENU,       /* 139 */
    KEY_BACK,       /* 158 */
    KEY_SEARCH,     /* 217 */
    KEY_VOLUMEDOWN,     /* 114 */
    KEY_VOLUMEUP,       /* 115 */
    KEY_CAMERA,     /* 212 */
    KEY_POWER       /* 116 */
};

static struct touch_settings cyttsp5_sett_btn_keys = {
    .data = (uint8_t *)&cyttsp5_btn_keys[0],
    .size = ARRAY_SIZE(cyttsp5_btn_keys),
    .tag = 0,
};

static int cyttsp5_xres(struct cyttsp5_core_platform_data *pdata, struct device *dev)
{
    int rc = 0;

    gpio_direction_output(CYTTSP5_I2C_RST_GPIO, 1);
    msleep(20);
    gpio_direction_output(CYTTSP5_I2C_RST_GPIO, 0);
    msleep(40);
    gpio_direction_output(CYTTSP5_I2C_RST_GPIO, 1);
    msleep(20);
    dev_info(dev,
             "%s: RESET CYTTSP gpio=%d r=%d\n", __func__,
             CYTTSP5_I2C_RST_GPIO, rc);
    return rc;
}

static int cyttsp5_init(struct cyttsp5_core_platform_data *pdata, int on,
                        struct device *dev)
{
    int rc = 0;

    if (on) {
        rc = gpio_request(CYTTSP5_I2C_RST_GPIO, NULL);
        if (rc < 0) {
            gpio_free(CYTTSP5_I2C_RST_GPIO);
            rc = gpio_request(CYTTSP5_I2C_RST_GPIO, NULL);
        }
        if (rc < 0) {
            dev_err(dev,
                    "%s: Fail request gpio=%d\n", __func__,
                    CYTTSP5_I2C_RST_GPIO);
        } else {
            rc = gpio_direction_output(CYTTSP5_I2C_RST_GPIO, 1);
            if (rc < 0) {
                pr_err("%s: Fail set output gpio=%d\n",
                       __func__, CYTTSP5_I2C_RST_GPIO);
                gpio_free(CYTTSP5_I2C_RST_GPIO);
            } else {
                rc = gpio_request(CYTTSP5_I2C_IRQ_GPIO, NULL);
                if (rc < 0) {
                    gpio_free(CYTTSP5_I2C_IRQ_GPIO);
                    rc = gpio_request(CYTTSP5_I2C_IRQ_GPIO,
                                      NULL);
                }
                if (rc < 0) {
                    dev_err(dev,
                            "%s: Fail request gpio=%d\n",
                            __func__, CYTTSP5_I2C_IRQ_GPIO);
                    gpio_free(CYTTSP5_I2C_RST_GPIO);
                } else {
                    gpio_direction_input(CYTTSP5_I2C_IRQ_GPIO);
                    printk("harris irq input mode\n");
                }
            }
        }
    } else {
        gpio_free(CYTTSP5_I2C_RST_GPIO);
        gpio_free(CYTTSP5_I2C_IRQ_GPIO);
    }

    printk("%s: INIT CYTTSP RST gpio=%d and IRQ gpio=%d r=%d\n",
           __func__, CYTTSP5_I2C_RST_GPIO, CYTTSP5_I2C_IRQ_GPIO, rc);

    return rc;
}

static int cyttsp5_wakeup(struct device *dev)
{
    int rc = 0;

    rc = gpio_direction_output(CYTTSP5_I2C_IRQ_GPIO, 0);
    if (rc < 0) {
        dev_err(dev,
                "%s: Fail set output gpio=%d\n",
                __func__, CYTTSP5_I2C_IRQ_GPIO);
    } else {
        udelay(2000);
        rc = gpio_direction_input(CYTTSP5_I2C_IRQ_GPIO);
        if (rc < 0) {
            dev_err(dev,
                    "%s: Fail set input gpio=%d\n",
                    __func__, CYTTSP5_I2C_IRQ_GPIO);
        }
    }

    dev_info(dev,
             "%s: WAKEUP CYTTSP gpio=%d r=%d\n", __func__,
             CYTTSP5_I2C_IRQ_GPIO, rc);
    return rc;
}

static int cyttsp5_sleep(struct device *dev)
{
    return 0;
}

static int cyttsp5_power(struct cyttsp5_core_platform_data *pdata, int on,
                         struct device *dev, atomic_t *ignore_irq)
{
    int rc = 0;

    rc = gpio_request(CYTTSP5_I2C_RST_GPIO, NULL);
    if (rc < 0) {
        gpio_free(CYTTSP5_I2C_RST_GPIO);
        rc = gpio_request(CYTTSP5_I2C_RST_GPIO, NULL);
    }
    if (rc < 0) {
        printk("%s harris request gpio failed\n", __func__);
    }

    printk("%s harris entry onoff=%d\n", __func__, on);
    if (on) {
        gpio_direction_output(CYTTSP5_I2C_RST_GPIO, 0);
        msleep(10);
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN_IO, 0, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN, 0, PMIC_POWER_VOLTAGE_ENABLE);
        msleep(10);
        //comip_mfp_config_array(comip_mfp_cfg_i2c_2, ARRAY_SIZE(comip_mfp_cfg_i2c_2));
        msleep(10);
        gpio_direction_output(CYTTSP5_I2C_RST_GPIO, 1);
        return cyttsp5_wakeup(dev);
    } else {
        gpio_direction_output(CYTTSP5_I2C_RST_GPIO, 0);
        msleep(2);
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN_IO, 0, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN, 0, PMIC_POWER_VOLTAGE_DISABLE);
        gpio_direction_input(CYTTSP5_I2C_RST_GPIO);
        //ts_set_i2c_to_gpio();
    }

    return cyttsp5_sleep(dev);
}

int cyttsp5_irq_stat(struct cyttsp5_core_platform_data *pdata,
                     struct device *dev)
{
    return gpio_get_value(pdata->irq_gpio);
}

static struct cyttsp5_core_platform_data _cyttsp5_core_platform_data = {
    .irq_gpio = CYTTSP5_INT_PIN,
    .rst_gpio = CYTTSP5_RST_PIN,
    .hid_desc_register = CYTTSP5_HID_DESC_REGISTER,
    .xres = cyttsp5_xres,
    .init = cyttsp5_init,
    //.power = cyttsp5_power,
    .irq_stat = cyttsp5_irq_stat,
    .sett = {
        NULL,   /* Reserved */
        NULL,   /* Command Registers */
        NULL,   /* Touch Report */
        NULL,   /* Cypress Data Record */
        NULL,   /* Test Record */
        NULL,   /* Panel Configuration Record */
        NULL,   /* &cyttsp5_sett_param_regs, */
        NULL,   /* &cyttsp5_sett_param_size, */
        NULL,   /* Reserved */
        NULL,   /* Reserved */
        NULL,   /* Operational Configuration Record */
        NULL,  /* &cyttsp5_sett_ddata,   Design Data Record */
        NULL,  /* &cyttsp5_sett_mdata,  Manufacturing Data Record */
        NULL,   /* Config and Test Registers */
        &cyttsp5_sett_btn_keys, /* button-to-keycode table */
    },
    .loader_pdata = &_cyttsp5_loader_platform_data,
    .flags = CY_CORE_FLAG_WAKE_ON_GESTURE,
};

static struct cyttsp5_core_info cyttsp5_core_info __initdata = {
    .name = CYTTSP5_CORE_NAME,
    .id = "main_ttsp_core",
    .adap_id = CYTTSP5_I2C_NAME,
    .platform_data = &_cyttsp5_core_platform_data,
};

static const uint16_t cyttsp5_abs[] = {
    ABS_MT_POSITION_X, CY_ABS_MIN_X, CY_ABS_MAX_X, 0, 0,
    ABS_MT_POSITION_Y, CY_ABS_MIN_Y, CY_ABS_MAX_Y, 0, 0,
    ABS_MT_PRESSURE, CY_ABS_MIN_P, CY_ABS_MAX_P, 0, 0,
    CY_IGNORE_VALUE, CY_ABS_MIN_W, CY_ABS_MAX_W, 0, 0,
    ABS_MT_TRACKING_ID, CY_ABS_MIN_T, CY_ABS_MAX_T, 0, 0,
    ABS_MT_TOUCH_MAJOR, 0, 255, 0, 0,
    ABS_MT_TOUCH_MINOR, 0, 255, 0, 0,
    ABS_MT_ORIENTATION, -128, 127, 0, 0,
    ABS_MT_TOOL_TYPE, 0, MT_TOOL_MAX, 0, 0,
};

struct touch_framework cyttsp5_framework = {
    .abs = (uint16_t *)&cyttsp5_abs[0],
    .size = ARRAY_SIZE(cyttsp5_abs),
    .enable_vkeys = 0,
};

static struct cyttsp5_mt_platform_data _cyttsp5_mt_platform_data = {
    .frmwrk = &cyttsp5_framework,
    .flags = CY_MT_FLAG_INV_X | CY_MT_FLAG_INV_Y,
    .inp_dev_name = CYTTSP5_MT_NAME,
    .vkeys_x = CY_VKEYS_X,
    .vkeys_y = CY_VKEYS_Y,
};

static struct cyttsp5_device_info cyttsp5_mt_info __initdata = {
    .name = CYTTSP5_MT_NAME,
    .core_id = "main_ttsp_core",
    .platform_data = &_cyttsp5_mt_platform_data,
};

static struct cyttsp5_btn_platform_data _cyttsp5_btn_platform_data = {
    .inp_dev_name = CYTTSP5_BTN_NAME,
};

static struct cyttsp5_device_info cyttsp5_btn_info __initdata = {
    .name = CYTTSP5_BTN_NAME,
    .core_id = "main_ttsp_core",
    .platform_data = &_cyttsp5_btn_platform_data,
};

static const uint16_t cyttsp5_prox_abs[] = {
    ABS_DISTANCE, CY_PROXIMITY_MIN_VAL, CY_PROXIMITY_MAX_VAL, 0, 0,
};

struct touch_framework cyttsp5_prox_framework = {
    .abs = (uint16_t *)&cyttsp5_prox_abs[0],
    .size = ARRAY_SIZE(cyttsp5_prox_abs),
};

static struct cyttsp5_proximity_platform_data
        _cyttsp5_proximity_platform_data = {
    .frmwrk = &cyttsp5_prox_framework,
    .inp_dev_name = CYTTSP5_PROXIMITY_NAME,
};

struct cyttsp5_device_info cyttsp5_proximity_info __initdata = {
    .name = CYTTSP5_PROXIMITY_NAME,
    .core_id = "main_ttsp_core",
    .platform_data = &_cyttsp5_proximity_platform_data,
};
#endif


extern struct Audio_switch_platform_data audio_switch_gpio;

int hardware_board_id;
int get_board_id()
{
    return hardware_board_id;
}
int board_num;

#if defined(CONFIG_SERIAL_SC16IS7X2) || defined(CONFIG_SERIAL_SC16IS7X2_MODULE)
static struct sc16is7x2_platform_data sc16is7x2_pdata = {
    .uartclk = 1843200, //3072000,//XTAL1 source clock
    .uart_base = 0,
    .gpio_base = 0, //GPIO func related, we do NOT care about it
    .label = NULL, //GPIO func related, we do NOT care about it
    .names = NULL, //GPIO func related, we do NOT care about it
    .gpio_for_irq = SPI2UART_INT,
    .gpio_for_reset = SPI2UART_RESET,
    .gpio_for_xtal1_1p8m_en = SPI2UART_XTAL1_1P8M_EN,
    //.gpio_for_shift_bt_en = SPI2UART_VOL_SHIFT_4_BT_EN,
    .gpio_for_shift_spi_en = SPI2UART_VOL_SHIFT_4_SPI_EN,
};
#endif


#if defined(CONFIG_FINGERPRINT_INC7183)
static struct icn7000_platform_data icn7000_info = {
    .irq_gpio       = MFP_PIN_GPIO(107),  //evb02: 162,220, evb03: 104,105
    .reset_gpio     = MFP_PIN_GPIO(104),  // gpio pins just for test , depend hardware connect
//    .cs_gpio        = MFP_PIN_GPIO(217),
    .force_hwid = 0,
    .external_supply_mv = 0,
    .txout_boost = 1,
    .use_regulator_for_bezel = 0,
    .without_bezel = 0
};
#endif


#if defined(CONFIG_FINGERPRINT_CHIPONE)
static struct fpsensor_platform_data chipone_4305_info = {
    .irq_gpio = MFP_PIN_GPIO(107),
    .reset_gpio =  MFP_PIN_GPIO(104),
//    .cs_gpio = MFP_PIN_GPIO(222),
    .external_supply_mv = 0,
    .txout_boost = 1,
    .force_hwid = 0,
    .use_regulator_for_bezel = 0,
    .without_bezel = 0,
};
#endif


#if defined(CONFIG_SPI_COMIP) || defined(CONFIG_SPI_COMIP_MODULE)

static struct spi_board_info comip_spi0_board_info[] = {
#if defined(CONFIG_MMC_SPI)
    {
        .modalias   = "mmc_spi",// TF card
        .max_speed_hz   = 8000000,
        .bus_num    = 0,
        .chip_select    = 0,
        .mode = SPI_MODE_0,
    },
#endif
};
static int spi0_cs_state(int chipselect, int level)
{
    if (chipselect == 0) {
        comip_mfp_config(MFP_PIN_GPIO(160), MFP_PIN_MODE_GPIO);
        gpio_request(mfp_to_gpio(MFP_PIN_GPIO(160)), "SPI0_TF_CS");
        gpio_direction_output(mfp_to_gpio(MFP_PIN_GPIO(160)), level);
//       mdelay(50);
        gpio_free(mfp_to_gpio(MFP_PIN_GPIO(160)));

        return 0;
    } else {
        if (chipselect == 1) {

        }
    }
    return 0;
}

//this array contains the device info of all devices on all spi controllers
static struct spi_board_info comip_spi1_board_info[] = {

#if defined(CONFIG_SERIAL_SC16IS7X2) || defined(CONFIG_SERIAL_SC16IS7X2_MODULE)
    {
        .modalias = "sc16is7x2",
        .platform_data = &sc16is7x2_pdata,
        .controller_data = NULL,
        .irq = 0,
        .max_speed_hz = 9000000,
        .bus_num = 1, //bus_num = 1 means this device connected to spi1
        .chip_select = 0, //the first device on spi1
        .mode = SPI_MODE_0,
    },
#endif

#if defined(CONFIG_FINGERPRINT_INC7183)
    {
        .modalias   = ICN7000_DEV_NAME2,//ICN7000_DEV_NAME
        .max_speed_hz   = 10000000,
        .bus_num    = 1,
        .chip_select    = 1,
//        .mode = SPI_MODE_0,
        .platform_data = &icn7000_info,
    },
#endif

#if defined(CONFIG_FINGERPRINT_CHIPONE)
    {
        .modalias       = "fpsensor",
        .bus_num        = 1,
        .chip_select        = 0,
        .max_speed_hz       = 8000000,
        .mode           = SPI_MODE_0,
        .platform_data = &chipone_4305_info,
    }
#endif
};

static int spi1_cs_state(int chipselect, int level)
{
    int ret = -1;

    if (0 == chipselect) { //device1 on spi1
        // gpio_direction_output(GPIO_xxx, level);
        comip_mfp_config(MFP_PIN_GPIO(222), MFP_PIN_MODE_GPIO);
        gpio_request(mfp_to_gpio(MFP_PIN_GPIO(222)), "SPI0_finger_CS");
        gpio_direction_output(mfp_to_gpio(MFP_PIN_GPIO(222)), level);
        //  mdelay(50);
        gpio_free(mfp_to_gpio(MFP_PIN_GPIO(222)));
    } else if (1 == chipselect) { //device0 on spi1
    }
    return 0;
}

static struct comip_spi_platform_data comip_spi0_info = {
    .num_chipselect = 1,
    .cs_state = spi0_cs_state,
    .protocol = 0,
};

static struct comip_spi_platform_data comip_spi1_info = {
    .num_chipselect = 1,
    .cs_state = spi1_cs_state,
    .protocol = 0,
};

static struct comip_spi_platform_data comip_spi2_info = {
    .num_chipselect = 0,
    .cs_state = NULL, //= spi2_cs_state,
    .protocol = 0, //use SPI protocol
};

static void __init comip_init_spi(void)
{
    comip_set_spi0_info(&comip_spi0_info);
    comip_set_spi1_info(&comip_spi1_info);
    comip_set_spi2_info(&comip_spi2_info);

    spi_register_board_info(comip_spi0_board_info, ARRAY_SIZE(comip_spi0_board_info));
    spi_register_board_info(comip_spi1_board_info, ARRAY_SIZE(comip_spi1_board_info));
}
#endif

#if defined(CONFIG_LC1132_MONITOR_BATTERY) || defined(CONFIG_LC1160_MONITOR_BATTERY)
static int batt_table[] = {
    /* adc code for temperature in degree C */
    2466, 2447, 2428, 2409, 2388, 2367, 2345, 2322, 2299, 2275,/* -20 ,-11 */
    2250, 2224, 2198, 2171, 2144, 2115, 2086, 2057, 2027, 1996,/* -10 ,-1 */
    1965, 1934, 1902, 1869, 1836, 1803, 1770, 1736, 1702, 1668,/* 00 - 09 */
    1634, 1599, 1565, 1531, 1496, 1462, 1428, 1394, 1360, 1327, /* 10 - 19 */
    1294, 1261, 1228, 1196, 1164, 1133, 1102, 1072, 1042, 1012,  /* 20 - 29 */
    983, 955, 927, 900, 873, 847, 822, 797, 773, 749,/* 30 - 39 */
    726, 703, 681, 660, 639, 619, 599, 580, 562, 544, /* 40 - 49 */
    526, 509, 493, 477, 461, 446, 432, 418, 404, 391, /* 50 - 59 */
    379, 366, 354, 343, 332, 321, 311, 300, 291, 281,/* 60 - 69 */
    272,/* 70 */
};
struct monitor_battery_platform_data bci_data = {
    .battery_tmp_tbl    = batt_table,
    .tblsize = ARRAY_SIZE(batt_table),
    .monitoring_interval    = 20,
    .max_charger_voltagemV  = 4200,//change CV to 4350 when use 4.35V battery
    .termination_currentmA  = 150,
    .usb_battery_currentmA  = 500,
    .ac_battery_currentmA   = 700,
    .rechg_voltagemV = 100,
    .temp_low_threshold = -10,/*bat limit charging temperature in degree C */
    .temp_zero_threshold = 0,
    .temp_cool_threshold = 10,
    .temp_warm_threshold = 45,
    .temp_high_threshold = 60,
    .ac_charge_int = 228,    // charge status gpio
    .jack_charge_int = 226,  // charge status gpio
    .aerial_charge_int = 229,// charge status gpio
    .sub_bat_sw = 133,       // sub baterry voltage  temperature switch gpio
    .backup_supply_int = 129,// sub power supply status gpio
};

static struct platform_device monitor_battery_dev = {
    .name = "monitor_battery",
    .id   = 0x00,
    .dev  = {
        .platform_data = &bci_data,
    }
};

static struct platform_device monitor_battery_dev_sub = {
    .name = "monitor_battery",
    .id   = 0x01,
    .dev  = {
        .platform_data = &bci_data,
    }
};
#endif

#if defined(CONFIG_LC1132_ADC) || defined(CONFIG_LC1160_ADC)
struct pmic_adc_platform_data lc_adc = {
    .irq_line = -1,
    .features = 0,
};

static struct platform_device adc_dev = {
    .name = "lc11xx_adc",
    .id = -1,
    .dev = {
        .platform_data = &lc_adc,
    }
};
#endif

#if defined(CONFIG_BATTERY_MAX17058) || defined(CONFIG_BATTERY_BQ27421) || defined(CONFIG_CW201X_BATTERY)
static int batt_temp_table[] = {
    /* adc code for temperature in degree C */
    2466, 2447, 2428, 2409, 2388, 2367, 2345, 2322, 2299, 2275,/* -20 ,-11 */
    2250, 2224, 2198, 2171, 2144, 2115, 2086, 2057, 2027, 1996,/* -10 ,-1 */
    1965, 1934, 1902, 1869, 1836, 1803, 1770, 1736, 1702, 1668,/* 00 - 09 */
    1634, 1599, 1565, 1531, 1496, 1462, 1428, 1394, 1360, 1327, /* 10 - 19 */
    1294, 1261, 1228, 1196, 1164, 1133, 1102, 1072, 1042, 1012,  /* 20 - 29 */
    983, 955, 927, 900, 873, 847, 822, 797, 773, 749,/* 30 - 39 */
    726, 703, 681, 660, 639, 619, 599, 580, 562, 544, /* 40 - 49 */
    526, 509, 493, 477, 461, 446, 432, 418, 404, 391, /* 50 - 59 */
    379, 366, 354, 343, 332, 321, 311, 300, 291, 281,/* 60 - 69 */
    272,/* 70 */
};
/*max17058 fuel gauge model data table*/
/*
* NOTE:  don't change this table without updating the
*  max1705_battery.c defines for battery_id about data_baseaddr
* so they continue to match the order in this table.
*/
static int fg_batt_model_table[64 * 7] = {
    /*default battery (data_baseaddr = 0)*/
    0xAE, 0xF0, 0xB7, 0x70, 0xB8, 0x80, 0xB9, 0xE0,
    0xBB, 0x70, 0xBC, 0x50, 0xBD, 0x30, 0xBE, 0x60,
    0xBF, 0xB0, 0xBF, 0xD0, 0xC0, 0xB0, 0xC3, 0xC0,
    0xC9, 0x90, 0xCF, 0xE0, 0xD4, 0x60, 0xD6, 0x50,
    0x04, 0x00, 0x2F, 0x60, 0x22, 0x20, 0x2A, 0x00,
    0x38, 0x00, 0x36, 0x00, 0x30, 0xD0, 0x27, 0xF0,
    0x65, 0xC0, 0x0B, 0xF0, 0x1C, 0xE0, 0x0F, 0xF0,
    0x0F, 0x30, 0x12, 0x60, 0x07, 0x30, 0x07, 0x30,
    /*GUANGYU (data_baseaddr = 64)*/
    0xAE, 0xF0, 0xB7, 0x70, 0xB8, 0x80, 0xB9, 0xE0,
    0xBB, 0x70, 0xBC, 0x50, 0xBD, 0x30, 0xBE, 0x60,
    0xBF, 0xB0, 0xBF, 0xD0, 0xC0, 0xB0, 0xC3, 0xC0,
    0xC9, 0x90, 0xCF, 0xE0, 0xD4, 0x60, 0xD6, 0x50,
    0x04, 0x00, 0x2F, 0x60, 0x22, 0x20, 0x2A, 0x00,
    0x38, 0x00, 0x36, 0x00, 0x30, 0xD0, 0x27, 0xF0,
    0x65, 0xC0, 0x0B, 0xF0, 0x1C, 0xE0, 0x0F, 0xF0,
    0x0F, 0x30, 0x12, 0x60, 0x07, 0x30, 0x07, 0x30,
    /*ATL XINWANGDA (data_baseaddr = 128)*/
    0xA9, 0x90, 0xB4, 0x50, 0xB7, 0x10, 0xB8, 0x60,
    0xB8, 0xC0, 0xBB, 0x30, 0xBB, 0xD0, 0xBC, 0x80,
    0xBD, 0x30, 0xBE, 0xD0, 0xC0, 0x90, 0xC3, 0xD0,
    0xC7, 0x10, 0xCD, 0x10, 0xD1, 0xE0, 0xD6, 0x80,
    0x02, 0x10, 0x05, 0x10, 0x11, 0x50, 0x71, 0x60,
    0x16, 0x10, 0x29, 0xD0, 0x44, 0x90, 0x4C, 0xF0,
    0x31, 0xF0, 0x26, 0xD0, 0x15, 0xF0, 0x12, 0xF0,
    0x11, 0xF0, 0x0E, 0x10, 0x0D, 0x20, 0x0D, 0x20,
    /*DESAI (data_baseaddr = 192)*/
    0xA9, 0xF0, 0xB6, 0x40, 0xB7, 0x40, 0xB8, 0x20,
    0xBA, 0xD0, 0xBB, 0x20, 0xBC, 0x50, 0xBC, 0xC0,
    0xBE, 0x10, 0xBF, 0x60, 0xC2, 0xD0, 0xC5, 0xB0,
    0xC9, 0x30, 0xCD, 0xA0, 0xD1, 0xA0, 0xD7, 0x50,
    0x00, 0x90, 0x32, 0x00, 0x39, 0x00, 0x12, 0xE0,
    0x50, 0xE0, 0x27, 0x20, 0x77, 0x30, 0x20, 0xA0,
    0x3A, 0xD0, 0x12, 0xF0, 0x15, 0xF0, 0x11, 0xE0,
    0x11, 0xE0, 0x0D, 0xF0, 0x0D, 0x20, 0x0D, 0x20,
    /*FOR CW201:GUANGYU (data_baseaddr =256)*/
    0x16, 0xF9, 0x66, 0x67, 0x63, 0x61, 0x5F, 0x4C,
    0x7F, 0x4E, 0x4B, 0x5D, 0x5A, 0x46, 0x3F, 0x33,
    0x2D, 0x26, 0x22, 0x21, 0x2C, 0x32, 0x40, 0x4B,
    0x1E, 0x57, 0x0B, 0x85, 0x33, 0x53, 0x78, 0x8B,
    0x9E, 0x99, 0x96, 0x98, 0x41, 0x1B, 0x45, 0x3A,
    0x17, 0x3D, 0x52, 0x87, 0x8F, 0x91, 0x94, 0x52,
    0x82, 0x8C, 0x92, 0x96, 0x00, 0x9B, 0x93, 0xCB,
    0x2F, 0x7D, 0x72, 0xA5, 0xB5, 0xC1, 0x95, 0x21,
    /*FOR CW201:DESAI (data_baseaddr =320)*/
    0x17, 0x63, 0x6A, 0x68, 0x6A, 0x65, 0x63, 0x60,
    0x5C, 0x5D, 0x54, 0x55, 0x5B, 0x54, 0x46, 0x3E,
    0x34, 0x2B, 0x24, 0x1D, 0x1E, 0x3B, 0x4C, 0x55,
    0x16, 0x44, 0x0B, 0x85, 0x2E, 0x4E, 0x53, 0x5C,
    0x65, 0x5F, 0x5E, 0x61, 0x3D, 0x1A, 0x70, 0x38,
    0x0C, 0x45, 0x52, 0x87, 0x8F, 0x91, 0x94, 0x52,
    0x82, 0x8C, 0x92, 0x96, 0x79, 0x98, 0xCF, 0xCB,
    0x2F, 0x7D, 0x72, 0xA5, 0xB5, 0xC1, 0x95, 0x31,
    /*FOR CW201:XINWANGDA (data_baseaddr =384)*/
    0x17, 0x5C, 0x6C, 0x66, 0x6B, 0x64, 0x63, 0x61,
    0x5D, 0x5B, 0x59, 0x53, 0x53, 0x4E, 0x45, 0x41,
    0x34, 0x31, 0x28, 0x27, 0x2E, 0x3E, 0x49, 0x53,
    0x27, 0x5D, 0x0B, 0x85, 0x44, 0x68, 0x5B, 0x67,
    0x6D, 0x63, 0x5F, 0x61, 0x40, 0x1B, 0x83, 0x2A,
    0x14, 0x46, 0x52, 0x87, 0x8F, 0x91, 0x94, 0x52,
    0x82, 0x8C, 0x92, 0x96, 0x6E, 0x96, 0xCE, 0xCB,
    0x2F, 0x7D, 0x72, 0xA5, 0xB5, 0xC1, 0x95, 0x29,
};

struct comip_fuelgauge_info fg_data = {
    .battery_tmp_tbl    = batt_temp_table,
    .tmptblsize = ARRAY_SIZE(batt_temp_table),
    .fg_model_tbl = fg_batt_model_table,
    .fgtblsize = ARRAY_SIZE(fg_batt_model_table),
};
#endif

#ifdef CONFIG_CHARGER_BQ24158
struct extern_charger_platform_data exchg_data = {
    .max_charger_currentmA  = 1250,
    .max_charger_voltagemV  = 4350,
    .termination_currentmA  = 100,
    .dpm_voltagemV          = 4360,
    .usb_cin_limit_currentmA = 500,
    .usb_battery_currentmA  = 550,
    .ac_cin_limit_currentmA = 1050,
    .ac_battery_currentmA   = 1050,
    .feature = 1,
};
#endif

#ifdef CONFIG_CHARGER_BQ24161
struct extern_charger_platform_data exchg_data_bq24161 = {
    .max_charge_currentmA   = 2500,
    .max_charge_voltagemV   = 4350,
    .term_currentmA         = 100,
    .dpm_voltagemV          = 4360,
    .usb_pc_current_limitmA = 1500,
    .usb_pc_charge_currentmA = 550,
    .usb_ac_current_limitmA = 2500,
    .usb_ac_charge_currentmA = 2000,
    .dcin_current_limitmA   = 2500,
    .dcin_charge_currentmA  = 2000,
    .feature = 1,
};
#endif

#if defined(CONFIG_GPIO_PCA953X)
static void comip_expand_gpio_init(void)
{
    int ret = 0;

    ret = gpio_request(TCA6424A_0_P01, "JLTE_VBUS_EN");
    if (ret) {
        printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P01\n", __FILE__, __LINE__, __func__);
    } else {
        gpio_direction_output(TCA6424A_0_P01, 0);
    }

    ret = gpio_request(TCA6424A_0_P04, "V_SHIFT_EN");
    if (ret) {
        printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P04\n", __FILE__, __LINE__, __func__);
    } else {
        gpio_direction_output(TCA6424A_0_P04, 0);
    }

    ret = gpio_request(TCA6424A_0_P12, "DBB2BM_1V8_EN");
    if (ret) {
        printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P12\n", __FILE__, __LINE__, __func__);
    } else {
        gpio_direction_output(TCA6424A_0_P12, 0);
    }

    ret = gpio_request(TCA6424A_0_P13, "DBB2BM_3V3_EN");
    if (ret) {
        printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P13\n", __FILE__, __LINE__, __func__);
    } else {
        gpio_direction_output(TCA6424A_0_P13, 0);
    }

    ret = gpio_request(TCA6424A_0_P23, "USB2SDIO_3V3_EN");
    if (ret) {
        printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P23\n", __FILE__, __LINE__, __func__);
    } else {
        gpio_direction_output(TCA6424A_0_P23, 0);
    }
}
#endif

#ifdef CONFIG_CHARGER_BQ24773
struct extern_charger_platform_data exchg_data_bq24773 = {
    .id = 0,
    .max_charge_currentmA   = 1980,
    .max_charge_voltagemV   = 8400,
    .current_limitmA        = 4992,
    .min_system_voltagemV   = 6144,
#if defined(CONFIG_GPIO_PCA953X)
    .expand_gpio_init       = comip_expand_gpio_init,
#endif

};
#endif

#if defined(CONFIG_BACKLIGHT_COMIP)
static void comip_lcd_bl_control(int onoff)
{
    if (onoff) {
        pmic_voltage_set(PMIC_POWER_LED, PMIC_LED_LCD, PMIC_POWER_VOLTAGE_ENABLE);
    } else {
        pmic_voltage_set(PMIC_POWER_LED, PMIC_LED_LCD, PMIC_POWER_VOLTAGE_DISABLE);
    }
}

static void comip_key_bl_control(int onoff)
{
    if (onoff) {
        pmic_voltage_set(PMIC_POWER_LED, PMIC_LED_KEYPAD, PMIC_POWER_VOLTAGE_ENABLE);
    } else {
        pmic_voltage_set(PMIC_POWER_LED, PMIC_LED_KEYPAD, PMIC_POWER_VOLTAGE_DISABLE);
    }
}

#if (defined (CONFIG_LCD_BOE_RM67120) || defined (CONFIG_LCD_BOE_RM67160))
static struct comip_backlight_platform_data comip_backlight_data = {
    .ctrl_type = CTRL_LCDC,
    .gpio_en = -1,
    .pwm_en = 1,
    .pwm_id = 0,
    .pwm_clk = 32500,  //32.5KhZ
    .bl_control = comip_lcd_bl_control,
    .key_bl_control = comip_key_bl_control,
};
#endif

#if defined (CONFIG_LCD_GVO_GDS8102)
static void gov_gds8102_bl_control(int onoff)
{
    int ret = 0;
    if (onoff) {
        ret = gpio_request(TCA6424A_0_P10, "OLED_POS_EN");
        if (ret) {
            printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P10\n", __FILE__, __LINE__, __func__);
            return;
        }
        ret = gpio_request(TCA6424A_0_P11, "OLED_NEG_EN");
        if (ret) {
            printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P11\n", __FILE__, __LINE__, __func__);
            return;
        }
        gpio_direction_output(TCA6424A_0_P10, 1);
        gpio_direction_output(TCA6424A_0_P11, 1);
        gpio_free(TCA6424A_0_P10);
        gpio_free(TCA6424A_0_P11);
        printk("[%s_INFO][%04d] [%s] backlight power ic enabled\n", __FILE__, __LINE__, __func__);
    } else {
        ret = gpio_request(TCA6424A_0_P10, "OLED_POS_EN");
        if (ret) {
            printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P10\n", __FILE__, __LINE__, __func__);
            return;
        }
        ret = gpio_request(TCA6424A_0_P11, "OLED_NEG_EN");
        if (ret) {
            printk("[%s_INFO][%04d] [%s] gpio request failed: TCA6424A_0_P11\n", __FILE__, __LINE__, __func__);
            return;
        }
        gpio_direction_output(TCA6424A_0_P10, 0);
        gpio_direction_output(TCA6424A_0_P11, 0);
        gpio_free(TCA6424A_0_P10);
        gpio_free(TCA6424A_0_P11);
        printk("[%s_INFO][%04d] [%s] backlight power ic disabled\n", __FILE__, __LINE__, __func__);
    }
}

static struct comip_backlight_platform_data comip_backlight_data = {
    .ctrl_type = CTRL_LCDC,
    .gpio_en = -1,
    .pwm_en = 1,
    .pwm_id = 0,
    .pwm_clk = 32500,  //32.5KhZ
    .bl_control = gov_gds8102_bl_control,
    .key_bl_control = comip_key_bl_control,
};
#endif

#if defined (CONFIG_LCD_TS_TS8080Y)
static struct comip_backlight_platform_data comip_backlight_data = {
    .ctrl_type = CTRL_PWM,
    .gpio_en = -1,
    .pwm_en = 1,
    .pwm_id = 0,
    .pwm_clk = 32500,  //32.5KhZ
    .bl_control = comip_lcd_bl_control,
    .key_bl_control = comip_key_bl_control,
};
#endif

static struct platform_device comip_backlight_device = {
    .name = "comip-backlight",
    .id = -1,
    .dev = {
        .platform_data = &comip_backlight_data,
    }
};
#endif

#if defined(CONFIG_FAN_PWM)
static struct fan_platform_data fan_pdata = {
    .ctrl_type = CTRL_PWM,
    .gpio_tach = DBB2FAN_TACH_PIN,
    .gpio_en = -1,
    .pwm_en = 1,
    .pwm_id = 0,
    .pwm_clk = 32500,  //32.5KhZ
    .pwm_ocpy_min = 10,
};

static struct platform_device fan_device = {
    .name = "fan",
    .id = -1,
    .dev = {
        .platform_data = &fan_pdata,
    }
};
#endif

#if defined(CONFIG_LC1160_PWM)
static void lc1160_pwm_device_init(int id)
{
}

static struct lc1160_pwm_platform_data lc1160_pwm_info = {
    .dev_init = lc1160_pwm_device_init,
};

static struct platform_device lc1160_pwm_device = {
    .name = "lc1160-pwm",
    .id = -1,
    .dev = {
        .platform_data = &lc1160_pwm_info,
    }
};
#endif

#if defined(CONFIG_THERMAL_COMIP)
static struct sample_rate_member sample_table[] = {
    { -100, 10, SAMPLE_RATE_SLOW, THERMAL_NORMAL},
    {10, 70, SAMPLE_RATE_NORMAL, THERMAL_NORMAL},
    {70, 73, SAMPLE_RATE_FAST, THERMAL_WARM},
    {73, 76, SAMPLE_RATE_FAST, THERMAL_HOT},
    {76, 78, SAMPLE_RATE_EMERGENT, THERMAL_TORRID},
    {78, 80, SAMPLE_RATE_EMERGENT, THERMAL_CRITICAL},
    {80, 83, SAMPLE_RATE_EMERGENT, THERMAL_FATAL},
    {83, 100, SAMPLE_RATE_EMERGENT, THERMAL_ERROR},
    {101, 1000, SAMPLE_RATE_ERROR, THERMAL_END},
};

static struct comip_thermal_platform_data comip_thermal_info = {
    .channel = DBB_TEMP_ADC_CHNL,
    .sample_table_size = ARRAY_SIZE(sample_table),
    .sample_table = sample_table,
};

static struct platform_device comip_thermal_device = {
    .name = "comip-thermal",
    .id = -1,
    .dev = {
        .platform_data = &comip_thermal_info,
    }
};
#endif

int hardware_get_board_info(void)
{
    int value1 , value2;
    int retval;
    int device_id;

    comip_mfp_config(HARDWARE_DEVICE_PIN, MFP_PIN_MODE_GPIO);
    comip_mfp_config_pull(HARDWARE_DEVICE_PIN, MFP_PULL_UP);
    comip_mfp_gpio_config(HARDWARE_DEVICE_PIN, MFP_GPIO_INPUT, 0);

    retval = gpio_request(HARDWARE_DEVICE_PIN , "hw_device_pin");
    if (retval) {
        pr_err("%s: Failed to get hardware version high gpio Code: %d.",
               __func__, retval);
    }
    device_id = gpio_get_value_cansleep(HARDWARE_DEVICE_PIN);

    gpio_free(HARDWARE_DEVICE_PIN);

    if (device_id) { // device is phone
        comip_mfp_config(HARDWARE_PHONE_PIN, MFP_PIN_MODE_GPIO);
        comip_mfp_config_pull(HARDWARE_PHONE_PIN, MFP_PULL_UP);
        comip_mfp_gpio_config(HARDWARE_PHONE_PIN, MFP_GPIO_INPUT, 0);

        retval = gpio_request(HARDWARE_PHONE_PIN , "hw_phone_pin");
        if (retval) {
            pr_err("%s: Failed to get hardware phone gpio Code: %d.",
                   __func__, retval);
        }
        value1 = gpio_get_value_cansleep(HARDWARE_PHONE_PIN);
        gpio_free(HARDWARE_PHONE_PIN);

        comip_mfp_config(HARDWARE_PHONE_PIN, MFP_PIN_MODE_GPIO);
        comip_mfp_config_pull(HARDWARE_PHONE_PIN, MFP_PULL_DOWN);
        comip_mfp_gpio_config(HARDWARE_PHONE_PIN, MFP_GPIO_INPUT, 0);

        retval = gpio_request(HARDWARE_PHONE_PIN , "hw_phone_pin");
        if (retval) {
            pr_err("%s: Failed to get hardware phone gpio Code: %d.",
                   __func__, retval);
        }
        value2 = gpio_get_value_cansleep(HARDWARE_PHONE_PIN);
        gpio_free(HARDWARE_PHONE_PIN);

        if ((value1 != value2)) {
            hardware_board_id = MPLUS_BOARD_EHANCED_PHONE;
        } else {
            hardware_board_id = MPLUS_BOARD_GENERAL_PHONE;
        }

    } else {
        hardware_board_id = MPLUS_BOARD_PAD;    //device is pad
    }

    return hardware_board_id;
}

int comip_board_info_get(char *name)
{
    int i, volt1, volt2, r1507, r1508, r1520 , r1521, voltage1, voltage2;
    int Vadc = 2850, retval; //mv
    int min_index1 = 0, min_index2 = 0, bom_id;
    int hardware_id, high_bit, low_bit;
    char version[50];

    volt1 = pmic_get_adc_conversion(HARDWARE_BOARD_ADC1);
    volt2 = pmic_get_adc_conversion(HARDWARE_BOARD_ADC2);

    for (i = 0; i < ARRAY_SIZE(board_bom_map1); i++) {

        r1507 = board_bom_map1[i].r1507;
        r1508 = board_bom_map1[i].r1508;
        r1520 = board_bom_map2[i].r1520;
        r1521 = board_bom_map2[i].r1521;
        voltage1 = Vadc * r1508 / (r1507 + r1508);
        voltage2 = Vadc * r1521 / (r1520 + r1521);
        board_bom_map1[i].delta_h = abs(volt1 - voltage1);
        board_bom_map2[i].delta_l = abs(volt2 - voltage2);

        if (i > 0 && board_bom_map1[i].delta_h < board_bom_map1[min_index1].delta_h)
            min_index1 = i;

        if (i > 0 && board_bom_map2[i].delta_l < board_bom_map2[min_index2].delta_l)
            min_index2 = i;

    }

    bom_id = (((board_bom_map1[min_index1].id - 1) * 15) +  board_bom_map2[min_index2].id);

    if ((!min_index1) || (!min_index2))
        bom_id = 0;

#if 1
    retval = gpio_request(HARDWARE_BOARD_HIGH_PIN, "hw_high_pin");
    if (retval) {
        pr_err("%s: Failed to get hardware version high gpio Code: %d.",
               __func__, retval);
    }

    retval = gpio_request(HARDWARE_BOARD_LOW_PIN, "hw_low_pin");
    if (retval) {
        pr_err("%s: Failed to get hardware version low gpio Code: %d.",
               __func__, retval);
    }
#endif

    high_bit = gpio_get_value_cansleep(HARDWARE_BOARD_HIGH_PIN);
    low_bit = gpio_get_value_cansleep(HARDWARE_BOARD_HIGH_PIN);
    hardware_id = 2 * high_bit + low_bit;

    printk(KERN_ALERT"device_id == %d hardware_id = %d bom id = %d\n", HARDWARE_DEVICE_ID, hardware_id, bom_id);

    memset(version, 0 , sizeof(version));
    sprintf(version, "%s-%s-BOM-%d\n", hardware_info_map[HARDWARE_DEVICE_ID].version, hardware_board_info_map[hardware_id].version, bom_id);
    gpio_free(HARDWARE_BOARD_HIGH_PIN);
    gpio_free(HARDWARE_BOARD_LOW_PIN);

    if (name) {
        strcpy(name, version);
    }

#ifdef CONFIG_COMIP_BOARD_MPLUS_PAD
    hardware_id = 0;
#endif

#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
    hardware_id = 1;
#endif


    return hardware_id;

}


#ifdef CONFIG_BAT_ID_BQ2022A
static int bq2022a_invalid(void)
{
    int ret = 0;
    if ((cpu_is_lc1860_eco1() || cpu_is_lc1860_eco2()))
        ret = 1; // invalid
    return ret;
}

static struct bq2022a_platform_data bq2022a_info = {
    .sdq_pin = BAT_ID_BQ2022A_PIN,
    .sdq_gpio = BAT_ID_BQ2022A_PINEOC,
    .bat_id_invalid = bq2022a_invalid,
};

static struct platform_device bq2022a_device = {
    .name = "bq2022a",
    .id = -1,
    .dev = {
        .platform_data = &bq2022a_info,
    }
};
#endif

#if defined(CONFIG_KEYBOARD_GPIO_MPLUS)
static struct gpio_keys_button mplus_gpio_key_buttons[] = {
      {
        .code       = KEY_F13,
        .gpio       = HEADSET_KEY_PTT1,
        .desc       = "HEADSET PTT1",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

    {
        .code       = KEY_F14,
        .gpio       = HEADSET_KEY_PTT2,
        .desc       = "HEADSET PTT2",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI)
    {
        .code       = KEY_VOLUMEUP,
        .gpio       = COMIP_GPIO_KEY_VOLUMEUP,
        .desc       = "volumeup Button",
        .active_low = 1,
        .debounce_interval = 30,
    },
    {
        .code       = KEY_VOLUMEDOWN,
        .gpio       = COMIP_GPIO_KEY_VOLUMEDOWN,
        .desc       = "volumedown Button",
        .active_low = 1,
        .debounce_interval = 30,
    },

    {
        .code       = KEY_DESTRUCTION,
        .gpio       = GPIO_KEY_DESTROY,
        .desc       = "DESTROY Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

    {
        .code       = KEY_SHOP,
        .gpio       = GPIO_KEY_PTT1,
        .desc       = "PTT1 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
        .wakeup = 1,
    },

    {
        .code       = KEY_CHAT,
        .gpio       = GPIO_KEY_PTT2,
        .desc       = "PTT2 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
        .wakeup = 1,
    },

    {
        .code       = KEY_F1,
        .gpio       = GPIO_KEY_F1,
        .desc       = "F1 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

    {
        .code       = KEY_F2,
        .gpio       = GPIO_KEY_F2,
        .desc       = "F2 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

    {
        .code       = KEY_F3,
        .gpio       = GPIO_KEY_F3,
        .desc       = "F3 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },
#endif

#if defined (CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {
        .code       = KEY_VOLUMEUP,
        .gpio       = COMIP_GPIO_KEY_VOLUMEUP,
        .desc       = "volumeup Button",
        .active_low = 1,
        .debounce_interval = 30,
    },

    {
        .code       = KEY_VOLUMEDOWN,
        .gpio       = COMIP_GPIO_KEY_VOLUMEDOWN,
        .desc       = "volumedown Button",
        .active_low = 1,
        .debounce_interval = 30,
    },

    {
        .code       = KEY_DESTRUCTION,
        .gpio       = GPIO_KEY_DESTROY,
        .desc       = "DESTROY Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

    {
        .code       = KEY_SHOP,
        .gpio       = GPIO_KEY_PTT1,
        .desc       = "PTT1 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
        .wakeup = 1,
    },

    {
        .code       = KEY_CHAT,
        .gpio       = GPIO_KEY_PTT2,
        .desc       = "PTT2 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
        .wakeup = 1,
    },

    {
        .code       = KEY_MENU,
        .gpio       = GPIO_KEY_F1,
        .desc       = "F1 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

    {
        .code       = KEY_HOME,
        .gpio       = GPIO_KEY_F2,
        .desc       = "F2 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },

    {
        .code       = KEY_BACK,
        .gpio       = GPIO_KEY_F3,
        .desc       = "F3 Button",
        .active_low = 1,
        .debounce_interval = 30,
        .can_disable = 0,
    },
#endif
};

static struct gpio_keys_platform_data mplus_gpio_key_button_data = {
    .buttons    = mplus_gpio_key_buttons,
    .nbuttons   = ARRAY_SIZE(mplus_gpio_key_buttons),
};

static struct platform_device mplus_gpio_button_device = {
    .name       = "comip-gpio-keys",
    .id     = -1,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_gpio_key_button_data,
    },
};

#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI) || defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
static struct aw9523_led_pdata led_pdata[] = {
    {
        .id = 0,
        .cdev = {
            .name = "green",
            .max_brightness = 255,
        },
    },
    {
        .id = 2,
        .cdev = {
            .name = "blue",
            .max_brightness = 255,
        },
    },
    {
        .id = 3,
        .cdev = {
            .name = "key_led1",
            .max_brightness = 255,
        },
    },
    {
        .id = 4,
        .cdev = {
            .name = "key_led2",
            .max_brightness = 255,
        },
    },
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI)
      {
        .id = 1,
        .cdev = {
            .name = "red",
            .max_brightness = 255,
        },
    },
    {
        .id = 5,
        .cdev = {
            .name = "key_led3",
            .max_brightness = 255,
        },
    },
    {
        .id = 6,
        .cdev = {
            .name = "key_led4",
            .max_brightness = 255,
        },
    },
#endif
};
#endif

#define LED_DEF(_name, _gpio, _default_trigger) \
     { \
         .name = _name,  \
         .gpio = _gpio, \
         .default_trigger   = _default_trigger, \
     }
#if 0
static struct gpio_led leds[] = {
    LED_DEF("fan", V_FAN_12V_EN_PIN, "none"),
};

int get_fan_gpio(void)
{
    printk("[%s_INFO][%04d] [%s] board_is_NH, fan_en=GPIO_%d\n",
           __FILE__, __LINE__, __func__, V_FAN_12V_EN_PIN);
    return V_FAN_12V_EN_PIN;
}

static struct gpio_led_platform_data led_data = {
    .get_fan_gpio = get_fan_gpio,
    .num_leds = ARRAY_SIZE(leds),
    .leds = leds,
};

static struct platform_device leds_device = {
    .name           = "leds-gpio",
    .id         = -1,
    .dev.platform_data  = &led_data,
};
#endif
/*
static int power_v_aer_5v(int onoff)
{
    if (onoff) {
        gpio_direction_output(DBB2EX_5V_EN_PIN, 1);
        printk("%s: HIGH\n", __func__);
    } else {
        gpio_direction_output(DBB2EX_5V_EN_PIN, 0);
        printk("%s: LOW\n", __func__);
    }

    return 0;
}
*/
static int power_vtt_4v(int onoff)
{
    if (onoff) {
        gpio_direction_output(DBB2VTT4V_EN_PIN, 1);
        printk("%s: HIGH\n", __func__);
    } else {
        gpio_direction_output(DBB2VTT4V_EN_PIN, 0);
        printk("%s: LOW\n", __func__);
    }

    return 0;
}

static int power_vcc3v3_dac(int onoff)
{
    if (onoff) {
        gpio_direction_output(DBB2DAC_PWR_EN_PIN, 1);
        printk("%s: HIGH\n", __func__);
    } else {
        gpio_direction_output(DBB2DAC_PWR_EN_PIN, 0);
        printk("%s: LOW\n", __func__);
    }

    return 0;
}

/*
static int power_vex1_5v(int onoff)
{
    if (onoff) {
        gpio_direction_output(DBB2VEX1_5V_EN_PIN, 1);
        printk("%s: HIGH\n", __func__);
    } else {
        gpio_direction_output(DBB2VEX1_5V_EN_PIN, 0);
        printk("%s: LOW\n", __func__);
    }

    return 0;
}

static int power_vex2_5v(int onoff)
{
    if (onoff) {
        gpio_direction_output(DBB2VEX2_5V_EN_PIN, 1);
        printk("%s: HIGH\n", __func__);
    } else {
        gpio_direction_output(DBB2VEX2_5V_EN_PIN, 0);
        printk("%s: LOW\n", __func__);
    }

    return 0;
}
*/
static int power_minipcie_vbus(int onoff)
{
    if (onoff) {
        gpio_direction_output(DBB2MINIPCIE_VBUS_PIN, 1);
        printk("%s: HIGH\n", __func__);
    } else {
        gpio_direction_output(DBB2MINIPCIE_VBUS_PIN, 0);
        printk("%s: LOW\n", __func__);
    }

    return 0;
}
#if 0
static int power_vfan_12v(int onoff)
{
    if (onoff) {
        gpio_direction_output(V_FAN_12V_EN_PIN, 1);
        printk("%s: HIGH\n", __func__);
    } else {
        gpio_direction_output(V_FAN_12V_EN_PIN, 0);
        printk("%s: LOW\n", __func__);
    }

    return 0;
}
#endif

#if defined (CONFIG_DTT_MODULES_SYSFS)
#if 0
int fax_power_on(void)
{
    gpio_direction_output(DB2_RJ11_POWER_ENABLE, 1);
    return 0;
}

int fax_power_off(void)
{
    gpio_direction_output(DB2_RJ11_POWER_ENABLE, 0);
    return 0;
}

int walkie_power_on(void)
{
    gpio_direction_output(TCA6424A_1_P25, 1);
    gpio_direction_output(TCA6424A_1_P24, 1);
    gpio_direction_output(ANT_PE42850_V3, 1);
    gpio_direction_output(ANT_PE42850_V2, 1);
    gpio_direction_output(ANT_PE42850_V1, 0);
    return 0;
}

int walkie_power_off(void)
{
    gpio_direction_output(TCA6424A_1_P25, 0);
    gpio_direction_output(TCA6424A_1_P24, 0);
    gpio_direction_output(ANT_PE42850_V3, 0);
    gpio_direction_output(ANT_PE42850_V2, 0);
    gpio_direction_output(ANT_PE42850_V1, 1);
    return 0;
}

int max3222_power_on(void)
{
    gpio_direction_output(MAX3222_EN_PIN, 1);
    return 0;
}

int max3222_power_off(void)
{
    gpio_direction_output(MAX3222_EN_PIN, 0);
    return 0;
}

int max881r_power_on(void)
{
    gpio_direction_output(TCA6424A_0_P07, 1);
    return 0;
}


int max881r_power_off(void)
{
    gpio_direction_output(TCA6424A_0_P07, 0);
    return 0;
}

int sylincom_power_on(void)
{
    gpio_direction_output(TCA6424A_1_P21, 1);
    mdelay(5);
    gpio_direction_output(TCA6424A_1_P20, 1);
    return 0;
}

int sylincom_power_off(void)
{
    gpio_direction_output(TCA6424A_1_P21, 0);
    mdelay(5);
    gpio_direction_output(TCA6424A_1_P20, 0);
    return 0;
}

int sylincom_reset(void)
{
    gpio_direction_output(TCA6424A_1_P20, 0);
    mdelay(15);
    gpio_direction_output(TCA6424A_1_P20, 1);
    return 0;
}

int sylincom_state(void)
{
    gpio_direction_output(SYLINCOM_EARLAY_WAKEUP, 1);
    mdelay(15);
    gpio_direction_output(SYLINCOM_EARLAY_WAKEUP, 0);
    return 0;
}
#endif
/* add by cuixuan */
int rf_power_on(void)
{
    power_vcc3v3_dac(1); //gpio 65
    //gpio_direction_output(DBB2DAC_PWR_EN_PIN, 1); //gpio 65
    gpio_direction_output(DBB2RF_PWRCTL3_PIN, 1);
    gpio_direction_output(DBB2RF_SHIFT_EN_PIN, 0); //gpio 144
    gpio_direction_output(DBB2RF_PWRCTL1_PIN, 1); //gpio 120
    gpio_direction_output(DBB2RF_PWRCTL2_PIN, 1);
    gpio_direction_output(DBB2RF_PIN, 1);
    return 0;
}

int rf_power_off(void)
{
    gpio_direction_output(DBB2RF_PIN, 0);
    power_vcc3v3_dac(0); //gpio 65
    //gpio_direction_output(DBB2DAC_PWR_EN_PIN, 0); //gpio 65
    gpio_direction_output(DBB2RF_PWRCTL3_PIN, 0);
    gpio_direction_output(DBB2RF_PWRCTL2_PIN, 0);
    gpio_direction_output(DBB2RF_PWRCTL1_PIN, 0); //gpio 120
    gpio_direction_output(DBB2RF_SHIFT_EN_PIN, 1); //gpio 144
    return 0;
}
int tiantong_power_off(void);

int lte_sim_on(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    //sw sim to ext lte
    gpio_direction_output(DBB2REC_SW_IN_PIN, 1);
#endif

    return 0;
}

int lte_power_on(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    gpio_direction_input(DBB2ZY_SW_EN_PIN);
    if (gpio_get_value(DBB2ZY_SW_EN_PIN) != 0){
       //no lte detect
       return 1;
    }

    tiantong_power_off();
    //no boot mode
    gpio_direction_output(DBB2TT_BOOTCTL_PIN, 0);

    //sw usb to lte
    gpio_direction_output(TCA6424A_0_P15, 1);

    gpio_direction_output(DBB2VTT4V_EN_PIN, 1);
    msleep(1000);
    gpio_direction_output(TCA6424A_0_P00, 0);
    gpio_direction_output(TCA6424A_0_P00, 1);
    msleep(3000);
    gpio_direction_output(TCA6424A_0_P00, 0);
#endif

    return 0;
}

int lte_boot_power_on(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    gpio_direction_input(DBB2ZY_SW_EN_PIN);
    if (gpio_get_value(DBB2ZY_SW_EN_PIN) != 0){
       //no lte detect
       return 1;
    }

    tiantong_power_off();
    //no boot mode
    //gpio_direction_output(DBB2TT_BOOTCTL_PIN, 0);

    //sw usb to lte
    gpio_direction_output(TCA6424A_0_P15, 1);

    gpio_direction_output(DBB2VTT4V_EN_PIN, 1);
    msleep(1000);
    gpio_direction_output(TCA6424A_0_P00, 0);
    gpio_direction_output(TCA6424A_0_P00, 1);
    msleep(3000);
    gpio_direction_output(TCA6424A_0_P00, 0);
#endif

    return 0;
}

int lte_sim_off(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    //sw sim to main lte
    gpio_direction_output(DBB2REC_SW_IN_PIN, 0);
#endif

    return 0;
}

int lte_power_off(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    //no boot mode
    gpio_direction_output(DBB2TT_BOOTCTL_PIN, 0);

    //sw usb to tt
    gpio_direction_output(TCA6424A_0_P15, 0);

    gpio_direction_output(DBB2VTT4V_EN_PIN, 0);
#endif

    return 0;
}

int lte_boot_on(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    gpio_direction_output(DBB2TT_BOOTCTL_PIN, 0);
    lte_power_off();
    gpio_direction_output(DBB2TT_BOOTCTL_PIN, 1);
    lte_boot_power_on();

    //need soft reset or soft poweroff poweron lte
#endif
    return 0;
}

int lte_boot_off(void)
{
    return 0;
}

int lte_state(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    gpio_direction_input(DBB2ZY_SW_EN_PIN);
    if (gpio_get_value(DBB2ZY_SW_EN_PIN) != 0){
        //no lte detect
        return 1;
    }
#endif
    return 0;
}

int tiantong_state(void)
{
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    gpio_direction_input(TT_DETECT_PIN);
    if (gpio_get_value(TT_DETECT_PIN) != 0){
        //no tiantong detect
        return 1;
    }
#endif
    return 0;
}

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
int tiantong_power_on(void)
{
    gpio_direction_input(TT_DETECT_PIN);
    if (gpio_get_value(TT_DETECT_PIN) != 0){
       //no tiantong detect
       return 1;
    }

    lte_power_off();

    //sw usb to tt
    gpio_direction_output(TCA6424A_0_P15, 0);

    gpio_direction_output(DBB2TT_HOSTRSTN_IN_PIN, 1);
    gpio_direction_output(DBB2TT_ON_PIN, 0);
    gpio_direction_output(DBB2VTT4V_EN_PIN, 1);
    //mdelay(1000);
    msleep(1000);
    gpio_direction_output(DBB2TT_ON_PIN, 1);
    //mdelay(2000);
    msleep(2200);
    gpio_direction_output(DBB2TT_ON_PIN, 0);
    return 0;
}

int tiantong_power_off(void)
{
    //sw usb to tt
    gpio_direction_output(TCA6424A_0_P15, 1);

    gpio_direction_output(DBB2TT_ON_PIN, 0);
    gpio_direction_output(DBB2VTT4V_EN_PIN, 0);
    return 0;
}
#endif



#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI)
int tiantong_power_on(void)
{
    gpio_direction_output(DBB2TT_HOSTRSTN_IN_PIN, 1);
    gpio_direction_output(DBB2TT_ON_PIN, 0);
    gpio_direction_output(DBB2VTT4V_EN_PIN, 1);
    //mdelay(1000);
    msleep(1000);
    gpio_direction_output(DBB2TT_ON_PIN, 1);
    //mdelay(2000);
    msleep(2200);
    gpio_direction_output(DBB2TT_ON_PIN, 0);
    return 0;
}

int tiantong_power_off(void)
{
    gpio_direction_output(DBB2TT_ON_PIN, 0);
    gpio_direction_output(DBB2VTT4V_EN_PIN, 0);
    return 0;
}
#endif

int tiantong_reset(void)
{
    gpio_direction_output(DBB2TT_ON_PIN, 0);
    gpio_direction_output(DBB2TT_HOSTRSTN_IN_PIN, 1);
    mdelay(15);
    gpio_direction_output(DBB2TT_HOSTRSTN_IN_PIN, 0);
    //mdelay(300);
    msleep(300);
    gpio_direction_output(DBB2TT_HOSTRSTN_IN_PIN, 1);
    return 0;
}

int zy_tiantong(void)
{
    gpio_direction_output(DBB2ZY_SW_EN_PIN, 1);
    return 0;
}

int zy_lte(void)
{
    gpio_direction_output(DBB2ZY_SW_EN_PIN, 0);
    return 0;
}


#if 0

#if defined(CONFIG_COMIP_BOARD_MPLUS_PAD)
int tiadhoc_power_on(void)
{
    gpio_direction_output(TCA6424A_1_P26, 0); // sw -> tiadhoc
    gpio_direction_output(TCA6424A_3_P06, 1); // 3.7V 28V
    gpio_direction_output(TCA6424A_0_P10, 1); // Pwr_on
    gpio_direction_output(TCA6424A_0_P11, 1); // Pwr_n_off
    gpio_direction_output(TCA6424A_0_P13, 1); // Pwr_ctrl
    gpio_direction_output(TCA6424A_1_P11, 1); // Low_n_pwr
    gpio_direction_output(TCA6424A_1_P12, 1); // Reset_n_in
    return 0;
}

int tiadhoc_power_off(void)
{
    gpio_direction_output(TCA6424A_3_P06, 0); // 3.7V 28V
    gpio_direction_output(TCA6424A_0_P10, 0); // Pwr_on
    gpio_direction_output(TCA6424A_0_P11, 0); // Pwr_n_off
    gpio_direction_output(TCA6424A_0_P13, 0); // Pwr_ctrl
    gpio_direction_output(TCA6424A_1_P11, 0); // Low_n_pwr
    gpio_direction_output(TCA6424A_1_P12, 0); // Reset_n_in
    return 0;
}

int adhoc_power_on(void)
{
    gpio_direction_output(TCA6424A_3_P11, 0); //
    gpio_direction_output(TCA6424A_1_P26, 1); //sw -> adhoc
    gpio_direction_output(TCA6424A_3_P05, 1); // adhoc power on
    return 0;
}

int adhoc_power_off(void)
{
//    gpio_direction_output(TCA6424A_3_P11, 0); //
//    gpio_direction_output(TCA6424A_1_P26, 1); //
    gpio_direction_output(TCA6424A_3_P05, 0); // adhoc power off

    return 0;
}

int adhoc_boot_on(void)
{
    gpio_direction_output(TCA6424A_3_P05, 0); // adhoc  power off
    mdelay(3000);
    gpio_direction_output(TCA6424A_3_P12, 0); // boot ctl low
    mdelay(5);
    gpio_direction_output(TCA6424A_3_P05, 1); // adhoc power on

    gpio_direction_output(TCA6424A_3_P10, 1); // type c -> adhoc
    gpio_direction_output(TCA6424A_3_P11, 1); // type c -> adhoc
    return 0;
}

int adhoc_boot_off(void)
{
    return 0;
}

int adhoc_debug_on(void)
{
    gpio_direction_output(TCA6424A_1_P26, 0); //
    gpio_direction_output(TCA6424A_3_P12, 0); // boot ctl low
    mdelay(5);
    gpio_direction_output(TCA6424A_3_P11, 1); // type c -> adhoc
    gpio_direction_output(TCA6424A_3_P10, 1); // type c -> adhoc
//    gpio_direction_output(TCA6424A_3_P05, 1); // 3.7v On
    return 0;
}

int adhoc_debug_off(void)
{
    gpio_direction_output(TCA6424A_3_P10, 0); // type c -> LTE
    return 0;
}
#endif

#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
int rfctl_power_on(void)
{
    gpio_direction_output(TCA6424A_1_P05, 1);
    gpio_direction_output(TCA6424A_1_P06, 1);
    return 0;
}
int rfctl_power_off(void)
{
    gpio_direction_output(TCA6424A_1_P05, 0);
    gpio_direction_output(TCA6424A_1_P06, 0);
    return 0;
}
#endif
#ifdef CONFIG_COMIP_BOARD_MPLUS_PAD
int rfctl_power_on(void)
{
    gpio_direction_output(TCA6424A_0_P06, 1);
    return 0;
}
int rfctl_power_off(void)
{
    gpio_direction_output(TCA6424A_0_P06, 0);
    return 0;
}
#endif
#endif
#if 0
struct module_gpio_info fax_gpio[] = {
    {DB2_RJ11_POWER_ENABLE , "RJ11_POWER"},
};

struct module_gpio_info max3222_gpio[] = {
    {MAX3222_EN_PIN , "MAX3222_POWER"},
};

struct module_gpio_info sylincom_gpio[] = {
    {TCA6424A_1_P20 ,        "SYLINCOM_POWER"},
    {TCA6424A_1_P21 ,        "SYLINCOM_RESET"},
    {SYLINCOM_EARLAY_WAKEUP , "SYLINCOM_STATE"},
};
#endif

struct module_gpio_info lte_sim_gpio[] = {
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {DBB2REC_SW_IN_PIN ,        "SIM_SW"},
#endif
};

struct module_gpio_info lte_gpio[] = {
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {TCA6424A_0_P00 ,        "LTE_POWERKEY"},
    {TCA6424A_0_P15 ,        "USB_SW"},
    {DBB2TT_BOOTCTL_PIN ,        "LTE_BOOT"},
#endif
    {TT_DETECT_PIN ,        "TT_DET"},
};


struct module_gpio_info tiantong_gpio[] = {
    {DBB2TT_ON_PIN ,        "TIANTONG_POWERKEY"},
    {DBB2TT_HOSTRSTN_IN_PIN ,        "TIANTONG_RESET"},
};


struct module_gpio_info zy_tiantong_lte_gpio[] = {
    {DBB2ZY_SW_EN_PIN ,        "ZY_TIANTONG_LTE"},
};

/* add by cuixuan */
struct module_gpio_info rf_gpio[] = {
    {DBB2RF_PIN,                "RF_POWERKEY_24"},
    {DBB2RF_PWRCTL2_PIN,        "RF_POWERKEY_108"},
    {DBB2RF_PWRCTL3_PIN,        "RF_POWERKEY_102"},
};

#if 0

#ifdef CONFIG_COMIP_BOARD_MPLUS_PAD
struct module_gpio_info tiadhoc_gpio[] = {
    {TCA6424A_3_P06 ,   "TIADHOC_POWER_28V"},
    {TCA6424A_0_P10 ,    "TIADHOC_POWER_ON"},
    {TCA6424A_0_P11 ,   "TIADHOC_POWER_OFF"},
    {TCA6424A_0_P13 ,  "TIADHOC_POWER_CTRL"},
    {TCA6424A_1_P11 ,   "TIADHOC_POWER_LOW"},
    {TCA6424A_1_P12 , "TIADHOC_POWER_RESET"},
};

struct module_gpio_info walkie_gpio[] = {
    {TCA6424A_1_P25,  "JQ_POWER"},
    {TCA6424A_1_P24,    "JQ_PWR"},
    {ANT_PE42850_V3,    "ANT_PE42850_V3 3p26"},
    {ANT_PE42850_V2,    "ANT_PE42850_V2 3p25"},
    {ANT_PE42850_V1,    "ANT_PE42850_V1 3p24"},
};

struct module_gpio_info adhoc_gpio[] = {
    {TCA6424A_1_P26 ,   "USB_SW"},
    {TCA6424A_3_P12 ,   "KP_BOOT_MODULE"},
    {TCA6424A_3_P11 ,   "USB_SW2"},
    {TCA6424A_3_P10 ,   "USB_SW1"},
    {TCA6424A_3_P05 ,   "ADHOC_PWR_EN"},
};
#endif

#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
struct module_gpio_info rfctl_gpio[] = {
    {TCA6424A_1_P05 , "ADHOC_POWER_3V6"},
    {TCA6424A_1_P06 , "ADHOC_POWER_3V3"},

};

struct module_gpio_info max881r_gpio[] = {
    {TCA6424A_0_P07 , "MAX881R_POWER"},
};

#endif

#ifdef CONFIG_COMIP_BOARD_MPLUS_PAD
struct module_gpio_info rfctl_gpio[] = {
    {TCA6424A_0_P06 , "ADHOC_POWER_3V6"},
};
#endif
#endif

static struct dtt_modules mplus_modules_data[] = {
#if 0
    {
        .name = "fax",
        .power_on =  fax_power_on,
        .power_off = fax_power_off,
        .gpio = fax_gpio,
        .gpio_num = ARRAY_SIZE(fax_gpio),
        .show_state = "disbale",
    },

    {
        .name = "max3222",
        .power_on =  max3222_power_on,
        .power_off = max3222_power_off,
        .gpio = max3222_gpio,
        .gpio_num = ARRAY_SIZE(max3222_gpio),
        .show_state = "disbale",
    },

    {
        .name = "sylincom",
        .power_on =  sylincom_power_on,
        .power_off = sylincom_power_off,
        .reset = sylincom_reset,
        .state = sylincom_state,
        .gpio = sylincom_gpio,
        .gpio_num = ARRAY_SIZE(sylincom_gpio),
        .show_state = "disable",
    },
#endif
    {
        .name = "lte_sim",
        .power_on =  lte_sim_on,
        .power_off = lte_sim_off,
        .gpio = lte_sim_gpio,
        .gpio_num = ARRAY_SIZE(lte_sim_gpio),
        .show_state = "disable",
    },


    {
        .name = "lte",
        .power_on =  lte_power_on,
        .power_off = lte_power_off,
        .boot_on = lte_boot_on,
        .boot_off = lte_boot_off,
        .state = lte_state,
        .gpio = lte_gpio,
        .gpio_num = ARRAY_SIZE(lte_gpio),
        .show_state = "disable",
    },


    {
        .name = "tiantong",
        .power_on =  tiantong_power_on,
        .power_off = tiantong_power_off,
        .reset = tiantong_reset,
        .state = tiantong_state,
        .gpio = tiantong_gpio,
        .gpio_num = ARRAY_SIZE(tiantong_gpio),
        .show_state = "disable",
    },

    {
        .name = "zy_tiantong_lte",
        .power_on =  zy_tiantong,
        .power_off = zy_lte,
        .gpio = zy_tiantong_lte_gpio,
        .gpio_num = ARRAY_SIZE(zy_tiantong_lte_gpio),
        .show_state = "disable",
    },

    /* add by cuixuan */
    {
        .name = "rfpower",
        .power_on =  rf_power_on,
        .power_off = rf_power_off,
        .gpio = rf_gpio,
        .gpio_num = ARRAY_SIZE(rf_gpio),
        .show_state = "enable",
    },
#if 0
    {
        .name = "rfctl",
        .power_on =  rfctl_power_on,
        .power_off = rfctl_power_off,
        .gpio = rfctl_gpio,
        .gpio_num = ARRAY_SIZE(rfctl_gpio),
        .show_state = "enable",
    },

#if defined(CONFIG_COMIP_BOARD_MPLUS_PAD)
    {
        .name = "walkie",
        .power_on =  walkie_power_on,
        .power_off = walkie_power_off,
        .gpio = walkie_gpio,
        .gpio_num = ARRAY_SIZE(walkie_gpio),
        .show_state = "disbale",
    },

    {
        .name = "tiadhoc",
        .power_on =  tiadhoc_power_on,
        .power_off = tiadhoc_power_off,
        .gpio = tiadhoc_gpio,
        .gpio_num = ARRAY_SIZE(tiadhoc_gpio),
        .show_state = "disable",
    },

    {
        .name = "adhoc",
        .power_on =  adhoc_power_on,
        .power_off = adhoc_power_off,
        .boot_on = adhoc_boot_on,
        .boot_off = adhoc_boot_off,
        .debug_on = adhoc_debug_on,
        .debug_off = adhoc_debug_off,
        .gpio = adhoc_gpio,
        .gpio_num = ARRAY_SIZE(adhoc_gpio),
        .show_state = "enable",
    },
#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_PHONE)
    {
        .name = "max881r",
        .power_on =  max881r_power_on,
        .power_off = max881r_power_off,
        .gpio = max881r_gpio,
        .gpio_num = ARRAY_SIZE(max881r_gpio),
        .show_state = "disable",
    },
#endif
#endif

};

static struct dtt_modules_pkg mplus_modules_data_pkg = {
    .dtt_modules_data = mplus_modules_data,
    .mod_total_num = ARRAY_SIZE(mplus_modules_data),
};
#if 0
static struct platform_device mplus_fax_device = {
    .name       = "modules-sysfs",
    .id     = 0,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

static struct platform_device mplus_max3222_device = {
    .name       = "modules-sysfs",
    .id     = 1,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

static struct platform_device mplus_sylincom_device = {
    .name       = "modules-sysfs",
    .id     = 2,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};
#endif

static struct platform_device mplus_lte_sim_device = {
    .name       = "modules-sysfs",
    .id     = 0,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};
static struct platform_device mplus_lte_device = {
    .name       = "modules-sysfs",
    .id     = 1,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

static struct platform_device mplus_tiantong_device = {
    .name       = "modules-sysfs",
    .id     = 2,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

static struct platform_device mplus_zy_device = {
    .name       = "modules-sysfs",
    .id     = 3,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

static struct platform_device mplus_rfpower_device = {
    .name       = "modules-sysfs",
    .id     = 4,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};
#if 0
static struct platform_device mplus_rfctl_device = {
    .name       = "modules-sysfs",
    .id     = 5,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

#if defined(CONFIG_COMIP_BOARD_MPLUS_PAD)
static struct platform_device mplus_walkie_device = {
    .name       = "modules-sysfs",
    .id     = 6,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

static struct platform_device mplus_tiadhoc_device = {
    .name       = "modules-sysfs",
    .id     = 7,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

static struct platform_device mplus_adhoc_device = {
    .name       = "modules-sysfs",
    .id     = 8,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};

#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_PHONE)
static struct platform_device mplus_max881r_device = {
    .name       = "modules-sysfs",
    .id     = 4,
    .num_resources  = 0,
    .dev        = {
        .platform_data  = &mplus_modules_data_pkg,
    },
};
#endif
#endif

#endif

static struct platform_device *devices[] __initdata = {
#if defined(CONFIG_BACKLIGHT_COMIP)
    &comip_backlight_device,
#endif
#if defined(CONFIG_FAN_PWM)
    &fan_device,
#endif
#if defined(CONFIG_LC1160_PWM)
    &lc1160_pwm_device,
#endif
#ifdef CONFIG_BAT_ID_BQ2022A
    &bq2022a_device,
#endif
#if defined(CONFIG_THERMAL_COMIP)
    &comip_thermal_device,
#endif
#if defined(CONFIG_LC1132_ADC) || defined(CONFIG_LC1160_ADC)
    &adc_dev,
#endif

#if defined(CONFIG_KEYBOARD_GPIO_MPLUS)
    &mplus_gpio_button_device,
#endif

#if defined (CONFIG_DTT_MODULES_SYSFS)
#if 0
    &mplus_fax_device,

    &mplus_max3222_device,

    &mplus_sylincom_device,
#endif
    &mplus_lte_sim_device,

    &mplus_lte_device,

    &mplus_tiantong_device,

    &mplus_zy_device,

    &mplus_rfpower_device,
#if 0

    &mplus_rfctl_device,

#ifdef CONFIG_COMIP_BOARD_MPLUS_PAD
    &mplus_walkie_device,

    &mplus_tiadhoc_device,

    &mplus_adhoc_device,
#endif

#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
    &mplus_max881r_device,
#endif

#endif
#endif

#if defined(CONFIG_LC1132_MONITOR_BATTERY) || defined(CONFIG_LC1160_MONITOR_BATTERY)
    &monitor_battery_dev,
    &monitor_battery_dev_sub,
#endif


};

static void __init comip_init_devices(void)
{
    platform_add_devices(devices, ARRAY_SIZE(devices));
}

static struct mfp_pin_cfg comip_mfp_cfg[] = {
    // TODO:  to be continue for device
    /* Power */
    {DBB2EX_5V_EN_PIN,     MFP_PIN_MODE_GPIO},
    {DBB2OTG_EN_PIN,       MFP_PIN_MODE_GPIO},
    {DBB2VTT4V_EN_PIN,     MFP_PIN_MODE_GPIO},
    {DBB2_BUCK3V3_EN_PIN,  MFP_PIN_MODE_GPIO},
    {DBB2DAC_PWR_EN_PIN,   MFP_PIN_MODE_GPIO},
    {DBB2RF_PWRCTL1_PIN,   MFP_PIN_MODE_GPIO},
    {DBB2VEX1_5V_EN_PIN,   MFP_PIN_MODE_GPIO},
    {DBB2VEX2_5V_EN_PIN,   MFP_PIN_MODE_GPIO},
    {DBB2RF_SHIFT_EN_PIN,  MFP_PIN_MODE_GPIO},
    {DBB2BDS_PP1S_EN_PIN,  MFP_PIN_MODE_GPIO},
    {DBB2MINIPCIE_VBUS_PIN,  MFP_PIN_MODE_GPIO},

#if defined(CONFIG_FAN_PWM)
    {DBB2FAN_TACH_PIN,  MFP_PIN_MODE_GPIO},
#endif
#if defined(CONFIG_COMIP_LC1160)
    /* LC1160. */
    {LC1160_INT_PIN,        MFP_PIN_MODE_GPIO},
#endif
#if defined(CONFIG_BATTERY_MAX17058) || defined(CONFIG_BATTERY_BQ27421)
    {MAX17058_FG_INT_PIN,   MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_CHARGER_BQ24158)
    {EXTERN_CHARGER_INT_PIN,    MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_CHARGER_BQ24161)
    {EXTERN_DBB2CHG_EN_N_PIN,   MFP_PIN_MODE_GPIO},
    {EXTERN_CHG_INT2DBB_PIN,    MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_CHARGER_BQ24773)
    {CHG2DBB_ACOK_PIN,   MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_BATTERY_BQ27510_G3)
    {BQ27510_G3_FG_INT_PIN,     MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_FM23_DSP)
    {FM23_RST_N_PIN,    MFP_PIN_MODE_GPIO},
    {FM23_MCLK_EN_PIN,  MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_ADC3001_CHIP)
    {ADC3100_RESET_GPIO_PIN,    MFP_PIN_MODE_GPIO},
    {ADC3100_MCLK_GPIO_PIN, MFP_PIN_MODE_0},
#endif

    /* LCD. */
    {LCD_RESET_PIN,         MFP_PIN_MODE_GPIO},
#if defined(CONFIG_SENSORS_INV_MPU6880)
    {INV6880_INT_PIN,       MFP_PIN_MODE_GPIO},
#endif

#ifdef CONFIG_SENSORS_BMI055
    {BMI055_INT1_ACC,         MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_TOUCHSCREEN_FT5X06)
    {FT5X06_RST_PIN,                MFP_PIN_MODE_GPIO},
    {FT5X06_INT_PIN,                MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_TOUCHSCREEN_CYPRESS_CYTTSP5)
    {CYTTSP5_RST_PIN,                MFP_PIN_MODE_GPIO},
    {CYTTSP5_INT_PIN,                MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_TOUCHSCREEN_S3402)
    {S3402_INT_PIN,         MFP_PIN_MODE_GPIO},
    {S3402_RST_PIN,         MFP_PIN_MODE_GPIO},
#endif

    /*Camera*/
#if defined(CONFIG_VIDEO_S5K3H2)    /* S5K3H2 */
    {S5K3H2_POWERDOWN_PIN,  MFP_PIN_MODE_GPIO},
    {S5K3H2_RESET_PIN,      MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_VIDEO_OV13850)    /* OV13850. */
    {OV13850_POWERDOWN_PIN,  MFP_PIN_MODE_GPIO},
    {OV13850_RESET_PIN,      MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_VIDEO_OV8865)    /* OV8865. */
    {OV8865_POWERDOWN_PIN,  MFP_PIN_MODE_GPIO},
    {OV8865_RESET_PIN,      MFP_PIN_MODE_GPIO},
#endif
#if defined(CONFIG_VIDEO_OV9760)        /* OV9760. */
    {OV9760_POWERDOWN_PIN,          MFP_PIN_MODE_GPIO},
    {OV9760_RESET_PIN,              MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_VIDEO_OV5648_2LANE_19M)
    {OV5648_POWERDOWN_PIN,          MFP_PIN_MODE_GPIO},
    {OV5648_RESET_PIN,          MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_VIDEO_OV2680)        /* OV2680. */
    {OV2680_POWERDOWN_PIN,          MFP_PIN_MODE_GPIO},
    {OV2680_RESET_PIN,              MFP_PIN_MODE_GPIO},
#endif

#if defined(EAR_SWITCH_PIN)
    {EAR_SWITCH_PIN,        MFP_PIN_MODE_GPIO},
#endif

    //{MAX3222_EN_PIN,      MFP_PIN_MODE_GPIO},
    {ANALOG_PA_GPIO_PIN,  MFP_PIN_MODE_GPIO},
    {SWITCH1_GPIO_PIN,  MFP_PIN_MODE_GPIO},
    {SWITCH2_GPIO_PIN,  MFP_PIN_MODE_GPIO},
    {SWITCH3_GPIO_PIN,  MFP_PIN_MODE_GPIO},
    {SWITCH4_GPIO_PIN,  MFP_PIN_MODE_GPIO},

#ifdef CONFIG_COMIP_BOARD_MPLUS_V2_MINI
    {SWITCH5_GPIO_PIN,  MFP_PIN_MODE_GPIO},
    {SWITCH5_ENABLE_PIN,  MFP_PIN_MODE_GPIO},
#endif

#ifdef  USE_I2S1
    {I2S1_DATA_OUT,  MFP_PIN_MODE_1},
    {I2S1_DATA_IN,   MFP_PIN_MODE_1},
    {I2S1_CLK_PIN,   MFP_PIN_MODE_1},
    {I2S1_WS_PIN,   MFP_PIN_MODE_1},
#endif

#if defined(CODEC_PA_PIN)
    {CODEC_PA_PIN,      MFP_PIN_MODE_GPIO},
#endif


#if defined(CONFIG_KEYBOARD_GPIO_MPLUS)

    {HEADSET_KEY_PTT1, MFP_PIN_MODE_GPIO},
    {HEADSET_KEY_PTT2, MFP_PIN_MODE_GPIO},
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI)
    {COMIP_GPIO_KEY_VOLUMEUP, MFP_PIN_MODE_GPIO},
    {COMIP_GPIO_KEY_VOLUMEDOWN, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_DESTROY, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_PTT1, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_PTT2, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_F1, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_F2, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_F3, MFP_PIN_MODE_GPIO},
#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {COMIP_GPIO_KEY_VOLUMEUP, MFP_PIN_MODE_GPIO},
    {COMIP_GPIO_KEY_VOLUMEDOWN, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_DESTROY, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_PTT1, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_PTT2, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_F1, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_F2, MFP_PIN_MODE_GPIO},
    {GPIO_KEY_F3, MFP_PIN_MODE_GPIO},
#endif

#endif

    /*mfp low power config*/
    {MIC_DETECT,                    MFP_PIN_MODE_GPIO},
#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
    {SM_PTT1,                       MFP_PIN_MODE_GPIO},
#endif

#if defined (CONFIG_COMIP_BOARD_MPLUS_PHONE)
    {MFP_PIN_GPIO(114),     MFP_PIN_MODE_GPIO},
#endif
    {MFP_PIN_GPIO(108),     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(107),     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(104),     MFP_PIN_MODE_GPIO},
    {BAT_LTC2DBB_VALID1_PIN , MFP_PIN_MODE_GPIO},
    {BAT_LTC2DBB_VALID2_PIN , MFP_PIN_MODE_GPIO},
    {DBB2BAT_TEMP_VOLT_SW_PIN,     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(217),     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(222),     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(226),     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(228),     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(229),     MFP_PIN_MODE_GPIO},
    //{SPI2UART_VOL_SHIFT_4_SPI_EN, MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(102),     MFP_PIN_MODE_GPIO},
#if defined(CONFIG_SENSORS_IST8303)
    {MFP_PIN_GPIO(IST8303_DRDY_PIN), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(IST8303_RST_PIN),  MFP_PIN_MODE_GPIO},
#endif
#if defined(CONFIG_SPI_COMIP) || defined(CONFIG_SPI_COMIP_MODULE)
    {SPI2UART_SPI1_SI,  MFP_PIN_MODE_0},
    {SPI2UART_SPI1_SO,  MFP_PIN_MODE_0},
    {SPI2UART_SPI1_CLK, MFP_PIN_MODE_0},
    {SPI2UART_SPI1_CS,  MFP_PIN_MODE_0},
#endif
#if defined(CONFIG_SERIAL_SC16IS7X2) || defined(CONFIG_SERIAL_SC16IS7X2_MODULE)
    {SPI2UART_INT,                MFP_PIN_MODE_GPIO},
    {SPI2UART_RESET,              MFP_PIN_MODE_GPIO},
    {SPI2UART_XTAL1_1P8M_EN,      MFP_PIN_MODE_GPIO},
    //{SPI2UART_VOL_SHIFT_4_BT_EN,  MFP_PIN_MODE_GPIO},
    {SPI2UART_VOL_SHIFT_4_SPI_EN, MFP_PIN_MODE_GPIO},
    {SPI2UART_SPI_CS,             MFP_PIN_MODE_GPIO},
#endif
#ifdef CONFIG_LIGHT_PROXIMITY_STK3X1X
    {STK3X1X_INT_PIN,             MFP_PIN_MODE_GPIO},
#endif

#if (defined(CONFIG_COMIP_APB_I2C3))
    {MFP_PIN_GPIO(167), MFP_PIN_MODE_1},
    {MFP_PIN_GPIO(168), MFP_PIN_MODE_1},
#endif

    {USB_OTG_ID_PIN,  MFP_PIN_MODE_GPIO},
    //{USB_OTG_PWR_PIN, MFP_PIN_MODE_GPIO},
    {USBID_EX_CONN_PIN,  MFP_PIN_MODE_GPIO},
    {USBID_AER_CONN_PIN,  MFP_PIN_MODE_GPIO},

    {MFP_PIN_GPIO(160),  MFP_PIN_MODE_GPIO},

    {HARDWARE_DEVICE_PIN,     MFP_PIN_MODE_GPIO},
    {HARDWARE_BOARD_HIGH_PIN, MFP_PIN_MODE_GPIO},
    {HARDWARE_BOARD_LOW_PIN,  MFP_PIN_MODE_GPIO},

#ifdef CONFIG_TYPE_C_DET_PI5USB30216A
    {TYPE_C_EN_PIN,    MFP_PIN_MODE_GPIO},
    {TYPE_C_INT_PIN, MFP_PIN_MODE_GPIO},
#endif

#if defined (CONFIG_DTT_MODULES_SYSFS)

    //{DB2_RJ11_POWER_ENABLE ,   MFP_PIN_MODE_GPIO},
    //{SYLINCOM_EARLAY_WAKEUP,   MFP_PIN_MODE_GPIO},
    {DBB2TT_BOOTCTL_PIN ,   MFP_PIN_MODE_GPIO},
    {DBB2TT_ON_PIN ,   MFP_PIN_MODE_GPIO},
    {DBB2TT_HOSTRSTN_IN_PIN,   MFP_PIN_MODE_GPIO},
    {DBB2ZY_SW_EN_PIN ,   MFP_PIN_MODE_GPIO},
    {TT_DETECT_PIN ,   MFP_PIN_MODE_GPIO},
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {DBB2REC_SW_IN_PIN ,   MFP_PIN_MODE_GPIO},
#endif



#endif
#ifdef CONFIG_USB_SERIAL_ADHOC
    {DBB2ADHOC_POWER_EN_PIN, MFP_PIN_MODE_GPIO},
#endif

#if defined (CONFIG_GPS_UNICORE)
    {UNICORE_GPS_RESET_PIN,     MFP_PIN_MODE_GPIO},
    {UNICORE_LNA_ENABLE_PIN,    MFP_PIN_MODE_GPIO},
    {UNICORE_B3_LNA_ENABLE_PIN, MFP_PIN_MODE_GPIO},
#if defined (CONFIG_COMIP_BOARD_MPLUS_PHONE)
    {UNICORE_GPS_EVENT0_PIN,    MFP_PIN_MODE_GPIO},
#endif
#endif

#if defined (CONFIG_GPS_UM220IIIN)
    //{UM220IIIN_VBACK_EN_PIN, MFP_PIN_MODE_GPIO},
    {UM220IIIN_PWR_EN_PIN, MFP_PIN_MODE_GPIO},
    {UM220IIIN_PPS_EN_PIN, MFP_PIN_MODE_GPIO},
    {UM220IIIN_LNA_EN_PIN, MFP_PIN_MODE_GPIO},
#endif

    {MFP_PIN_GPIO(124), MFP_PIN_MODE_GPIO},

    {DBB2RF_PIN, MFP_PIN_MODE_GPIO}, //add by cuixuan
    {DBB2RF_PWRCTL3_PIN, MFP_PIN_MODE_GPIO}, //add by cuixuan
    {DBB2RF_PWRCTL2_PIN, MFP_PIN_MODE_GPIO}, //add by cuixuan

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI) || defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {AW9523_KEY_RST,        MFP_PIN_MODE_GPIO},
    {AW9523_KEY_INT,        MFP_PIN_MODE_GPIO},
    {RLED_CTL1_PIN,         MFP_PIN_MODE_GPIO},
#endif

//USB HSIC
    {DBB2HSIC_RESET_N_PIN,        MFP_PIN_MODE_GPIO},

};

static struct mfp_pull_cfg comip_mfp_pull_cfg[] = {
    {LCD_RESET_PIN, MFP_PULL_UP},

    /* Power */
    {DBB2EX_5V_EN_PIN,    MFP_PULL_DOWN},
    {DBB2OTG_EN_PIN,      MFP_PULL_DOWN},
    {DBB2VTT4V_EN_PIN,    MFP_PULL_DOWN},
    {DBB2_BUCK3V3_EN_PIN, MFP_PULL_DOWN},
    {DBB2RF_PIN,          MFP_PULL_DOWN},
    {DBB2RF_PWRCTL2_PIN,  MFP_PULL_DOWN},
    {DBB2RF_PWRCTL3_PIN,  MFP_PULL_DOWN},
    {DBB2DAC_PWR_EN_PIN,  MFP_PULL_DOWN},
    {DBB2RF_PWRCTL1_PIN,  MFP_PULL_DOWN},
    {DBB2VEX1_5V_EN_PIN,  MFP_PULL_DOWN},
    {DBB2VEX2_5V_EN_PIN,  MFP_PULL_DOWN},
    {DBB2RF_SHIFT_EN_PIN, MFP_PULL_DOWN},
    {DBB2BDS_PP1S_EN_PIN, MFP_PULL_DOWN},
    {DBB2MINIPCIE_VBUS_PIN,  MFP_PULL_DOWN},

#ifdef CONFIG_TOUCHSCREEN_CYPRESS_CYTTSP5
    {CYTTSP5_I2C_IRQ_GPIO,   MFP_PULL_UP},
#endif
#if defined(CONFIG_FAN_PWM)
    {DBB2FAN_TACH_PIN,  MFP_PULL_UP},
#endif
#if defined(CONFIG_BATTERY_MAX17058) || defined(CONFIG_BATTERY_BQ27421)
    {MAX17058_FG_INT_PIN,   MFP_PULL_UP},
#endif
#if defined(CONFIG_CHARGER_BQ24158)
    {EXTERN_CHARGER_INT_PIN,    MFP_PULL_UP},
#endif
#if defined(CONFIG_CHARGER_BQ24161)
    {EXTERN_DBB2CHG_EN_N_PIN,   MFP_PULL_DOWN},
    {EXTERN_CHG_INT2DBB_PIN,    MFP_PULL_UP},
#endif
#if defined(CONFIG_CHARGER_BQ24773)
    {CHG2DBB_ACOK_PIN,   MFP_PULL_DOWN},
#endif

#if defined(CONFIG_BATTERY_BQ27510_G3)
    {BQ27510_G3_FG_INT_PIN,     MFP_PULL_UP},
#endif

#if defined(CONFIG_FM23_DSP)
    {FM23_RST_N_PIN,            MFP_PULL_UP},
    {FM23_MCLK_EN_PIN,          MFP_PULL_UP},
#endif
    {ANALOG_PA_GPIO_PIN,          MFP_PULL_UP},
    {SWITCH1_GPIO_PIN,            MFP_PULL_UP},
    {SWITCH2_GPIO_PIN,            MFP_PULL_UP},
    {SWITCH3_GPIO_PIN,            MFP_PULL_UP},
    {SWITCH4_GPIO_PIN,            MFP_PULL_UP},

#ifdef CONFIG_COMIP_BOARD_MPLUS_V2_MINI
    {SWITCH5_GPIO_PIN,            MFP_PULL_UP},
    {SWITCH5_ENABLE_PIN,            MFP_PULL_UP},
#endif

#if defined(CONFIG_ADC3001_CHIP)
    {ADC3100_RESET_GPIO_PIN,    MFP_PULL_UP},
#endif

#if defined(CONFIG_KEYBOARD_GPIO_MPLUS)

    {HEADSET_KEY_PTT1, MFP_PULL_UP},
    {HEADSET_KEY_PTT2, MFP_PULL_UP},
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI)
    {COMIP_GPIO_KEY_VOLUMEUP, MFP_PULL_UP},
    {COMIP_GPIO_KEY_VOLUMEDOWN, MFP_PULL_UP},
    {GPIO_KEY_DESTROY, MFP_PULL_UP},
    {GPIO_KEY_PTT1, MFP_PULL_UP},
    {GPIO_KEY_PTT2, MFP_PULL_UP},
    {GPIO_KEY_F1, MFP_PULL_UP},
    {GPIO_KEY_F2, MFP_PULL_UP},
    {GPIO_KEY_F3, MFP_PULL_UP},
#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {COMIP_GPIO_KEY_VOLUMEUP, MFP_PULL_UP},
    {COMIP_GPIO_KEY_VOLUMEDOWN, MFP_PULL_UP},
    {GPIO_KEY_DESTROY, MFP_PULL_UP},
    {GPIO_KEY_PTT1, MFP_PULL_UP},
    {GPIO_KEY_PTT2, MFP_PULL_UP},
    {GPIO_KEY_F1, MFP_PULL_UP},
    {GPIO_KEY_F2, MFP_PULL_UP},
    {GPIO_KEY_F3, MFP_PULL_UP},
#endif

#endif

#if defined(CONFIG_RTK_BLUETOOTH) || defined(CONFIG_BRCM_BLUETOOTH)
    {UART2_CTS_PIN, MFP_PULL_DOWN},
#endif

#if defined(CONFIG_TOUCHSCREEN_S3402)
    {S3402_INT_PIN,     MFP_PULL_UP},
#endif

#ifdef  USE_I2S1
    {I2S1_DATA_OUT,     MFP_PULL_DISABLE},
    {I2S1_DATA_IN,      MFP_PULL_DISABLE},
    {I2S1_CLK_PIN,      MFP_PULL_DISABLE},
    {I2S1_WS_PIN,       MFP_PULL_DISABLE},
#endif

    /*mfp low power config*/
    {MFP_PIN_GPIO(72),      MFP_PULL_UP},
    {MFP_PIN_GPIO(73),      MFP_PULL_UP},
    {MFP_PIN_GPIO(253),     MFP_PULL_DISABLE},
    //{MFP_PIN_GPIO(140),   MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(169),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(170),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(198),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(199),     MFP_PULL_DISABLE},

#if defined (CONFIG_COMIP_BOARD_MPLUS_PHONE)
    {MFP_PIN_GPIO(114),     MFP_PULL_DOWN},
#endif

    {MFP_PIN_GPIO(108),     MFP_PULL_DOWN},
    {HARDWARE_BOARD_HIGH_PIN, MFP_PULL_UP},
    {HARDWARE_BOARD_LOW_PIN, MFP_PULL_UP},
    //  {MFP_PIN_GPIO(107),     MFP_PULL_DOWN},
#ifdef CONFIG_TYPE_C_DET_PI5USB30216A
    {MFP_PIN_GPIO(TYPE_C_EN_PIN),  MFP_PULL_DOWN},
    {MFP_PIN_GPIO(TYPE_C_INT_PIN), MFP_PULL_UP},
#endif
//   {MFP_PIN_GPIO(104),     MFP_PULL_DOWN},

#if defined (CONFIG_COMIP_BOARD_MPLUS_PHONE)
    {MFP_PIN_GPIO(102),     MFP_PULL_DOWN},
#endif

#if (defined(CONFIG_COMIP_APB_I2C3))
    {MFP_PIN_GPIO(167),     MFP_PULL_UP},
    {MFP_PIN_GPIO(168),     MFP_PULL_UP},
#else
    {MFP_PIN_GPIO(167),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(168),     MFP_PULL_DISABLE},
#endif
    //{MFP_PIN_GPIO(230),   MFP_PULL_DOWN},
    {MFP_PIN_GPIO(234),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(235),     MFP_PULL_DOWN},
    {MFP_PIN_GPIO(236),     MFP_PULL_DOWN},
    {MFP_PIN_GPIO(237),     MFP_PULL_DOWN},
    {MFP_PIN_GPIO(238),     MFP_PULL_DOWN},
    {MFP_PIN_GPIO(239),     MFP_PULL_UP},
    {MFP_PIN_GPIO(169),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(170),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(171),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(172),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(198),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(199),     MFP_PULL_DISABLE},
    {MFP_PIN_GPIO(201),     MFP_PULL_DOWN},
    {MFP_PIN_GPIO(204),     MFP_PULL_DOWN},
    {MFP_PIN_GPIO(205),     MFP_PULL_DOWN},
#if defined(CONFIG_SENSORS_INV_MPU6880)
    {MFP_PIN_GPIO(INV6880_INT_PIN),     MFP_PULL_UP},
#endif
    {MFP_PIN_GPIO(215),     MFP_PULL_DOWN},
#if defined(CONFIG_SENSORS_IST8303)
    {MFP_PIN_GPIO(IST8303_DRDY_PIN), MFP_PULL_UP},
    {MFP_PIN_GPIO(IST8303_RST_PIN),  MFP_PULL_UP},
#endif

#ifdef CONFIG_SENSORS_BMI055
    {BMI055_INT1_ACC,         MFP_PULL_UP},
#endif

#if defined(CONFIG_SPI_COMIP) || defined(CONFIG_SPI_COMIP_MODULE)
    {SPI2UART_SPI1_SI,       MFP_PULL_UP},
    {SPI2UART_SPI1_SO,       MFP_PULL_UP},
    {SPI2UART_SPI1_CLK,      MFP_PULL_UP},
    {SPI2UART_SPI1_CS,       MFP_PULL_UP},
#endif
#if defined(CONFIG_SERIAL_SC16IS7X2) || defined(CONFIG_SERIAL_SC16IS7X2_MODULE)
    {SPI2UART_INT,                MFP_PULL_UP},
    {SPI2UART_RESET,              MFP_PULL_UP},
    {SPI2UART_XTAL1_1P8M_EN,      MFP_PULL_UP},
    //{SPI2UART_VOL_SHIFT_4_BT_EN,  MFP_PULL_UP},
    {SPI2UART_VOL_SHIFT_4_SPI_EN, MFP_PULL_UP},
    {SPI2UART_SPI_CS,             MFP_PULL_UP},
#endif
#ifdef CONFIG_LIGHT_PROXIMITY_STK3X1X
    {STK3X1X_INT_PIN,             MFP_PULL_UP},
#endif

#if defined (CONFIG_DTT_MODULES_SYSFS)
    //{DB2_RJ11_POWER_ENABLE , MFP_PULL_DOWN},
    //{SYLINCOM_EARLAY_WAKEUP, MFP_PULL_DOWN},
    {DBB2TT_BOOTCTL_PIN, MFP_PULL_DOWN},
    {DBB2TT_ON_PIN ,   MFP_PULL_DOWN},
    {DBB2TT_HOSTRSTN_IN_PIN,   MFP_PULL_UP},
    {DBB2ZY_SW_EN_PIN,   MFP_PULL_UP},
    {TT_DETECT_PIN,   MFP_PULL_UP},
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {DBB2REC_SW_IN_PIN,   MFP_PULL_UP},
#endif

#endif

#ifdef CONFIG_USB_SERIAL_ADHOC
    {DBB2ADHOC_POWER_EN_PIN, MFP_PULL_DOWN},
#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI) || defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {AW9523_KEY_RST,        MFP_PULL_UP},
    {AW9523_KEY_INT,        MFP_PULL_UP},
    {RLED_CTL1_PIN,         MFP_PULL_DOWN},
#endif

    {BAT_LTC2DBB_VALID1_PIN , MFP_PULL_UP},
    {BAT_LTC2DBB_VALID2_PIN , MFP_PULL_UP},
};

#ifdef CONFIG_BAT_ID_BQ2022A
static struct mfp_pin_cfg comip_mfp_cfg1[] = {
    {BAT_ID_BQ2022A_PIN,            MFP_PIN_MODE_GPIO},
};
static struct mfp_pull_cfg comip_mfp_pull_cfg1[] = {
    {BAT_ID_BQ2022A_PIN,        MFP_PULL_UP},
    {MFP_PIN_GPIO(230),     MFP_PULL_DOWN},
};

static struct mfp_pin_cfg comip_mfp_cfg2[] = {
    {BAT_ID_BQ2022A_PINEOC,            MFP_PIN_MODE_GPIO},
};
static struct mfp_pull_cfg comip_mfp_pull_cfg2[] = {
    {BAT_ID_BQ2022A_PINEOC,    MFP_PULL_UP},
    {MFP_PIN_GPIO(233),        MFP_PULL_DISABLE},
};
#endif

static struct mfp_ds_cfg comip_ds_cfg[] = {
    {MFP_PIN_CTRL_MMC0CLK,  MFP_DS_8MA},
    {MFP_PIN_CTRL_MMC0CMD,  MFP_DS_6MA},
    {MFP_PIN_CTRL_MMC0D0,   MFP_DS_6MA},
    {MFP_PIN_CTRL_MMC0D1,   MFP_DS_6MA},
    {MFP_PIN_CTRL_MMC0D2,   MFP_DS_6MA},
    {MFP_PIN_CTRL_MMC0D3,   MFP_DS_6MA},
};

#if defined(CONFIG_GPIO_PCA953X)
static struct mfp_pin_cfg comip_mfp_cfg_4_tca6424a_4_hp[] = {
    {MFP_PIN_GPIO(123), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(124), MFP_PIN_MODE_GPIO},
    //{MFP_PIN_GPIO(137), MFP_PIN_MODE_GPIO},
    //{MFP_PIN_GPIO(58), MFP_PIN_MODE_GPIO},
};
static struct mfp_pull_cfg comip_mfp_pull_cfg_4_tca6424a_4_hp[] = {
    {MFP_PIN_GPIO(123), MFP_PULL_UP},
    {MFP_PIN_GPIO(124), MFP_PULL_UP},
    //{MFP_PIN_GPIO(137), MFP_PULL_UP},
    //{MFP_PIN_GPIO(58), MFP_PULL_UP},
};
//==================================================
static struct mfp_pin_cfg comip_mfp_cfg_4_tca6424a_4_pad[] = {
    {MFP_PIN_GPIO(139), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(57), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(137), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(58), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(131), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(59), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(129), MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(46), MFP_PIN_MODE_GPIO},
};
static struct mfp_pull_cfg comip_mfp_pull_cfg_4_tca6424a_4_pad[] = {
    {MFP_PIN_GPIO(139), MFP_PULL_UP},
    {MFP_PIN_GPIO(57), MFP_PULL_UP},
    {MFP_PIN_GPIO(137), MFP_PULL_UP},
    {MFP_PIN_GPIO(58), MFP_PULL_UP},
    {MFP_PIN_GPIO(131), MFP_PULL_UP},
    {MFP_PIN_GPIO(59), MFP_PULL_UP},
    {MFP_PIN_GPIO(129), MFP_PULL_UP},
    {MFP_PIN_GPIO(46), MFP_PULL_UP},
};
#endif
static void __init comip_init_mfp(void)
{
    comip_mfp_config_array(comip_mfp_cfg, ARRAY_SIZE(comip_mfp_cfg));
    comip_mfp_config_pull_array(comip_mfp_pull_cfg, ARRAY_SIZE(comip_mfp_pull_cfg));
    comip_mfp_config_ds_array(comip_ds_cfg, ARRAY_SIZE(comip_ds_cfg));

#ifdef CONFIG_BAT_ID_BQ2022A
    if (cpu_is_lc1860_eco1() || cpu_is_lc1860_eco2()) {
        comip_mfp_config_array(comip_mfp_cfg2, ARRAY_SIZE(comip_mfp_cfg2));
        comip_mfp_config_pull_array(comip_mfp_pull_cfg2, ARRAY_SIZE(comip_mfp_pull_cfg2));
    } else {
        comip_mfp_config_array(comip_mfp_cfg1, ARRAY_SIZE(comip_mfp_cfg1));
        comip_mfp_config_pull_array(comip_mfp_pull_cfg1, ARRAY_SIZE(comip_mfp_pull_cfg2));
    }
#endif

#if defined(CONFIG_GPIO_PCA953X)
        comip_mfp_config_array(comip_mfp_cfg_4_tca6424a_4_hp,
                               ARRAY_SIZE(comip_mfp_cfg_4_tca6424a_4_hp));
        comip_mfp_config_pull_array(comip_mfp_pull_cfg_4_tca6424a_4_hp,
                                    ARRAY_SIZE(comip_mfp_pull_cfg_4_tca6424a_4_hp));
        printk("[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
#endif
}

static struct mfp_gpio_cfg comip_init_mfp_lp_gpio_cfg[] = {
    /* Power */
    {DBB2EX_5V_EN_PIN,    MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {DBB2OTG_EN_PIN,      MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_HIGH},
    {DBB2VTT4V_EN_PIN,    MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {DBB2_BUCK3V3_EN_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_HIGH},
    {DBB2DAC_PWR_EN_PIN,  MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_HIGH},
    {DBB2RF_PWRCTL1_PIN,  MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_HIGH},
    {DBB2VEX1_5V_EN_PIN,  MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {DBB2VEX2_5V_EN_PIN,  MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {DBB2RF_SHIFT_EN_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {DBB2BDS_PP1S_EN_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {DBB2MINIPCIE_VBUS_PIN,  MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},

    //{MFP_PIN_GPIO(117),     MFP_GPIO_INPUT},
    //{MFP_PIN_GPIO(116),     MFP_GPIO_INPUT},
#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
    {SM_PTT1,                          MFP_GPIO_INPUT},
#endif

#if defined(CONFIG_FAN_PWM)
    {DBB2FAN_TACH_PIN,     MFP_GPIO_INPUT},
#endif
    {SWITCH1_GPIO_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {SWITCH2_GPIO_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {SWITCH3_GPIO_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {SWITCH4_GPIO_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},

#ifdef CONFIG_COMIP_BOARD_MPLUS_V2_MINI
    {SWITCH5_GPIO_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
    {SWITCH5_ENABLE_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_LOW},
#endif

    {FM23_RST_N_PIN,   MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_HIGH},
    {FM23_MCLK_EN_PIN, MFP_GPIO_OUTPUT,  MFP_GPIO_VALUE_HIGH},

    {MFP_PIN_GPIO(109),     MFP_GPIO_INPUT},
    {MFP_PIN_GPIO(108),     MFP_GPIO_INPUT},
//   {MFP_PIN_GPIO(107),     MFP_GPIO_INPUT},
//    {MFP_PIN_GPIO(104),     MFP_GPIO_INPUT},
    {MFP_PIN_GPIO(102),     MFP_GPIO_INPUT},
    //{MFP_PIN_GPIO(197),       MFP_GPIO_OUTPUT,        MFP_GPIO_VALUE_LOW},
    //{MFP_PIN_GPIO(225),       MFP_GPIO_OUTPUT,        MFP_GPIO_VALUE_LOW},
    {MFP_PIN_GPIO(135),     MFP_GPIO_INPUT},
    {HARDWARE_DEVICE_PIN,   MFP_GPIO_INPUT},
    {HARDWARE_BOARD_HIGH_PIN, MFP_GPIO_INPUT},
    {HARDWARE_BOARD_HIGH_PIN, MFP_GPIO_INPUT},
};

static void __init comip_init_gpio_lp(void)
{
    comip_gpio_config_array(comip_init_mfp_lp_gpio_cfg, ARRAY_SIZE(comip_init_mfp_lp_gpio_cfg));
}


#if defined(CONFIG_I2C_COMIP) || defined(CONFIG_I2C_COMIP_MODULE)
#if defined(CONFIG_COMIP_LC1160)
static struct pmic_power_module_map lc1160_power_module_map[] = {
    {PMIC_DLDO3,    PMIC_POWER_SDIO,        0,  1},
    //{PMIC_ALDO14,   PMIC_POWER_SDIO,        1,  0},
    {PMIC_ALDO14,   PMIC_POWER_SDIO,        1,  1},
    {PMIC_DLDO4,    PMIC_POWER_USIM,        0,  0},
    {PMIC_DLDO5,    PMIC_POWER_USIM,        1,  0},
    {PMIC_DLDO6,    PMIC_POWER_USB,     0,  0},
    {PMIC_DLDO7,    PMIC_POWER_LCD_CORE,        0,  0},
    {PMIC_DLDO8,    PMIC_POWER_TOUCHSCREEN,     0,  1},
    {PMIC_DLDO9,    PMIC_POWER_CAMERA_CORE,     0,  0},
    {PMIC_DLDO9,    PMIC_POWER_CAMERA_CORE,     1,  0},
    {PMIC_DLDO10,   PMIC_POWER_CAMERA_IO,       0,  0},
    {PMIC_DLDO10,   PMIC_POWER_CAMERA_IO,       1,  0},
    {PMIC_DLDO11,   PMIC_POWER_CAMERA_AF_MOTOR,     0,  1},
    {PMIC_ALDO7,    PMIC_POWER_CAMERA_ANALOG,       0,  0},
    {PMIC_ALDO7,    PMIC_POWER_CAMERA_ANALOG,       1,  0},
    {PMIC_ALDO10,   PMIC_POWER_LCD_IO,      0,  0},
    {PMIC_ALDO10,   PMIC_POWER_TOUCHSCREEN_IO,      0,  0},
    {PMIC_ALDO10,   PMIC_POWER_CAMERA_CSI_PHY,      0,  0},
    {PMIC_ALDO10,   PMIC_POWER_KEYPAD_I2C,      0,  0},
    {PMIC_ALDO12,   PMIC_POWER_USB,         1,  0},
    {PMIC_ISINK3,   PMIC_POWER_VIBRATOR,        0,  0},
    {PMIC_ALDO13,   PMIC_POWER_USB_HSIC,  1,      1}
};

static struct pmic_power_ctrl_map lc1160_power_ctrl_map[] = {
    {PMIC_ALDO3,    PMIC_POWER_CTRL_REG,    PMIC_POWER_CTRL_GPIO_ID_NONE,   2850},
    //{PMIC_ALDO4,  PMIC_POWER_CTRL_REG,    PMIC_POWER_CTRL_GPIO_ID_NONE,   2850},
    {PMIC_ALDO8,    PMIC_POWER_CTRL_REG,    PMIC_POWER_CTRL_GPIO_ID_NONE,   2850},
    {PMIC_ALDO12,   PMIC_POWER_CTRL_REG,    PMIC_POWER_CTRL_GPIO_ID_NONE,   1800},
    //{PMIC_ALDO14,   PMIC_POWER_CTRL_REG,    PMIC_POWER_CTRL_GPIO_ID_NONE,   2850},
    {PMIC_ALDO14,   PMIC_POWER_CTRL_REG,    PMIC_POWER_CTRL_GPIO_ID_NONE,   3300},
    {PMIC_ISINK1,   PMIC_POWER_CTRL_MAX,    PMIC_POWER_CTRL_GPIO_ID_NONE,   10},
    {PMIC_ISINK2,   PMIC_POWER_CTRL_MAX,    PMIC_POWER_CTRL_GPIO_ID_NONE,   60},
    {PMIC_ISINK3,   PMIC_POWER_CTRL_MAX,    PMIC_POWER_CTRL_GPIO_ID_NONE,   80},
};

static struct pmic_reg_st lc1160_init_regs[] = {
    /* RF power register could be write by SPI &IIC */
    {LC1160_REG_SPICR, 0x01, LC1160_REG_BITMASK_SPI_IIC_EN},
    /* ALDO3 enable */
    {LC1160_REG_LDOA3CR, 0x01, LC1160_REG_BITMASK_LDOA3EN},
    /* ALDO2 enter ECO mode when sleep */
    {LC1160_REG_LDOA2CR, 0x01, LC1160_REG_BITMASK_LDOA2SLP},
    /*DCDC9 disable when sleep */
    {LC1160_REG_DC9OVS1, 0x00, LC1160_REG_BITMASK_DC9OVS1_DC9EN},
    /* ALDO1/4/5/6/7/8/9/10/11/12 disable when sleep */
    {LC1160_REG_LDOA_SLEEP_MODE1, 0x00, LC1160_REG_BITMASK_LDOA5_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE1, 0x00, LC1160_REG_BITMASK_LDOA6_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE2, 0x00, LC1160_REG_BITMASK_LDOA1_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE2, 0x00, LC1160_REG_BITMASK_LDOA4_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE2, 0x00, LC1160_REG_BITMASK_LDOA7_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE2, 0x00, LC1160_REG_BITMASK_LDOA8_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE3, 0x00, LC1160_REG_BITMASK_LDOA9_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE3, 0x00, LC1160_REG_BITMASK_LDOA10_ALLOW_IN_SLP},
    //{LC1160_REG_LDOA_SLEEP_MODE3, 0x00, LC1160_REG_BITMASK_LDOA11_ALLOW_IN_SLP},
    {LC1160_REG_LDOA_SLEEP_MODE3, 0x00, LC1160_REG_BITMASK_LDOA12_ALLOW_IN_SLP},
    /* DLDO1/2 enter ECO mode when sleep */
    {LC1160_REG_LDOD1CR, 0x01, LC1160_REG_BITMASK_LDOD1SLP},
    {LC1160_REG_LDOD2CR, 0x01, LC1160_REG_BITMASK_LDOD2SLP},
    {LC1160_REG_LDOD4CR, 0x01, LC1160_REG_BITMASK_LDOD4SLP},
    {LC1160_REG_LDOD5CR, 0x01, LC1160_REG_BITMASK_LDOD5SLP},
    /* DLDO6/7/8/9/10/11/ disable when sleep. DLDO3 closed by mmc driver. */
    {LC1160_REG_LDOD_SLEEP_MODE1, 0x00, LC1160_REG_BITMASK_LDOD6_ALLOW_IN_SLP},
    {LC1160_REG_LDOD_SLEEP_MODE1, 0x00, LC1160_REG_BITMASK_LDOD7_ALLOW_IN_SLP},
    {LC1160_REG_LDOD_SLEEP_MODE1, 0x00, LC1160_REG_BITMASK_LDOD8_ALLOW_IN_SLP},
    {LC1160_REG_LDOD_SLEEP_MODE2, 0x00, LC1160_REG_BITMASK_LDOD9_ALLOW_IN_SLP},
    //{LC1160_REG_LDOD_SLEEP_MODE2, 0x00, LC1160_REG_BITMASK_LDOD10_ALLOW_IN_SLP},
    {LC1160_REG_LDOD_SLEEP_MODE2, 0x00, LC1160_REG_BITMASK_LDOD11_ALLOW_IN_SLP},
    /* Current sink for LCD backlight function selection: used for LCD backlight */
    {LC1160_REG_INDDIM, 0x00, LC1160_REG_BITMASK_DIMEN},
    /* ALDO5 0.95V, ALDO6 1.8V, BUCK7 power on */
    {LC1160_REG_LDOA5CR, 0xc4, 0xff},
    {LC1160_REG_LDOA6CR, 0xcd, 0xff},
    {LC1160_REG_LDOA11CR, 0xcd, 0xff},  // modify for by zk for fingerprint 1.8v power
    {LC1160_REG_DC7OVS0, 0x5a, 0xff},
};

static struct lc1160_pmic_platform_data lc1160_pmic_info = {
    .irq_gpio = mfp_to_gpio(LC1160_INT_PIN),
    .ctrl_map = lc1160_power_ctrl_map,
    .ctrl_map_num = ARRAY_SIZE(lc1160_power_ctrl_map),
    .module_map = lc1160_power_module_map,
    .module_map_num = ARRAY_SIZE(lc1160_power_module_map),
    .init_regs = lc1160_init_regs,
    .init_regs_num = ARRAY_SIZE(lc1160_init_regs),
};

static struct lc1160_platform_data i2c_lc1160_info = {
    .flags = LC1160_FLAGS_DEVICE_CHECK,
    .pmic_data = &lc1160_pmic_info,
};

#endif

static ssize_t virtual_key_show(struct kobject *kobj,
                                struct kobj_attribute *attr, char *buf)
{
#if defined(CONFIG_TOUCHSCREEN_FT5X06)
    /**720p**/
    return sprintf(buf,
                   __stringify(EV_KEY) ":" __stringify(KEY_MENU) ":160:1342:100:90"
                   ":" __stringify(EV_KEY) ":" __stringify(KEY_HOME) ":360:1342:100:90"
                   ":" __stringify(EV_KEY) ":" __stringify(KEY_BACK) ":570:1342:100:90"
                   "\n");
#else
    /**Set default value, have no use**/
    return sprintf(buf,
                   __stringify(EV_KEY) ":" __stringify(KEY_MENU) ":0:1999:100:60"
                   ":" __stringify(EV_KEY) ":" __stringify(KEY_HOME) ":0:1999:100:60"
                   ":" __stringify(EV_KEY) ":" __stringify(KEY_BACK) ":0:1999:100:60"
                   "\n");
#endif
}

static struct kobj_attribute ts_virtual_keys_attr = {
    .attr = {
#if defined(CONFIG_TOUCHSCREEN_FT5X06)
        .name = "virtualkeys.ft5x06",
#else
        .name = "virtualkeys.lc186x-default",
#endif
        .mode = S_IRUGO,
    },
    .show = virtual_key_show,
};

static struct attribute *virtual_key_attributes[] = {
    &ts_virtual_keys_attr.attr,
    NULL
};

static struct attribute_group virtual_key_group = {
    .attrs = virtual_key_attributes
};

static void __init comip_init_ts_virtual_key(void)
{
    struct kobject *properties_kobj;
    int ret = 0;

    properties_kobj = kobject_create_and_add("board_properties", NULL);
    if (properties_kobj)
        ret = sysfs_create_group(properties_kobj, &virtual_key_group);
    if (ret < 0)
        printk("Create virtual key properties failed!\n");
}

/*i2c gpio set for LC186x touchscreen*/
static struct mfp_pin_cfg comip_mfp_cfg_i2c_2[] = {
    /* I2C2. */
    {MFP_PIN_GPIO(163),     MFP_PIN_MODE_1},
    {MFP_PIN_GPIO(164),     MFP_PIN_MODE_1},
};

static struct mfp_pin_cfg comip_mfp_cfg_gpio[] = {
    /* GPIO. */
    {MFP_PIN_GPIO(163),     MFP_PIN_MODE_GPIO},
    {MFP_PIN_GPIO(164),     MFP_PIN_MODE_GPIO},
};

static int ts_gpio[] = {MFP_PIN_GPIO(163), MFP_PIN_GPIO(164)};

static int ts_set_i2c_to_gpio(void)
{
    int i;
    int retval;

    comip_mfp_config_array(comip_mfp_cfg_gpio, ARRAY_SIZE(comip_mfp_cfg_gpio));
    for (i = 0; i < ARRAY_SIZE(ts_gpio); i++) {
        retval = gpio_request(ts_gpio[i], "ts_i2c");
        if (retval) {
            pr_err("%s: Failed to get i2c gpio %d. Code: %d.",
                   __func__, ts_gpio[i], retval);
            return retval;
        }
        retval = gpio_direction_output(ts_gpio[i], 0);
        if (retval) {
            pr_err("%s: Failed to setup attn gpio %d. Code: %d.",
                   __func__, ts_gpio[i], retval);
            gpio_free(ts_gpio[i]);
        }
        gpio_free(ts_gpio[i]);
    }
    return 0;
}

#if defined(CONFIG_TOUCHSCREEN_FT5X06)
static int ft5x06_rst = FT5X06_RST_PIN;
static int ft5x06_i2c_power(struct device *dev, unsigned int vdd)
{
    /* Set power. */
    if (vdd) {
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN_IO, 0, PMIC_POWER_VOLTAGE_ENABLE);
    } else {
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN_IO, 0, PMIC_POWER_VOLTAGE_DISABLE);
    }

    return 0;
}

static int ft5x06_ic_power(struct device *dev, unsigned int vdd)
{
    int retval = 0;
    int gpio_rst = FT5X06_RST_PIN;
    /* Set power. */
    if (vdd) {
        /*add for power on sequence*/
        retval = gpio_request(gpio_rst, "ft5x06_ts_rst");
        if (retval) {
            pr_err("ft5x06_ts request rst error\n");
            return retval;
        }
        gpio_direction_output(gpio_rst, 0);
        msleep(2);
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN, 0, PMIC_POWER_VOLTAGE_ENABLE);
        msleep(2);
        gpio_direction_output(gpio_rst, 1);
        gpio_free(gpio_rst);
        comip_mfp_config_array(comip_mfp_cfg_i2c_2, ARRAY_SIZE(comip_mfp_cfg_i2c_2));

    } else {
        retval = gpio_request(gpio_rst, "ft5x06_ts_rst");
        if (retval) {
            pr_err("ft5x06_ts request rst error\n");
            return retval;
        }
        gpio_direction_output(gpio_rst, 0);
        msleep(2);
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN, 0, PMIC_POWER_VOLTAGE_DISABLE);
        gpio_direction_input(gpio_rst);
        gpio_free(gpio_rst);

        //ts_set_i2c_to_gpio();
    }
    return 0;
}

static int ft5x06_reset(struct device *dev)
{
    gpio_request(ft5x06_rst, "ft5x06 Reset");
    gpio_direction_output(ft5x06_rst, 1);
    msleep(2);
    gpio_direction_output(ft5x06_rst, 0);
    msleep(10);
    gpio_direction_output(ft5x06_rst, 1);
    msleep(200);
    gpio_free(ft5x06_rst);

    return 0;
}

static struct ft5x06_info comip_i2c_ft5x06_info = {
    .reset = ft5x06_reset,
    .power_i2c = ft5x06_i2c_power,
    .power_ic = ft5x06_ic_power,
    .reset_gpio = mfp_to_gpio(FT5X06_RST_PIN),
    .irq_gpio = mfp_to_gpio(FT5X06_INT_PIN),
    .power_i2c_flag = 1,
    .power_ic_flag = 1,
    .max_scrx = 272,
    .max_scry = 340,
    .virtual_scry = 1450,
    .max_points = 10,
};
#endif
#ifdef CONFIG_LIGHT_PROXIMITY_STK3X1X
static struct stk3x1x_platform_data stk3x1x_data = {
    .state_reg = 0x0, /* disable all */
    .psctrl_reg = 0x31, /* ps_persistance=1, ps_gain=64X, PS_IT=0.391ms */
    .alsctrl_reg = 0x38, /* als_persistance=1, als_gain=64X, ALS_IT=50ms */
    .ledctrl_reg = 0xFF, /* 100mA IRDR, 64/64 LED duty */
    .wait_reg = 0x07, /* 50 ms */
    .ps_thd_h = 1700,
    .ps_thd_l = 1500,
    .int_pin = mfp_to_gpio(STK3X1X_INT_PIN),
    .transmittance = 500,
};
#endif

#ifdef CONFIG_LIGHT_PROXIMITY_LTR55XALS
static struct ltr55x_platform_data ltr55x_pdata = {
    .irq_gpio = mfp_to_gpio(LTR55XALS_INT_PIN),
};
#endif

#if defined(CONFIG_TOUCHSCREEN_S3402)
static int s3402_rst = S3402_RST_PIN;
static int s3402_reset(struct device *dev)
{
    gpio_request(s3402_rst, "s3402 Reset");
    gpio_direction_output(s3402_rst, 1);
    msleep(10);
    gpio_direction_output(s3402_rst, 0);
    msleep(10);
    gpio_direction_output(s3402_rst, 1);
    msleep(200);
    gpio_free(s3402_rst);
    return 0;
}
static int s3402_i2c_power(struct device *dev, unsigned int vdd)
{
    if (vdd) {
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN_IO, 0, PMIC_POWER_VOLTAGE_ENABLE);
    } else {
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN_IO, 0, PMIC_POWER_VOLTAGE_DISABLE);
    }
    return 0;
}
static int s3402_ic_power(struct device *dev, unsigned int vdd)
{
    int retval;

    if (vdd) {
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN, 0, PMIC_POWER_VOLTAGE_ENABLE);
        msleep(10);
        comip_mfp_config_array(comip_mfp_cfg_i2c_2, ARRAY_SIZE(comip_mfp_cfg_i2c_2));
        msleep(10);
    } else {
        retval = gpio_request(s3402_rst, "s3402 Reset");
        if (retval) {
            pr_err("s3402 request rst error\n");
            return retval;
        }
        gpio_direction_output(s3402_rst, 0);
        msleep(2);
        pmic_voltage_set(PMIC_POWER_TOUCHSCREEN, 0, PMIC_POWER_VOLTAGE_DISABLE);
        gpio_direction_input(s3402_rst);
        gpio_free(s3402_rst);

        ts_set_i2c_to_gpio();
    }
    return 0;
}

static struct s3402_ts_info comip_i2c_s3402_info = {
    .reset = s3402_reset,
    .power_i2c = s3402_i2c_power,
    .power_ic = s3402_ic_power,
    .irq_gpio = S3402_INT_PIN,
//  .gpio_rst = S3402_RST_PIN,
    .power_i2c_flag = 1,
    .power_ic_flag = 1,

    .max_scrx = 720,
    .max_scry = 1280,

    .virtual_scry = 2200,
    .max_points = 5,
};
#endif


#if defined (CONFIG_SENSORS_AK09911)
static int addr_offset(void)
{
    if (comip_board_info_get(NULL) == LTE26047M10) {
        return 0x0c;
    } else {
        if (comip_board_info_get(NULL) > LTE26047M10) {
            return 0x0d;
        } else {
            return 0;
        }
    }
}
static char layout_offset(void)
{
    if (comip_board_info_get(NULL) >= LTE26047M12) {
        return 0x06;
    } else {
        return 0x05;
    }
}
static struct akm09911_platform_data akm09911_pdata = {
    .layout = layout_offset,
    .addr_amend = addr_offset,
};
#endif

#ifdef CONFIG_SENSORS_LSM330
static struct lsm330_acc_platform_data lsm330_acc_data = {
    .fs_range = LSM330_ACC_G_2G,
#ifdef CONFIG_SENSORS_XYZ
    .axis_map_x = 0,
    .axis_map_y = 1,
    .axis_map_z = 2,
#endif
#ifdef CONFIG_SENSORS_YXZ
    .axis_map_x = 1,
    .axis_map_y = 0,
    .axis_map_z = 2,
#endif
#ifdef CONFIG_SENSORS_IOO
    .negate_x = 1,
    .negate_y = 0,
    .negate_z = 0,
#endif
#ifdef CONFIG_SENSORS_IOI
    .negate_x = 1,
    .negate_y = 0,
    .negate_z = 1,
#endif
    .poll_interval = 10,
    .min_interval = LSM330_ACC_MIN_POLL_PERIOD_MS,
};

static struct lsm330_gyr_platform_data lsm330_gyr_data = {
    .fs_range = LSM330_GYR_FS_2000DPS,
    .axis_map_x = 1,
    .axis_map_y = 0,
    .axis_map_z = 2,
    .negate_x = 1,
    .negate_y = 0,
    .negate_z = 0,
    .poll_interval = 10,
    .min_interval = LSM330_GYR_MIN_POLL_PERIOD_MS, /* 2ms */
};
#endif
#ifdef CONFIG_SENSORS_INV_MPU6880
static int mpuirq_init(void)
{
    int ret = 0;

    pr_info("*** MPU START *** mpuirq_init...\n");

    /* MPU-IRQ assignment */
    ret = gpio_request(INV6880_INT_PIN, "mpu6880");
    if (ret < 0) {
        pr_err("%s: gpio_request failed %d\n", __func__, ret);
        return -1;
    }

    ret = gpio_direction_input(INV6880_INT_PIN);
    if (ret < 0) {
        pr_err("%s: gpio_direction_input failed %d\n", __func__, ret);
        gpio_free(INV6880_INT_PIN);
        return -1;
    }
    pr_info("*** MPU END *** mpuirq_init...\n");
    return 0;

}

static __s8  mpu_orientation_pad[9] = {//pad
    -1, 0, 0,
    0, 1, 0,
    0, 0, -1
};

static __s8  mpu_orientation_hp[9] = {//hp
    1, 0, 0,
    0, -1, 0,
    0, 0, -1
};

static __s8  mpu_orientation_nh[9] = {//normal hp
    1, 0, 0,
    0, -1, 0,
    0, 0, -1
};

static void mpu_gyro_set_layout(struct mpu_platform_data *pdata)
{
    if (MPLUS_BOARD_PAD == HARDWARE_DEVICE_ID) {
        printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
        printk(KERN_INFO "board info: MPLUS_BOARD_PAD == HARDWARE_DEVICE_ID\n");
        memcpy(pdata->orientation,
               mpu_orientation_pad,
               ARRAY_SIZE(mpu_orientation_pad));
    } else {
        if (MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID) {
            printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
            printk(KERN_INFO "board info: MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID\n");
            memcpy(pdata->orientation,
                   mpu_orientation_nh,
                   ARRAY_SIZE(mpu_orientation_nh));
        } else {
            if (MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID) {
                printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
                printk(KERN_INFO "board info: MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID\n");
                memcpy(pdata->orientation,
                       mpu_orientation_hp,
                       ARRAY_SIZE(mpu_orientation_hp));
            } else {
                printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
                printk(KERN_INFO "board info: MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID\n");
                memcpy(pdata->orientation,
                       mpu_orientation_hp,
                       ARRAY_SIZE(mpu_orientation_hp));
            }
        }
    }
}

static struct mpu_platform_data mpu_gyro_data = {
    .int_config  = 0x10,
    .level_shifter = 0,
    .sec_slave_type = SECONDARY_SLAVE_TYPE_NONE,
    .key = {
        221, 22, 205, 7,   217, 186, 151, 55,
        206, 254, 35, 144, 225, 102,  47, 50
    },
    .irq_init = mpuirq_init,
    .set_layout = mpu_gyro_set_layout,
};
#endif

#ifdef CONFIG_SENSORS_BMI055
static struct bmi055_platform_data bmi055_pdata = {
    .gpio_int1 = BMI055_INT1_ACC,
    .position = 7,
};
#endif

#ifdef CONFIG_SENSORS_IST8303
static __s8  ist8303_orientation_pad[9] = {//pad
    1, 0, 0,
    0, -1, 0,
    0, 0, 1
};

static __s8  ist8303_orientation_hp[9] = {//hp
    -1, 0, 0,
    0, 1, 0,
    0, 0, 1
};

static __s8  ist8303_orientation_nh[9] = {//normal hp
    -1, 0, 0,
    0, 1, 0,
    0, 0, 1
};

static void ist8303_set_layout(struct ist8303_platform_data *pdata)
{
    //if (MPLUS_BOARD_PAD == HARDWARE_DEVICE_ID) {
    if (1) {
        printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
        printk(KERN_INFO "board info: MPLUS_BOARD_PAD == HARDWARE_DEVICE_ID\n");
        memcpy(pdata->orientation,
               ist8303_orientation_pad,
               ARRAY_SIZE(ist8303_orientation_pad));
    } else {
        if (MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID) {
            printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
            printk(KERN_INFO "board info: MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID\n");
            memcpy(pdata->orientation,
                   ist8303_orientation_nh,
                   ARRAY_SIZE(ist8303_orientation_nh));
        } else {
            if (MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID) {
                printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
                printk(KERN_INFO "board info: MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID\n");
                memcpy(pdata->orientation,
                       ist8303_orientation_hp,
                       ARRAY_SIZE(ist8303_orientation_hp));
            } else {
                printk(KERN_INFO "[%s_INFO][%04d] [%s]\n", __FILE__, __LINE__, __func__);
                printk(KERN_INFO "board info: MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID\n");
                memcpy(pdata->orientation,
                       ist8303_orientation_hp,
                       ARRAY_SIZE(ist8303_orientation_hp));
            }
        }
    }
}

static struct ist8303_platform_data ist8303_pdata = {
    .set_layout = ist8303_set_layout,
};
#endif

#if defined(CONFIG_GPIO_PCA953X)
static struct pca953x_platform_data tca6424a_expander_0_pdata;
static struct pca953x_platform_data tca6424a_expander_1_pdata;
static struct pca953x_platform_data tca6424a_expander_2_pdata;
static struct pca953x_platform_data tca6424a_expander_3_pdata;

#define TCA6424A_EXPENDER_0_GPIO_BASE (IIC2GPIO_BASE_0) //256
#define TCA6424A_EXPENDER_0_IRQ_BASE (IRQ_GPIO(TCA6424A_EXPENDER_0_GPIO_BASE)) //394
#define TCA6424A_EXPENDER_1_GPIO_BASE (IIC2GPIO_BASE_1)
#define TCA6424A_EXPENDER_1_IRQ_BASE (IRQ_GPIO(TCA6424A_EXPENDER_1_GPIO_BASE))
#define TCA6424A_EXPENDER_2_GPIO_BASE (IIC2GPIO_BASE_2)
#define TCA6424A_EXPENDER_2_IRQ_BASE (IRQ_GPIO(TCA6424A_EXPENDER_2_GPIO_BASE))
#define TCA6424A_EXPENDER_3_GPIO_BASE (IIC2GPIO_BASE_3)
#define TCA6424A_EXPENDER_3_IRQ_BASE (IRQ_GPIO(TCA6424A_EXPENDER_3_GPIO_BASE))

enum tca6424a_expander_pins {
    TCA6424A_P00 = 0,
    TCA6424A_P01,
    TCA6424A_P02,
    TCA6424A_P03,
    TCA6424A_P04,
    TCA6424A_P05,
    TCA6424A_P06,
    TCA6424A_P07,
    TCA6424A_P10 = 8,
    TCA6424A_P11,
    TCA6424A_P12,
    TCA6424A_P13,
    TCA6424A_P14,
    TCA6424A_P15,
    TCA6424A_P16,
    TCA6424A_P17,
    TCA6424A_P20 = 16,
    TCA6424A_P21,
    TCA6424A_P22,
    TCA6424A_P23,
    TCA6424A_P24,
    TCA6424A_P25,
    TCA6424A_P26,
    TCA6424A_P27 = 23
};

static const char * const tca6424a_expander_0_names[] = {
    [TCA6424A_P00] = "TCA6424A_0_P00",
    [TCA6424A_P01] = "TCA6424A_0_P01",
    [TCA6424A_P02] = "TCA6424A_0_P02",
    [TCA6424A_P03] = "TCA6424A_0_P03",
    [TCA6424A_P04] = "TCA6424A_0_P04",
    [TCA6424A_P05] = "TCA6424A_0_P05",
    [TCA6424A_P06] = "TCA6424A_0_P06",
    [TCA6424A_P07] = "TCA6424A_0_P07",
    [TCA6424A_P10] = "TCA6424A_0_P10",
    [TCA6424A_P11] = "TCA6424A_0_P11",
    [TCA6424A_P12] = "TCA6424A_0_P12",
    [TCA6424A_P13] = "TCA6424A_0_P13",
    [TCA6424A_P14] = "TCA6424A_0_P14",
    [TCA6424A_P15] = "TCA6424A_0_P15",
    [TCA6424A_P16] = "TCA6424A_0_P16",
    [TCA6424A_P17] = "TCA6424A_0_P17",
    [TCA6424A_P20] = "TCA6424A_0_P20",
    [TCA6424A_P21] = "TCA6424A_0_P21",
    [TCA6424A_P22] = "TCA6424A_0_P22",
    [TCA6424A_P23] = "TCA6424A_0_P23",
    [TCA6424A_P24] = "TCA6424A_0_P24",
    [TCA6424A_P25] = "TCA6424A_0_P25",
    [TCA6424A_P26] = "TCA6424A_0_P26",
    [TCA6424A_P27] = "TCA6424A_0_P27",
};
static const char * const tca6424a_expander_1_names[] = {
    [TCA6424A_P00] = "TCA6424A_1_P00",
    [TCA6424A_P01] = "TCA6424A_1_P01",
    [TCA6424A_P02] = "TCA6424A_1_P02",
    [TCA6424A_P03] = "TCA6424A_1_P03",
    [TCA6424A_P04] = "TCA6424A_1_P04",
    [TCA6424A_P05] = "TCA6424A_1_P05",
    [TCA6424A_P06] = "TCA6424A_1_P06",
    [TCA6424A_P07] = "TCA6424A_1_P07",
    [TCA6424A_P10] = "TCA6424A_1_P10",
    [TCA6424A_P11] = "TCA6424A_1_P11",
    [TCA6424A_P12] = "TCA6424A_1_P12",
    [TCA6424A_P13] = "TCA6424A_1_P13",
    [TCA6424A_P14] = "TCA6424A_1_P14",
    [TCA6424A_P15] = "TCA6424A_1_P15",
    [TCA6424A_P16] = "TCA6424A_1_P16",
    [TCA6424A_P17] = "TCA6424A_1_P17",
    [TCA6424A_P20] = "TCA6424A_1_P20",
    [TCA6424A_P21] = "TCA6424A_1_P21",
    [TCA6424A_P22] = "TCA6424A_1_P22",
    [TCA6424A_P23] = "TCA6424A_1_P23",
    [TCA6424A_P24] = "TCA6424A_1_P24",
    [TCA6424A_P25] = "TCA6424A_1_P25",
    [TCA6424A_P26] = "TCA6424A_1_P26",
    [TCA6424A_P27] = "TCA6424A_1_P27",
};
static const char * const tca6424a_expander_2_names[] = {
    [TCA6424A_P00] = "TCA6424A_2_P00",
    [TCA6424A_P01] = "TCA6424A_2_P01",
    [TCA6424A_P02] = "TCA6424A_2_P02",
    [TCA6424A_P03] = "TCA6424A_2_P03",
    [TCA6424A_P04] = "TCA6424A_2_P04",
    [TCA6424A_P05] = "TCA6424A_2_P05",
    [TCA6424A_P06] = "TCA6424A_2_P06",
    [TCA6424A_P07] = "TCA6424A_2_P07",
    [TCA6424A_P10] = "TCA6424A_2_P10",
    [TCA6424A_P11] = "TCA6424A_2_P11",
    [TCA6424A_P12] = "TCA6424A_2_P12",
    [TCA6424A_P13] = "TCA6424A_2_P13",
    [TCA6424A_P14] = "TCA6424A_2_P14",
    [TCA6424A_P15] = "TCA6424A_2_P15",
    [TCA6424A_P16] = "TCA6424A_2_P16",
    [TCA6424A_P17] = "TCA6424A_2_P17",
    [TCA6424A_P20] = "TCA6424A_2_P20",
    [TCA6424A_P21] = "TCA6424A_2_P21",
    [TCA6424A_P22] = "TCA6424A_2_P22",
    [TCA6424A_P23] = "TCA6424A_2_P23",
    [TCA6424A_P24] = "TCA6424A_2_P24",
    [TCA6424A_P25] = "TCA6424A_2_P25",
    [TCA6424A_P26] = "TCA6424A_2_P26",
    [TCA6424A_P27] = "TCA6424A_2_P27",
};
static const char * const tca6424a_expander_3_names[] = {
    [TCA6424A_P00] = "TCA6424A_3_P00",
    [TCA6424A_P01] = "TCA6424A_3_P01",
    [TCA6424A_P02] = "TCA6424A_3_P02",
    [TCA6424A_P03] = "TCA6424A_3_P03",
    [TCA6424A_P04] = "TCA6424A_3_P04",
    [TCA6424A_P05] = "TCA6424A_3_P05",
    [TCA6424A_P06] = "TCA6424A_3_P06",
    [TCA6424A_P07] = "TCA6424A_3_P07",
    [TCA6424A_P10] = "TCA6424A_3_P10",
    [TCA6424A_P11] = "TCA6424A_3_P11",
    [TCA6424A_P12] = "TCA6424A_3_P12",
    [TCA6424A_P13] = "TCA6424A_3_P13",
    [TCA6424A_P14] = "TCA6424A_3_P14",
    [TCA6424A_P15] = "TCA6424A_3_P15",
    [TCA6424A_P16] = "TCA6424A_3_P16",
    [TCA6424A_P17] = "TCA6424A_3_P17",
    [TCA6424A_P20] = "TCA6424A_3_P20",
    [TCA6424A_P21] = "TCA6424A_3_P21",
    [TCA6424A_P22] = "TCA6424A_3_P22",
    [TCA6424A_P23] = "TCA6424A_3_P23",
    [TCA6424A_P24] = "TCA6424A_3_P24",
    [TCA6424A_P25] = "TCA6424A_3_P25",
    [TCA6424A_P26] = "TCA6424A_3_P26",
    [TCA6424A_P27] = "TCA6424A_3_P27",
};

static int tca6424a_expander_0_device_init(void)
{
    int ret = -1;

    tca6424a_expander_0_pdata.gpio_int = MFP_PIN_GPIO(123);
    tca6424a_expander_0_pdata.gpio_reset = MFP_PIN_GPIO(124);
    printk("[%s_INFO][%04d] [%s] gpio_int=%d gpio_reset=%d\n",
        __FILE__, __LINE__, __func__,
        tca6424a_expander_0_pdata.gpio_int,
        tca6424a_expander_0_pdata.gpio_reset);

    return 0;
}

static int tca6424a_expander_1_device_init(void)
{
    int ret = -1;

    if ((MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID)
        ||(MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID)) {
        tca6424a_expander_1_pdata.gpio_int = MFP_PIN_GPIO(137);
        tca6424a_expander_1_pdata.gpio_reset = MFP_PIN_GPIO(58);
        printk("[%s_INFO][%04d] [%s] board_is_hp gpio_int=%d gpio_reset=%d\n",
               __FILE__, __LINE__, __func__,
               tca6424a_expander_1_pdata.gpio_int,
               tca6424a_expander_1_pdata.gpio_reset);
    } else {
        if (MPLUS_BOARD_PAD == HARDWARE_DEVICE_ID) {
            tca6424a_expander_1_pdata.gpio_int = MFP_PIN_GPIO(137);
            tca6424a_expander_1_pdata.gpio_reset = MFP_PIN_GPIO(58);
            printk("[%s_INFO][%04d] [%s] board_is_pad gpio_int=%d gpio_reset=%d\n",
                   __FILE__, __LINE__, __func__,
                   tca6424a_expander_1_pdata.gpio_int,
                   tca6424a_expander_1_pdata.gpio_reset);
        } else {
            printk(KERN_ERR "[%s_ERR][%04d] [%s]\n", __FILE__, __LINE__, __func__);
            return ret;
        }
    }
    return 0;
}

static int tca6424a_expander_2_device_init(void)
{
    int ret = -1;

    if ((MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID)
        ||(MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID)) {
        tca6424a_expander_2_pdata.gpio_int = MFP_PIN_GPIO(131);
        tca6424a_expander_2_pdata.gpio_reset = MFP_PIN_GPIO(59);
        printk("[%s_INFO][%04d] [%s] board_is_hp gpio_int=%d gpio_reset=%d\n",
               __FILE__, __LINE__, __func__,
               tca6424a_expander_2_pdata.gpio_int,
               tca6424a_expander_2_pdata.gpio_reset);
    } else {
        if (MPLUS_BOARD_PAD == HARDWARE_DEVICE_ID) {
            tca6424a_expander_2_pdata.gpio_int = MFP_PIN_GPIO(131);
            tca6424a_expander_2_pdata.gpio_reset = MFP_PIN_GPIO(59);
            printk("[%s_INFO][%04d] [%s] board_is_pad gpio_int=%d gpio_reset=%d\n",
                   __FILE__, __LINE__, __func__,
                   tca6424a_expander_2_pdata.gpio_int,
                   tca6424a_expander_2_pdata.gpio_reset);
        } else {
            printk(KERN_ERR "[%s_ERR][%04d] [%s]\n", __FILE__, __LINE__, __func__);
            return ret;
        }
    }
    return 0;
}

static int tca6424a_expander_3_device_init(void)
{
    int ret = -1;

    if ((MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID)
        ||(MPLUS_BOARD_EHANCED_PHONE == HARDWARE_DEVICE_ID)) {
        tca6424a_expander_3_pdata.gpio_int = MFP_PIN_GPIO(129);
        tca6424a_expander_3_pdata.gpio_reset = MFP_PIN_GPIO(46);
        printk("[%s_INFO][%04d] [%s] board_is_hp gpio_int=%d gpio_reset=%d\n",
               __FILE__, __LINE__, __func__,
               tca6424a_expander_3_pdata.gpio_int,
               tca6424a_expander_3_pdata.gpio_reset);
    } else {
        if (MPLUS_BOARD_PAD == HARDWARE_DEVICE_ID) {
            tca6424a_expander_3_pdata.gpio_int = MFP_PIN_GPIO(129);
            tca6424a_expander_3_pdata.gpio_reset = MFP_PIN_GPIO(46);
            printk("[%s_INFO][%04d] [%s] board_is_pad gpio_int=%d gpio_reset=%d\n",
                   __FILE__, __LINE__, __func__,
                   tca6424a_expander_3_pdata.gpio_int,
                   tca6424a_expander_3_pdata.gpio_reset);
        } else {
            printk(KERN_ERR "[%s_ERR][%04d] [%s]\n", __FILE__, __LINE__, __func__);
            return ret;
        }
    }
    return 0;
}

static int tca6424a_expander_0_setup(struct i2c_client *client, unsigned gpio,
                                     unsigned ngpio, void *c)
{
    int ret = -1;
    static u8 requested = 0;

    if (0 == requested) {
        ret = gpio_request(tca6424a_expander_0_pdata.gpio_reset,
                           "tca6424a_expander_0_pdata.gpio_reset");
        if (ret) {
            printk("gpio_request failed of GPIO_%d(tca6424a_expander_0_pdata.gpio_reset)\n",
                   tca6424a_expander_0_pdata.gpio_reset);
        } else {
            requested = 1;
            printk("gpio_request success of GPIO_%d(tca6424a_expander_0_pdata.gpio_reset)\n",
                   tca6424a_expander_0_pdata.gpio_reset);
        }
    }

    gpio_direction_output(tca6424a_expander_0_pdata.gpio_reset, 0);
    udelay(200);
    gpio_direction_output(tca6424a_expander_0_pdata.gpio_reset, 1);

    return ret;
}

static int tca6424a_expander_1_setup(struct i2c_client *client, unsigned gpio,
                                     unsigned ngpio, void *c)
{
    int ret = -1;
    static u8 requested = 0;

    if (0 == requested) {
        ret = gpio_request(tca6424a_expander_1_pdata.gpio_reset,
                           "tca6424a_expander_1_pdata.gpio_reset");
        if (ret) {
            printk("gpio_request failed of GPIO_%d(tca6424a_expander_1_pdata.gpio_reset)\n",
                   tca6424a_expander_1_pdata.gpio_reset);
        } else {
            requested = 1;
            printk("gpio_request success of GPIO_%d(tca6424a_expander_1_pdata.gpio_reset)\n",
                   tca6424a_expander_1_pdata.gpio_reset);
        }
    }

    gpio_direction_output(tca6424a_expander_1_pdata.gpio_reset, 0);
    udelay(200);
    gpio_direction_output(tca6424a_expander_1_pdata.gpio_reset, 1);

    return ret;
}


static int tca6424a_expander_2_setup(struct i2c_client *client, unsigned gpio,
                                     unsigned ngpio, void *c)
{
    int ret = -1;
    static u8 requested = 0;

    if (0 == requested) {
        ret = gpio_request(tca6424a_expander_2_pdata.gpio_reset,
                           "tca6424a_expander_2_pdata.gpio_reset");
        if (ret) {
            printk("gpio_request failed of GPIO_%d(tca6424a_expander_2_pdata.gpio_reset)\n",
                   tca6424a_expander_2_pdata.gpio_reset);
        } else {
            requested = 1;
            printk("gpio_request success of GPIO_%d(tca6424a_expander_2_pdata.gpio_reset)\n",
                   tca6424a_expander_2_pdata.gpio_reset);
        }
    }

    gpio_direction_output(tca6424a_expander_2_pdata.gpio_reset, 0);
    udelay(200);
    gpio_direction_output(tca6424a_expander_2_pdata.gpio_reset, 1);

    return ret;
}


static int tca6424a_expander_3_setup(struct i2c_client *client, unsigned gpio,
                                     unsigned ngpio, void *c)
{
    int ret = -1;
    static u8 requested = 0;

    if (0 == requested) {
        ret = gpio_request(tca6424a_expander_3_pdata.gpio_reset,
                           "tca6424a_expander_3_pdata.gpio_reset");
        if (ret) {
            printk("gpio_request failed of GPIO_%d(tca6424a_expander_3_pdata.gpio_reset)\n",
                   tca6424a_expander_3_pdata.gpio_reset);
        } else {
            requested = 1;
            printk("gpio_request success of GPIO_%d(tca6424a_expander_3_pdata.gpio_reset)\n",
                   tca6424a_expander_3_pdata.gpio_reset);
        }
    }

    gpio_direction_output(tca6424a_expander_3_pdata.gpio_reset, 0);
    udelay(200);
    gpio_direction_output(tca6424a_expander_3_pdata.gpio_reset, 1);

    return ret;
}

static struct pca953x_platform_data tca6424a_expander_0_pdata = {
    .gpio_base   = TCA6424A_EXPENDER_0_GPIO_BASE,
    .invert      = 0,
    .irq_base    = TCA6424A_EXPENDER_0_IRQ_BASE,
    .context     = NULL,
    .device_init = tca6424a_expander_0_device_init,
    .setup       = tca6424a_expander_0_setup,
    .teardown    = NULL,
    .names       = tca6424a_expander_0_names,
    .chip_name   = "tca6424a_expander_0",
};

static struct pca953x_platform_data tca6424a_expander_1_pdata = {
    .gpio_base   = TCA6424A_EXPENDER_1_GPIO_BASE,
    .invert      = 0,
    .irq_base    = TCA6424A_EXPENDER_1_IRQ_BASE,
    .context     = NULL,
    .device_init = tca6424a_expander_1_device_init,
    .setup       = tca6424a_expander_1_setup,
    .teardown    = NULL,
    .names       = tca6424a_expander_1_names,
    .chip_name   = "tca6424a_expander_1",
};
static struct pca953x_platform_data tca6424a_expander_2_pdata = {
    .gpio_base   = TCA6424A_EXPENDER_2_GPIO_BASE,
    .invert      = 0,
    .irq_base    = TCA6424A_EXPENDER_2_IRQ_BASE,
    .context     = NULL,
    .device_init = tca6424a_expander_2_device_init,
    .setup       = tca6424a_expander_2_setup,
    .teardown    = NULL,
    .names       = tca6424a_expander_2_names,
    .chip_name   = "tca6424a_expander_2",
};
static struct pca953x_platform_data tca6424a_expander_3_pdata = {
    .gpio_base   = TCA6424A_EXPENDER_3_GPIO_BASE,
    .invert      = 0,
    .irq_base    = TCA6424A_EXPENDER_3_IRQ_BASE,
    .context     = NULL,
    .device_init = tca6424a_expander_3_device_init,
    .setup       = tca6424a_expander_3_setup,
    .teardown    = NULL,
    .names       = tca6424a_expander_3_names,
    .chip_name   = "tca6424a_expander_3",
};

#endif

#if defined(CONFIG_FM23_DSP)
struct fm23_platform_data  fm23_data = {
    .gpio_reset = FM23_RST_N_PIN,
    .gpio_clk_en = FM23_MCLK_EN_PIN,
};
#endif

#if defined(CONFIG_ADC3001_CHIP)
struct adc3001_platform_data  adc3001_pdata = {
    .gpio_reset = ADC3100_RESET_GPIO_PIN,
    .clk_name   = "clkout2_clk",
    .clk_parent_name = "pll1_mclk",
    //.clk_rate   = ADC3001_MCLK_12P288M,
    .clk_rate   = ADC3001_MCLK_11P2896M,
};
#endif

#ifdef CONFIG_TYPE_C_DET_PI5USB30216A
struct pericom_pdata pericom_pdata =  {
    .gpio_int = mfp_to_gpio(TYPE_C_INT_PIN),
    .gpio_en = mfp_to_gpio(TYPE_C_EN_PIN),
};
#endif

#ifdef CONFIG_POWER_DAC_AD5321
struct ad5321_pdata ad5321_pdata =  {
    //.gpio_intb = mfp_to_gpio(MFP_PIN_GPIO(209)),
    .power_mode = 0,//on power 28V; 0~4095 0V~Vdd ;here is 0v
};
#endif

#ifdef CONFIG_LEDS_LM3642
static struct lm3642_platform_data  lm3642_data = {
    .torch_pin = 0x10,//LM3646_TORCH_PIN_ENABLED,//torch_pin
    .strobe_pin = 0x00,//LM3646_TX_PIN_ENABLED ,
    .tx_pin = 0x40,//LM3646_TX_PIN_DISABLED,
};
#endif

#ifdef CONFIG_VIBR_DRV2625
static struct mfp_pin_cfg mfp_cfg_4_drv2625[] = {
    {DRV2625_NRST, MFP_PIN_MODE_GPIO},
    {DRV2625_TRIG, MFP_PIN_MODE_GPIO},
};

static struct mfp_pull_cfg mfp_pull_cfg_4_drv2625[] = {
    {DRV2625_NRST, MFP_PULL_DOWN},
    {DRV2625_TRIG, MFP_PULL_DOWN},
};

static int drv2625_hardware_init(void)
{
    //if (MPLUS_BOARD_GENERAL_PHONE == HARDWARE_DEVICE_ID) {
    if (1) {
        comip_mfp_config_array(mfp_cfg_4_drv2625,
                               ARRAY_SIZE(mfp_cfg_4_drv2625));
        comip_mfp_config_pull_array(mfp_pull_cfg_4_drv2625,
                                    ARRAY_SIZE(mfp_pull_cfg_4_drv2625));
        printk("[%s_INFO][%04d] [%s] gpio init\n", __FILE__, __LINE__, __func__);
        return 0;
    } else {
        printk("[%s_INFO][%04d] [%s] ERROR ??? need to confirm!!!\n", __FILE__, __LINE__, __func__);
        return -1;
    }
}

static struct drv2625_vibrator_platform_data  drv2625_pdata = {
    .gpio_nrst = DRV2625_NRST,
    .gpio_trig = DRV2625_TRIG,
    .hardware_init = drv2625_hardware_init,
};
#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI) || defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
static int aw9523_i2c_power(int onoff)
{
    if (onoff) {
        pmic_voltage_set(PMIC_POWER_KEYPAD_I2C, 0, PMIC_POWER_VOLTAGE_ENABLE);
    } else {
        pmic_voltage_set(PMIC_POWER_KEYPAD_I2C, 0, PMIC_POWER_VOLTAGE_DISABLE);
    }

    return 0;
}

static int aw9523_hw_reset(void)
{
    int retval;

    pr_info("*******aw9523_hw_reset start **********\n");

    if (gpio_is_valid(AW9523_KEY_RST)) {
        /* configure aw9523 reset out gpio */
        retval = gpio_request(AW9523_KEY_RST,
                              "aw9523_reset_gpio");
        if (retval) {
            pr_err("%s: unable to request gpio [%d]\n", __func__, retval);
            return -1;
        }

        retval = gpio_direction_output(AW9523_KEY_RST, 1);
        if (retval) {
            pr_err("%s: unable to set dir request gpio [%d]\n", __func__, retval);
            return -1;
        }
    }

    /*chip reset by reset_gpio from low to high*/
    retval = gpio_direction_output(AW9523_KEY_RST, 0);
    udelay(50);
    retval = gpio_direction_output(AW9523_KEY_RST, 1);
    udelay(20);

    pr_info("*******aw9523_hw_reset end **********\n");
    return 0;
}

static int aw9523_irq_init(void)
{
    int retval;

    pr_info("*******aw9523_irq_init start**********\n");

    if (gpio_is_valid(AW9523_KEY_INT)) {
        /* configure aw9523 reset out gpio */
        retval = gpio_request(AW9523_KEY_INT,
                              "aw9523_irq_gpio");
        if (retval) {
            pr_err("%s: unable to irq gpio [%d]\n", __func__, retval);
            return -1;
        }

        retval = gpio_direction_input(AW9523_KEY_INT);
        if (retval) {
            pr_err("%s: unable to set dir irq gpio [%d]\n", __func__, retval);
            return -1;
        }
    }

    pr_info("*******aw9523_irq_init end **********\n");
    return 0;
}

static struct aw9523_platform_data pdata_9523 = {
    .irq_gpio = gpio_to_irq(AW9523_KEY_INT),
    .reset_gpio = AW9523_KEY_RST,
    .led_ctl    = RLED_CTL1_PIN,
    .pdata = &led_pdata,
    .num_leds = ARRAY_SIZE(led_pdata),
    .max_current = 0,
    .hw_reset = aw9523_hw_reset,
    .irq_init = aw9523_irq_init,
    .i2c_power = aw9523_i2c_power,
};
#endif

static struct i2c_board_info comip_i2c0_board_info[] = {
    // TODO:  to be continue for device
#if defined(CONFIG_BATTERY_BQ27421)
    {
        I2C_BOARD_INFO("bq27421-battery", 0x55),
        .platform_data = &fg_data,
        .irq = mfp_to_gpio(MAX17058_FG_INT_PIN),
    },
#endif
#if defined (CONFIG_CW201X_BATTERY)
    {
        I2C_BOARD_INFO("cw201x", 0x62),
        .platform_data = &fg_data,
    },
#endif

#if defined(CONFIG_FM23_DSP)
    {
        I2C_BOARD_INFO("fm23-dsp", 0x60),
        .platform_data = &fm23_data,
    },
#endif

#if defined(CONFIG_GPIO_PCA953X)
    {
        .type = "tca6424",
        .addr = 0x22,//0x22: when ADDR=GND; 0x23 when ADDR=VDD
        .platform_data = &tca6424a_expander_0_pdata,
    },
#if 0
    {
        .type = "tca6424",
        .addr = 0x23,//0x22: when ADDR=GND; 0x23 when ADDR=VDD
        .platform_data = &tca6424a_expander_1_pdata,
    },
#endif
#endif

#ifdef CONFIG_TYPE_C_DET_PI5USB30216A
    {
        I2C_BOARD_INFO("pi5usb30216a", 0x1D),
        .platform_data = &pericom_pdata,
    },
#endif

#ifdef CONFIG_POWER_DAC_AD5321
    {
        I2C_BOARD_INFO("ad5321", 0x0c),
        .platform_data = &ad5321_pdata,
    },
#endif

#ifdef CONFIG_POWER_DAC_AD5693
    {
        I2C_BOARD_INFO("ad5693", 0x4C),
    },
#endif

//IR LED
#ifdef CONFIG_LEDS_LM3642
    {
        .type = "lm3642",
        .addr = 0x63,
        .platform_data = &lm3642_data,
    },
#endif

//flashlight
#ifdef CONFIG_LEDS_LM3646
    {
        .type = "lm3646",
        .addr = 0x67,
//   .platform_data = &lm3646_data,
    },
#endif

#ifdef CONFIG_VIBR_DRV2625
    {
        .type = DRV2625_DEV_NAME,
        .addr = 0x5A,
        .platform_data = &drv2625_pdata,
    },
#endif
};

/* Sensors. */
static struct i2c_board_info comip_i2c1_board_info[] = {
#ifdef CONFIG_SENSORS_BOSCH_BME280
    {
        I2C_BOARD_INFO("bme280", 0x76),
    },
#endif
#ifdef CONFIG_SENSORS_HSCDTD007A
    {
        I2C_BOARD_INFO("hscdtd007a", 0x0c),
    },
#endif
#ifdef CONFIG_SENSORS_LSM330
    {
        I2C_BOARD_INFO("lsm330_acc", 0x1E),
        .platform_data = &lsm330_acc_data,
    },
    {
        I2C_BOARD_INFO("lsm330_gyr", 0x6A),
        .platform_data = &lsm330_gyr_data,
    },
#endif
#if defined(CONFIG_SENSORS_AK09911)
    {
        .type = "akm09911",
        .addr = 0x0d,
        .platform_data = &akm09911_pdata,
    },
#endif
#if defined(CONFIG_SENSORS_YAS_MAGNETOMETER)
    {
        I2C_BOARD_INFO("yas_magnetometer", 0x2e),
    },
#endif

#ifdef CONFIG_LIGHT_PROXIMITY_STK3X1X
    {
        I2C_BOARD_INFO("stk_ps", 0x48),
        .platform_data = &stk3x1x_data,
    },
#endif
#ifdef CONFIG_LIGHT_PROXIMITY_LTR55XALS
    {
        I2C_BOARD_INFO("ltr55xals", 0x23),
        .platform_data = &ltr55x_pdata,
    },
#endif
#if defined (CONFIG_SENSORS_INV_MPU6880)
    {
        I2C_BOARD_INFO("mpu6880", 0x68),
        .irq = mfp_to_gpio(INV6880_INT_PIN),
        .platform_data = &mpu_gyro_data,
    },

#endif

#if 0
#if defined(CONFIG_GPIO_PCA953X)
    {
        .type = "tca6424",
        .addr = 0x22,//0x22: when ADDR=GND; 0x23 when ADDR=VDD
        .platform_data = &tca6424a_expander_2_pdata,
    },
    {
        .type = "tca6424",
        .addr = 0x23,//0x22: when ADDR=GND; 0x23 when ADDR=VDD
        .platform_data = &tca6424a_expander_3_pdata,
    },
#endif
#endif

    /*BMI055 = BMA2X2 + BMG160*/
#if defined (CONFIG_SENSORS_BMI055)
    {
        I2C_BOARD_INFO("bma2x2", 0x18),
        .irq = gpio_to_irq(BMI055_INT1_ACC),
        .platform_data = &bmi055_pdata,
    },

    {
        I2C_BOARD_INFO("bmg160", 0x68),
        .platform_data = &bmi055_pdata,
    },
#endif

#if defined (CONFIG_SENSORS_IST8303)
#if 1
    {
        I2C_BOARD_INFO(IST8303_I2C_NAME, 0x0C),
        .platform_data = &ist8303_pdata,
    },
#else
    {
        I2C_BOARD_INFO(IST8303_I2C_NAME, 0x0F),
        .platform_data = &ist8303_pdata,
    },
#endif
#endif
#if defined (CONFIG_ADC3001_CHIP)
    {
        I2C_BOARD_INFO("adc3001", 0x18),
        .platform_data = &adc3001_pdata,
    },
#endif
};

#if defined(CONFIG_BATTERY_BQ27510)
struct comip_fuelgauge_info bq27510_data = {
    .normal_capacity = 1650,
    .firmware_version = 0x16000a4,
};
#endif

#if defined(CONFIG_BATTERY_BQ27510_G3)
struct comip_fuelgauge_info bq27510_g3_data = {
    .normal_capacity = 2000,
    .firmware_version = 0x16000a4,
};
#endif

#if defined(CONFIG_BATTERY_BQ34Z100)
struct comip_fuelgauge_info bq34z100_data = {
    .normal_capacity = 4000,
    .firmware_version = 0x1070017,
};
#endif

/* TouchScreen. */
static struct i2c_board_info comip_i2c2_board_info[] = {
    // TODO:  to be continue for device
#if defined(CONFIG_TOUCHSCREEN_FT5X06)
    {
        .type = "ft5x06",
        .addr = 0x38,
        .platform_data = &comip_i2c_ft5x06_info,
    },
#endif

#if defined(CONFIG_TOUCHSCREEN_CYPRESS_CYTTSP5)
    {
        I2C_BOARD_INFO(CYTTSP5_I2C_NAME, CYTTSP5_I2C_TCH_ADR),
        .irq =  (CYTTSP5_INT_PIN),
        .platform_data = CYTTSP5_I2C_NAME,
    },
#endif

#if defined(CONFIG_TOUCHSCREEN_S3402)
    {
        .type = S3402_TS_I2C_NAME,
        .addr = 0x20,
        .irq  = gpio_to_irq(S3402_INT_PIN),
        .platform_data = &comip_i2c_s3402_info,
    },
#endif

#if defined(CONFIG_TOUCHSCREEN_GT9XX)
    {
        .type = "Goodix-TS",
        .addr = 0x14,
    },
#endif

#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_MINI) || defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
    {
        .type = AW9523_DEV_NAME,
        .addr = 0x5B,
        .platform_data = &pdata_9523,
    },
#endif
};

#if (defined(CONFIG_COMIP_APB_I2C3))
static struct i2c_board_info comip_i2c3_board_info[] = {

//Do Not add comip-camera infomation here! The comip-camera uses its own register routine

};
#endif

/* PMU&CODEC. */
static struct i2c_board_info comip_i2c4_board_info[] = {
    // TODO:  to be continue for device
#if defined(CONFIG_COMIP_LC1160)
    {
        .type = "lc1160",
        .addr = 0x33,
        .platform_data = &i2c_lc1160_info,
    },
#endif

#if defined(CONFIG_CHARGER_BQ24158)
    {
        I2C_BOARD_INFO("fan5405", 0x6a),
        .platform_data = &exchg_data,
        .irq = mfp_to_gpio(EXTERN_CHARGER_INT_PIN),
    },
#endif

#if defined(CONFIG_CHARGER_BQ24161)
    {
        I2C_BOARD_INFO("bq24161", 0x6b),
        .platform_data = &exchg_data_bq24161,
        .irq = mfp_to_gpio(EXTERN_CHG_INT2DBB_PIN),
    },
#endif
#if defined(CONFIG_CHARGER_BQ24773)
    {
        I2C_BOARD_INFO("bq24773", 0x6a),
        .platform_data = &exchg_data_bq24773,
        .irq = mfp_to_gpio(CHG2DBB_ACOK_PIN),

    },
#endif


#if defined(CONFIG_BATTERY_BQ27510_G3)
    {
        I2C_BOARD_INFO("bq27510_g3-battery", 0x55),
        .platform_data = &bq27510_g3_data,
        .irq = mfp_to_gpio(BQ27510_G3_FG_INT_PIN),
    },
#endif

#if defined(CONFIG_BATTERY_BQ34Z100)
    {
        I2C_BOARD_INFO("bq34z100-battery", 0x55),
        .platform_data = &bq34z100_data,
    },
#endif

#if defined(CONFIG_BATTERY_MAX17058)
    {
        I2C_BOARD_INFO("max17058-battery", 0x36),
        .platform_data = &fg_data,
        .irq = mfp_to_gpio(MAX17058_FG_INT_PIN),
    },
#endif

#if defined(CONFIG_BATTERY_BQ27510)
    {
        I2C_BOARD_INFO("bq27510-battery", 0x55),
        .platform_data = &bq27510_data,
        .irq = mfp_to_gpio(BQ27510_GASGAUGE_INT_PIN),
    },
#endif

#if defined(CONFIG_LEDS_AW2013)
    {
        .type = "aw2013",
        .addr = 0x45,
    },
#endif
};

/* NFC. */
static struct comip_i2c_platform_data comip_i2c0_info = {
    .use_pio = 1,
    .flags = COMIP_I2C_FAST_MODE,
};

/* Sensors. */
static struct comip_i2c_platform_data comip_i2c1_info = {
    .use_pio = 1,
    .flags = COMIP_I2C_FAST_MODE,
};

/* TouchScreen. */
static struct comip_i2c_platform_data comip_i2c2_info = {
    .use_pio = 1,
    .flags = COMIP_I2C_FAST_MODE,
};

#if (defined(CONFIG_COMIP_APB_I2C3))
static struct comip_i2c_platform_data comip_i2c3_info = {
    .use_pio = 1,
    .flags = COMIP_I2C_FAST_MODE,
};
#endif

/* PMU&CODEC. */
static struct comip_i2c_platform_data comip_i2c4_info = {
    .use_pio = 1,
    .flags = COMIP_I2C_STANDARD_MODE,
};

static void __init comip_init_i2c(void)
{
    int index = 0;
    struct pmic_power_ctrl_map *power_ctrl_map_item = NULL;
    if (cpu_is_lc1860_eco1() == 3) {
        printk("comip_init_i2c cpu_is_lc1860_eco1\n");
        for (index = 0; index < sizeof(lc1160_power_ctrl_map) / sizeof(lc1160_power_ctrl_map[0]); index++) {

            power_ctrl_map_item = &lc1160_power_ctrl_map[index];

            if (power_ctrl_map_item->power_id == PMIC_ALDO12) {
                power_ctrl_map_item->default_mv = 1550;
                printk("lc1860_eco1:PMIC_ALDO12 default_mv=1550 \n");
                break;
            }
        }
    }

    comip_set_i2c0_info(&comip_i2c0_info);
    comip_set_i2c1_info(&comip_i2c1_info);
    comip_set_i2c2_info(&comip_i2c2_info);
#if (defined(CONFIG_COMIP_APB_I2C3))
    comip_set_i2c3_info(&comip_i2c3_info);
#endif
    comip_set_i2c4_info(&comip_i2c4_info);
    i2c_register_board_info(0, comip_i2c0_board_info, ARRAY_SIZE(comip_i2c0_board_info));
    i2c_register_board_info(1, comip_i2c1_board_info, ARRAY_SIZE(comip_i2c1_board_info));
    i2c_register_board_info(2, comip_i2c2_board_info, ARRAY_SIZE(comip_i2c2_board_info));
#if (defined(CONFIG_COMIP_APB_I2C3))
    i2c_register_board_info(3, comip_i2c3_board_info, ARRAY_SIZE(comip_i2c3_board_info));
#endif
    i2c_register_board_info(4, comip_i2c4_board_info, ARRAY_SIZE(comip_i2c4_board_info));

}
#else
static inline void comip_init_i2c(void)
{
}
#endif

static int comip_lcd_detect_dev(void)
{
#if defined(CONFIG_LCD_BOE_RM67120)//yasin: M+ PHONE
    return LCD_ID_BOE_RM67120;
#elif defined(CONFIG_LCD_BOE_RM67160)//yasin: M+ mini
    return LCD_ID_BOE_RM67160;
#elif defined(CONFIG_LCD_GVO_GDS8102)//yasin:
    return LCD_ID_GVO_GDS8102;
#elif defined(CONFIG_LCD_TS_TS8080Y)//yasin: M+ PAD
    return LCD_ID_TS_TS8080Y;
#else
    printk(KERN_ERR "comip_lcd_detect_dev failed\n");
    WARN_ON(1);
    return -1;
#endif
}

static int comip_lcd_power(int onoff)
{
    if (onoff) {
        pmic_voltage_set(PMIC_POWER_LCD_CORE, 0, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_LCD_IO, 0, PMIC_POWER_VOLTAGE_ENABLE);
    } else {
        pmic_voltage_set(PMIC_POWER_LCD_CORE, 0, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_LCD_IO, 0, PMIC_POWER_VOLTAGE_DISABLE);
    }

    return 0;
}

#if defined(CONFIG_FB_COMIP2) || defined(CONFIG_FB_COMIP2_MODULE)
static struct comipfb_platform_data comip_lcd_info = {
    .lcdcaxi_clk = 312000000,
    .lcdc_support_interface = COMIPFB_MIPI_IF,
    .phy_ref_freq = 26000,  /* KHz */
    .gpio_rst = LCD_RESET_PIN,
    .gpio_im = -1,
    .flags = COMIPFB_SLEEP_POWEROFF,
    .power = comip_lcd_power,
    .bl_control = comip_lcd_bl_control,
    .detect_dev = comip_lcd_detect_dev,

};
static void __init comip_init_lcd(void)
{
    comip_set_fb_info(&comip_lcd_info);//yasin
}
#else
static void inline comip_init_lcd(void)
{
}
#endif

//#if defined(CONFIG_COMIP_MODEM_RFSW)
#if defined(CONFIG_COMIP_BOARD_MPLUS_V2_PLUS)
static struct resource comip_resource_modem_rfsw[] = {
    [0] = {
        .start = SWITCH_ZZW_LTE_V1,
        .end =   SWITCH_ZZW_LTE_V1,
        .flags = IORESOURCE_IO,
    },
    [1] = {
        .start = SWITCH_ZZW_LTE_V2,
        .end =  SWITCH_ZZW_LTE_V2,
        .flags = IORESOURCE_IO,
    },
    [2] = {
        .start = SWITCH_ZZW_LTE_V3,
        .end =   SWITCH_ZZW_LTE_V3,
        .flags = IORESOURCE_IO,
    },
    [3] = {
        .start = SWITCH_MAIN_V1,
        .end =   SWITCH_MAIN_V1,
        .flags = IORESOURCE_IO,
    },
    [4] = {
        .start = SWITCH_MAIN_V2,
        .end =   SWITCH_MAIN_V2,
        .flags = IORESOURCE_IO,
    },
    [5] = {
        .start = SWITCH_MAIN_V3,
        .end =   SWITCH_MAIN_V3,
        .flags = IORESOURCE_IO,
    },
};
static struct platform_device comip_device_modem_rfsw = {
    .name           = "comip-modem-rfsw",
    .id             =  -1,
    .num_resources  = ARRAY_SIZE(comip_resource_modem_rfsw),
    .resource       = comip_resource_modem_rfsw,
};

#endif
#if defined(CONFIG_VIDEO_COMIP)
#if defined(CONFIG_VIDEO_S5K3H2)
static int s5k3h2_pwdn = mfp_to_gpio(S5K3H2_POWERDOWN_PIN);
static int s5k3h2_rst = mfp_to_gpio(S5K3H2_RESET_PIN);
static int s5k3h2_power(int onoff)
{
    printk("s5k3h2 power : %d\n", onoff);
    gpio_request(s5k3h2_pwdn, "S5K3H2 Powerdown");
    gpio_request(s5k3h2_rst, "s5k3h2 Reset");

    if (onoff) {
        gpio_direction_output(s5k3h2_pwdn, 0);
        gpio_direction_output(s5k3h2_rst, 0);
        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, 1200);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_AF_MOTOR, 0, PMIC_POWER_VOLTAGE_ENABLE);
        gpio_direction_output(s5k3h2_pwdn, 1);
        gpio_direction_output(s5k3h2_rst, 1);

        mdelay(10);
        gpio_direction_output(s5k3h2_rst, 0);
        gpio_direction_output(s5k3h2_pwdn, 0);
        mdelay(10);
        gpio_direction_output(s5k3h2_pwdn, 1);
        gpio_direction_output(s5k3h2_rst, 1);
    } else {
        gpio_direction_output(s5k3h2_pwdn, 0);
        gpio_direction_output(s5k3h2_rst, 0);

        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_DISABLE);
        //pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_AF_MOTOR, 0, PMIC_POWER_VOLTAGE_DISABLE);
    }
    gpio_free(s5k3h2_pwdn);
    gpio_free(s5k3h2_rst);
    return 0;
}

static int s5k3h2_reset(void)
{
    printk("s5k3h2 reset\n");
    return 0;
}

static struct i2c_board_info s5k3h2_board_info = {
    .type = "s5k3h2-mipi-raw",
    .addr = 0x10,
    //.platform_data = &s5k3h2_setting,
};
#endif

#if defined(CONFIG_VIDEO_OV13850)
static int ov13850_pwdn = mfp_to_gpio(OV13850_POWERDOWN_PIN);
static int ov13850_rst = mfp_to_gpio(OV13850_RESET_PIN);
static int ov13850_mclk = mfp_to_gpio(OV13850_MCLK_PIN);

static int ov13850_power(int onoff)
{
    static int ov13850_power_core;
    printk(" ov13850 power : %d\n", onoff);

    comip_mfp_config(MFP_PIN_GPIO(176), MFP_PIN_MODE_GPIO);
    ov13850_power_core = mfp_to_gpio(176);

    gpio_request(ov13850_pwdn, "OV13850 Powerdown");
    gpio_request(ov13850_power_core, "OV13850 power_core");
    gpio_request(ov13850_rst, "OV13850 Reset");

    if (onoff) {
        gpio_direction_output(ov13850_pwdn, 0);
        gpio_direction_output(ov13850_power_core, 0);
        gpio_direction_output(ov13850_rst, 1);

        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, 1200);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_AF_MOTOR, 0, PMIC_POWER_VOLTAGE_ENABLE);

        gpio_direction_output(ov13850_power_core, 1);
        mdelay(10);
        gpio_direction_output(ov13850_pwdn, 1);//OV13850 different from OV5647
        gpio_direction_output(ov13850_rst, 0);
        mdelay(50);
        gpio_direction_output(ov13850_rst, 1);
        comip_mfp_config_ds(ov13850_mclk, MFP_DS_2MA);
    } else {
        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_AF_MOTOR, 0, PMIC_POWER_VOLTAGE_DISABLE);

        gpio_direction_output(ov13850_pwdn, 0);
        gpio_direction_output(ov13850_power_core, 0);
        gpio_direction_output(ov13850_rst, 0);
    }
    gpio_free(ov13850_pwdn);
    gpio_free(ov13850_power_core);
    gpio_free(ov13850_rst);

    return 0;
}

static int ov13850_reset(void)
{
    printk("ov13850 reset\n");

    return 0;
}

static struct comip_camera_subdev_platform_data ov13850_setting = {
    .flags = CAMERA_SUBDEV_FLAG_MIRROR | CAMERA_SUBDEV_FLAG_FLIP,
};

static struct i2c_board_info ov13850_board_info = {
    .type = "ov13850-mipi-raw",
    .addr = 0x10,//.addr = 0x21,
    .platform_data = &ov13850_setting,
};
#endif


#if defined(CONFIG_VIDEO_OV8865)
static int ov8865_pwdn = mfp_to_gpio(OV8865_POWERDOWN_PIN);
static int ov8865_rst = mfp_to_gpio(OV8865_RESET_PIN);
static int ov8865_mclk = mfp_to_gpio(OV8865_MCLK_PIN);
static int ov8865_power(int onoff)
{
    printk("ov8865 power : %d\n", onoff);

    gpio_request(ov8865_pwdn, "OV8865 Powerdown");
    gpio_request(ov8865_rst, "OV8865 Reset");
    if (onoff) {
        gpio_direction_output(ov8865_pwdn, 0);
        gpio_direction_output(ov8865_rst, 1);
        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, 1200);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_AF_MOTOR, 0, PMIC_POWER_VOLTAGE_ENABLE);


        gpio_direction_output(ov8865_pwdn, 1);//OV8865 different from OV5647
        mdelay(1);
        gpio_direction_output(ov8865_rst, 0);
        mdelay(1);
        gpio_direction_output(ov8865_rst, 1);
        comip_mfp_config_ds(ov8865_mclk, MFP_DS_2MA);
    } else {

        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_DISABLE);
        //pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_AF_MOTOR, 0, PMIC_POWER_VOLTAGE_DISABLE);


        gpio_direction_output(ov8865_pwdn, 0);
        gpio_direction_output(ov8865_rst, 0);
    }
    gpio_free(ov8865_pwdn);
    gpio_free(ov8865_rst);

    return 0;
}

static int ov8865_reset(void)
{
    printk("ov8865 reset\n");

    return 0;
}

static struct i2c_board_info ov8865_board_info = {
    .type = "ov8865-mipi-raw",
    .addr = 0x10,
};
#endif

#if defined(CONFIG_VIDEO_OV9760)
static int ov9760_pwdn = mfp_to_gpio(OV9760_POWERDOWN_PIN);
static int ov9760_rst = mfp_to_gpio(OV9760_RESET_PIN);

static int ov9760_power(int onoff)
{
    printk("ov9760 power : %d\n", onoff);

    gpio_request(ov9760_pwdn, "OV9760 Powerdown");
    gpio_request(ov9760_rst, "OV9760 Reset");

    if (onoff) {
        gpio_direction_output(ov9760_pwdn, 0);
        gpio_direction_output(ov9760_rst, 1);

        pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, 1500);

        mdelay(10);
        gpio_direction_output(ov9760_pwdn, 1);
        gpio_direction_output(ov9760_rst, 0);
        mdelay(10);
        gpio_direction_output(ov9760_rst, 1);
    } else {
        //pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, PMIC_POWER_VOLTAGE_DISABLE);

        gpio_direction_output(ov9760_pwdn, 0);
        gpio_direction_output(ov9760_rst, 0);
    }

    gpio_free(ov9760_pwdn);
    gpio_free(ov9760_rst);

    return 0;
}

static int ov9760_reset(void)
{
    printk("ov9760 reset\n");
    return 0;
}

static struct i2c_board_info ov9760_board_info = {
    .type = "ov9760-mipi-raw",
    .addr = 0x20,
};
static struct i2c_board_info ov9760_board_info1 = {
    .type = "ov9760-mipi-raw",
    .addr = 0x36,
#endif

#if defined(CONFIG_VIDEO_OV5648_2LANE_19M)
static int ov5648_pwdn = mfp_to_gpio(OV5648_POWERDOWN_PIN);
static int ov5648_rst = mfp_to_gpio(OV5648_RESET_PIN);
static int ov5648_power(int onoff)
{
    printk("ov5648 power : %d\n", onoff);

    gpio_request(ov5648_pwdn, "OV5648 Powerdown");
    gpio_request(ov5648_rst, "OV5648 Reset");
    if (onoff)
    {
        gpio_direction_output(ov5648_pwdn, 0);
        gpio_direction_output(ov5648_rst, 1);
        pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_ENABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, PMIC_POWER_VOLTAGE_ENABLE);
        mdelay(10);
        gpio_direction_output(ov5648_pwdn, 1);//OV5648 different from OV5647
        gpio_direction_output(ov5648_rst, 0);
        msleep(50);
        gpio_direction_output(ov5648_rst, 1);
    } else {
        pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_DISABLE);
        pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, PMIC_POWER_VOLTAGE_DISABLE);

        gpio_direction_output(ov5648_pwdn, 0);
        gpio_direction_output(ov5648_rst, 0);
    }
    gpio_free(ov5648_pwdn);
    gpio_free(ov5648_rst);

    return 0;
}

    static int ov5648_reset(void) {
        printk("ov5648 reset\n");
        return 0;
    }

    static struct comip_camera_subdev_platform_data ov5648_setting =
    {
        .flags = CAMERA_SUBDEV_FLAG_FLIP,
    };

    static struct i2c_board_info ov5648_board_info = {
        .type = "ov5648-mipi-raw",
        .addr = 0x36,//.addr = 0x6c,
//#if defined(CONFIG_COMIP_BOARD_LC1860_EVB3) || defined(CONFIG_COMIP_BOARD_FOURMODE_V1_0)
        .platform_data = &ov5648_setting,
//#endif
    };
#endif

#if defined(CONFIG_VIDEO_OV2680)
    static int ov2680_pwdn = mfp_to_gpio(OV2680_POWERDOWN_PIN);
    static int ov2680_rst = mfp_to_gpio(OV2680_RESET_PIN);
    static int ov2680_mclk = mfp_to_gpio(OV2680_MCLK_PIN);
    static int ov2680_power(int onoff) {
        printk("ov2680 power : %d\n", onoff);

        gpio_request(ov2680_pwdn, "OV2680 Powerdown");
        gpio_request(ov2680_rst, "OV2680 Reset");

        if (onoff) {
            gpio_direction_output(ov2680_pwdn, 0);
            gpio_direction_output(ov2680_rst, 1);

            pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_ENABLE);
            pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_ENABLE);
            pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, 1500);

            mdelay(10);
            gpio_direction_output(ov2680_pwdn, 1);
            gpio_direction_output(ov2680_rst, 0);
            mdelay(10);
            gpio_direction_output(ov2680_rst, 1);
            comip_mfp_config_ds(ov2680_mclk, MFP_DS_2MA);
        } else {
            //pmic_voltage_set(PMIC_POWER_CAMERA_IO, 1, PMIC_POWER_VOLTAGE_DISABLE);
            pmic_voltage_set(PMIC_POWER_CAMERA_ANALOG, 1, PMIC_POWER_VOLTAGE_DISABLE);
            pmic_voltage_set(PMIC_POWER_CAMERA_CORE, 1, PMIC_POWER_VOLTAGE_DISABLE);

            gpio_direction_output(ov2680_pwdn, 0);
            gpio_direction_output(ov2680_rst, 0);
        }

        gpio_free(ov2680_pwdn);
        gpio_free(ov2680_rst);

        return 0;
    }

    static int ov2680_reset(void) {
        printk("ov2680 reset\n");
        return 0;
    }


    static struct i2c_board_info ov2680_board_info = {
        .type = "ov2680-mipi-raw",
        .addr = 0x20,
    };
    static struct i2c_board_info ov2680_board_info1 = {
        .type = "ov2680-mipi-raw",
        .addr = 0x36,
    };

#endif

#if defined(CONFIG_VIDEO_OCP8111)
    static int ocp8111_gpio_en = mfp_to_gpio(OCP8111_EN_PIN);
    static int ocp8111_gpio_mode = mfp_to_gpio(OCP8111_MODE_PIN);
    static unsigned char init_flag = 0;

    static int ocp8111_set(enum camera_led_mode mode, int onoff) {
        printk(KERN_DEBUG"%s: mode=%d, onoff=%d \n", __func__, mode, onoff);

        if (!init_flag) {
            gpio_request(ocp8111_gpio_en, "OCP8111 EN");
            gpio_request(ocp8111_gpio_mode, "OCP8111 MODE");
            gpio_direction_output(ocp8111_gpio_en, 0);
            gpio_direction_output(ocp8111_gpio_mode, 0);
            gpio_free(ocp8111_gpio_en);
            gpio_free(ocp8111_gpio_mode);
            init_flag = 1;
        }

        if (mode == FLASH) {
            gpio_request(ocp8111_gpio_en, "OCP8111 EN");
            gpio_request(ocp8111_gpio_mode, "OCP8111 MODE");
            if (onoff) {
                gpio_direction_output(ocp8111_gpio_mode, 1);
                gpio_direction_output(ocp8111_gpio_en, 1);
                mdelay(1);
            } else {
                gpio_direction_output(ocp8111_gpio_en, 0);
                gpio_direction_output(ocp8111_gpio_mode, 0);
            }
            gpio_free(ocp8111_gpio_en);
            gpio_free(ocp8111_gpio_mode);
        } else {
            gpio_request(ocp8111_gpio_en, "OCP8111 EN");
            gpio_request(ocp8111_gpio_mode, "OCP8111 MODE");
            if (onoff) {
                gpio_direction_output(ocp8111_gpio_mode, 0);
                gpio_direction_output(ocp8111_gpio_en, 1);
                //mdelay(200);
            } else {
                gpio_direction_output(ocp8111_gpio_en, 0);
                gpio_direction_output(ocp8111_gpio_mode, 0);
            }
            gpio_free(ocp8111_gpio_en);
            gpio_free(ocp8111_gpio_mode);
        }

        return 0;
    }

    static int camera_flash(enum camera_led_mode mode, int onoff) {
        return ocp8111_set(mode, onoff);
    }
#else
    static int camera_flash(enum camera_led_mode mode, int onoff) {
        return 0;
    }
#endif

    static struct comip_camera_client comip_camera_clients[] = {
#if defined(CONFIG_VIDEO_OV13850)
        {
            .board_info = &ov13850_board_info,
            .flags = CAMERA_CLIENT_IF_MIPI
            | CAMERA_CLIENT_CLK_EXT
            | CAMERA_CLIENT_ISP_CLK_HHIGH,
            .caps = CAMERA_CAP_FOCUS_INFINITY
            | CAMERA_CAP_FOCUS_AUTO
            | CAMERA_CAP_FOCUS_CONTINUOUS_AUTO
            | CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE
            | CAMERA_CAP_HDR_CAPTURE,
            .if_id = 0,
            .mipi_lane_num = 4,
            .mclk_parent_name = "pll1_mclk",
            .mclk_name = "clkout1_clk",
            .mclk_rate = 26000000,
            .power = ov13850_power,
            .reset = ov13850_reset,
            .flash = camera_flash,
        },
#endif

#if defined(CONFIG_VIDEO_S5K3H2)
        {
            .board_info = &s5k3h2_board_info,
            .flags = CAMERA_CLIENT_IF_MIPI
            | CAMERA_CLIENT_FRAMERATE_DYN
            | CAMERA_CLIENT_CLK_EXT
            | CAMERA_CLIENT_ISP_CLK_HIGH,
            .caps = CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE
            | CAMERA_CAP_HDR_CAPTURE
            | CAMERA_CAP_FLASH,
            .if_id = 0,
            .mipi_lane_num = 2,
            .camera_id = CAMERA_ID_BACK,
            .mclk_parent_name = "pll1_mclk",
            .mclk_name = "clkout1_clk",
            .mclk_rate = 26000000,
            .power = s5k3h2_power,
            .reset = s5k3h2_reset,
            .flash = camera_flash,
        },
#endif
#if defined(CONFIG_VIDEO_OV8865)
        {
            .board_info = &ov8865_board_info,
            .flags = CAMERA_CLIENT_IF_MIPI
            | CAMERA_CLIENT_FRAMERATE_DYN
            | CAMERA_CLIENT_CLK_EXT
            | CAMERA_CLIENT_ISP_CLK_HIGH,
            .caps = CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE
            | CAMERA_CAP_HDR_CAPTURE
            | CAMERA_CAP_FLASH,
            .if_id = 0,
            .mipi_lane_num = 4,
            .camera_id = CAMERA_ID_BACK,
            .mclk_parent_name = "pll1_mclk",
            .mclk_name = "clkout1_clk",
            .mclk_rate = 26000000,
            .power = ov8865_power,
            .reset = ov8865_reset,
            .flash = camera_flash,

        },
#endif

#if defined(CONFIG_VIDEO_OV9760)
        {
            .board_info = &ov9760_board_info,
            .flags = CAMERA_CLIENT_IF_MIPI,
            .caps = CAMERA_CAP_FOCUS_INFINITY
            | CAMERA_CAP_FOCUS_AUTO
            | CAMERA_CAP_FOCUS_CONTINUOUS_AUTO
            | CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE,
            .if_id = 1,
            .mipi_lane_num = 1,
            .camera_id = CAMERA_ID_FRONT,
            .power = ov9760_power,
            .reset = ov9760_reset,
        },
        {
            .board_info = &ov9760_board_info1,
            .flags = CAMERA_CLIENT_IF_MIPI,
            .caps = CAMERA_CAP_FOCUS_INFINITY
            | CAMERA_CAP_FOCUS_AUTO
            | CAMERA_CAP_FOCUS_CONTINUOUS_AUTO
            | CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE,
            .if_id = 1,
            .mipi_lane_num = 1,
            .camera_id = CAMERA_ID_FRONT,
            .power = ov9760_power,
            .reset = ov9760_reset,
        },
#endif

#if defined(CONFIG_VIDEO_OV5648_2LANE_19M)
        {
            .board_info = &ov5648_board_info,
//     .flags = CAMERA_CLIENT_IF_MIPI,
            .flags = CAMERA_CLIENT_IF_MIPI
            | CAMERA_CLIENT_FRAMERATE_DYN
            | CAMERA_CLIENT_ISP_CLK_MIDDLE,
            .caps = CAMERA_CAP_FOCUS_INFINITY
            | CAMERA_CAP_FOCUS_AUTO
            | CAMERA_CAP_FOCUS_CONTINUOUS_AUTO
            | CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE
            | CAMERA_CAP_HDR_CAPTURE,
            .if_id = 1,
            .mipi_lane_num = 2,
            .power = ov5648_power,
            .reset = ov5648_reset,
            .flash = camera_flash,
        },
#endif

#if defined(CONFIG_VIDEO_OV2680)
        {
            .board_info = &ov2680_board_info,
            .flags = CAMERA_CLIENT_IF_MIPI
            | CAMERA_CLIENT_FRAMERATE_DYN
            | CAMERA_CLIENT_ISP_CLK_MIDDLE,
            .caps = CAMERA_CAP_FOCUS_INFINITY
            | CAMERA_CAP_FOCUS_AUTO
            | CAMERA_CAP_FOCUS_CONTINUOUS_AUTO
            | CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE,
            .if_id = 1,
            .mipi_lane_num = 1,
            .camera_id = CAMERA_ID_FRONT,
            .power = ov2680_power,
            .reset = ov2680_reset,
        },
        {
            .board_info = &ov2680_board_info1,
            .flags = CAMERA_CLIENT_IF_MIPI
            | CAMERA_CLIENT_FRAMERATE_DYN
            | CAMERA_CLIENT_ISP_CLK_MIDDLE,
            .caps = CAMERA_CAP_FOCUS_INFINITY
            | CAMERA_CAP_FOCUS_AUTO
            | CAMERA_CAP_FOCUS_CONTINUOUS_AUTO
            | CAMERA_CAP_METER_CENTER
            | CAMERA_CAP_METER_DOT
            | CAMERA_CAP_FACE_DETECT
            | CAMERA_CAP_ANTI_SHAKE_CAPTURE,
            .if_id = 1,
            .mipi_lane_num = 1,
            .camera_id = CAMERA_ID_FRONT,
            .power = ov2680_power,
            .reset = ov2680_reset,
        },
#endif

    };

    static struct comip_camera_platform_data comip_camera_info = {
        .i2c_adapter_id = 3,
#if (defined(CONFIG_COMIP_APB_I2C3))
        .flags = CAMERA_USE_HIGH_BYTE
        | CAMERA_I2C_PIO_MODE | CAMERA_I2C_STANDARD_SPEED,
#else
        .flags = CAMERA_USE_ISP_I2C | CAMERA_USE_HIGH_BYTE
        | CAMERA_I2C_PIO_MODE | CAMERA_I2C_STANDARD_SPEED,
#endif

        .anti_shake_parms = {
            .a = 12,
            .b = 3,
            .c = 3,
            .d = 4,
        },
        .flash_parms = {
            .redeye_on_duration = 500,
            .redeye_off_duration = 100,
            .snapshot_pre_duration = 400,
            .aecgc_stable_duration = 1200,
            .torch_off_duration = 100,
            .flash_on_ramp_time = 150,
            .mean_percent = 50,
            .brightness_ratio = 32,
        },
        .mem_delayed_release = {
            .delayed_release_duration = 0, //10 minutes
            .memfree_threshold = 0,//40 MB
        },
        .client = comip_camera_clients,
        .client_num = ARRAY_SIZE(comip_camera_clients),
    };

    static void __init comip_init_camera(void) {
        comip_set_camera_info(&comip_camera_info);
    }
#else
static void inline comip_init_camera(void) {

}
#endif

    static void comip_init_misc(void) {
        pmic_voltage_set(PMIC_POWER_SDIO, 1, 3300);
#if defined(CONFIG_COMIP_MODEM_RFSW)
        comip_register_device(&comip_device_modem_rfsw, NULL);
#endif
    }

    static int comip_set_mmc0_info_ext(void) {
        return MMCF_UHS_I;
    }

    static int ear_switch(int enable) {
        int ear_switch_gpio = mfp_to_gpio(EAR_SWITCH_PIN);
        gpio_request(ear_switch_gpio, "ear switch");
        gpio_direction_output(ear_switch_gpio, enable);
        gpio_free(ear_switch_gpio);

        return 0;
    }


#if 0
    static int pa_boost_enable(int enable) {
        if (comip_board_info_get(NULL) > LTE26007M20) {
            int pa_extra_gpio = mfp_to_gpio(CODEC_PA_EXTRA_PIN);
            int pa_gpio = mfp_to_gpio(CODEC_PA_PIN);
            gpio_request(pa_extra_gpio, "codec_pa_extra_gpio");
            gpio_request(pa_gpio, "codec_pa_gpio");
            gpio_direction_output(pa_extra_gpio, enable);
            gpio_direction_output(pa_gpio, enable);
            gpio_free(pa_extra_gpio);
            gpio_free(pa_gpio);
        } else {
            int pa_gpio = mfp_to_gpio(CODEC_PA_PIN);
            gpio_request(pa_gpio, "codec_pa_gpio");
            gpio_direction_output(pa_gpio, enable);
            gpio_free(pa_gpio);
        }

        return 0;
    }
#endif

    static void comip_init_codec(void) {
        lc1160_codec_platform_data.ear_switch = ear_switch;
        //lc1160_codec_platform_data.pa_enable = pa_boost_enable;
    }

    int usb_power_set(int onoff) {
//usb hsic control
//#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
        /*reset USB4604.*/
        //printk(KERN_INFO "%s:hub_reset = %d\n", __func__, TCA6424A_0_P11);
        gpio_request(DBB2HSIC_RESET_N_PIN, "hub_reset");
        gpio_direction_output(DBB2HSIC_RESET_N_PIN, 1);
        mdelay(10);
        gpio_direction_output(DBB2HSIC_RESET_N_PIN, 0);
        mdelay(10);
        gpio_direction_output(DBB2HSIC_RESET_N_PIN, !!onoff);
        mdelay(10);
        gpio_free(DBB2HSIC_RESET_N_PIN);
//#endif

#ifdef CONFIG_COMIP_BOARD_MPLUS_PAD
        gpio_request(TCA6424A_2_P03, "usb2net");
        gpio_direction_output(TCA6424A_2_P03, !!onoff);
        gpio_free(TCA6424A_2_P03);
        /*reset USB4604.*/
        printk(KERN_INFO "%s:hub_reset = %d\n", __func__, TCA6424A_2_P11);
        gpio_request(TCA6424A_2_P11, "hub_reset");
        gpio_direction_output(TCA6424A_2_P11, 1);
        mdelay(10);
        gpio_direction_output(TCA6424A_2_P11, 0);
        mdelay(10);
        gpio_direction_output(TCA6424A_2_P11, !!onoff);
        mdelay(10);
        gpio_free(TCA6424A_2_P11);
#endif
        return 0;
    }
    static struct comip_usb_platform_data comip_usb_info = {
#ifdef CONFIG_USB_COMIP_OTG
        .otg = {
            .id_gpio = mfp_to_gpio(USB_OTG_ID_PIN),
            .pwr_gpio = mfp_to_gpio(DBB2VEX1_5V_EN_PIN),
            .id_gpio_ext1 = mfp_to_gpio(USBID_EX_CONN_PIN),
            .pwr_gpio_ext1 = mfp_to_gpio(DBB2VEX2_5V_EN_PIN),
            .id_gpio_ext2 = mfp_to_gpio(USBID_AER_CONN_PIN),
            .pwr_gpio_ext2 = mfp_to_gpio(DBB2EX_5V_EN_PIN),
            .debounce_interval = 50,
        },
#endif
        .hcd = {
            .usb_power_set = usb_power_set,
            .hub_power = -1,

#ifdef CONFIG_COMIP_BOARD_MPLUS_PHONE
            .hub_reset = TCA6424A_0_P11,
#endif
#ifdef CONFIG_COMIP_BOARD_MPLUS_PAD
            .hub_reset = TCA6424A_2_P11,
#endif
            .eth_power = -1,
            .eth_reset = -1,
        }
    };
    static void comip_muxpin_pvdd_config(void) {
        comip_pvdd_vol_ctrl_config(MUXPIN_PVDD4_VOL_CTRL, PVDDx_VOL_CTRL_1_8V);
    }

    static void audio_switch_gpio_config(void) {

        pr_err("%s() : Entry !\n", __func__);
        audio_switch_gpio.switch_eclk  = SWITCH_ECLK_PIN;
        audio_switch_gpio.switch1_gpio = SWITCH1_GPIO_PIN;
        audio_switch_gpio.switch2_gpio = SWITCH2_GPIO_PIN;
        audio_switch_gpio.switch3_gpio = SWITCH3_GPIO_PIN;
        audio_switch_gpio.switch4_gpio = SWITCH4_GPIO_PIN;
#ifdef CONFIG_COMIP_BOARD_MPLUS_V2_MINI
        audio_switch_gpio.switch5_gpio = SWITCH5_GPIO_PIN;
        audio_switch_gpio.switch5_enable = SWITCH5_ENABLE_PIN;
#endif
        audio_switch_gpio.analog_pa_gpio = ANALOG_PA_GPIO_PIN;
    }

    static void comip_init_gpio_request(void) {
        /* Power */
        //gpio_request(DBB2EX_5V_EN_PIN,      "DBB2EX_5V_EN_PIN");
        gpio_request(DBB2OTG_EN_PIN,        "DBB2OTG_EN_PIN");
        gpio_request(DBB2VTT4V_EN_PIN,      "DBB2VTT4V_EN_PIN");
        gpio_request(DBB2_BUCK3V3_EN_PIN,    "DBB2_BUCK3V3_EN_PIN");
        gpio_request(DBB2DAC_PWR_EN_PIN,     "DBB2DAC_PWR_EN_PIN");
        gpio_request(DBB2RF_PWRCTL1_PIN,     "DBB2RF_PWRCTL1_PIN");
        //gpio_request(DBB2VEX1_5V_EN_PIN,     "DBB2VEX1_5V_EN_PIN");
        //gpio_request(DBB2VEX2_5V_EN_PIN,     "DBB2VEX2_5V_EN_PIN");
        gpio_request(DBB2RF_SHIFT_EN_PIN,   "DBB2RF_SHIFT_EN_PIN");
        gpio_request(DBB2BDS_PP1S_EN_PIN,   "DBB2BDS_PP1S_EN_PIN");
        gpio_request(DBB2MINIPCIE_VBUS_PIN, "DBB2MINIPCIE_VBUS_PIN");
        gpio_request(DBB2BAT_TEMP_VOLT_SW_PIN, "bat_ctrl_sw");
#if defined(CONFIG_FAN_PWM)
        gpio_request(DBB2FAN_TACH_PIN,         "DBB2FAN_TACH_PIN");
#endif
    }

#ifdef CONFIG_TOUCHSCREEN_CYPRESS_CYTTSP5
    static void comip_init_cyttsp5(void) {
        struct kobject *properties_kobj;
        int ret = 0;

        /* Initialize muxes for GPIO pins */
        //omap_mux_init_gpio(CYTTSP5_I2C_RST_GPIO, OMAP_PIN_OUTPUT);
        //omap_mux_init_gpio(CYTTSP5_I2C_IRQ_GPIO, OMAP_PIN_INPUT_PULLUP);;

        /* Register core and devices */
        cyttsp5_register_core_device(&cyttsp5_core_info);
        cyttsp5_register_device(&cyttsp5_mt_info);
        cyttsp5_register_device(&cyttsp5_btn_info);
        cyttsp5_register_device(&cyttsp5_proximity_info);
    }
#endif

    static void __init comip_init_board_early(void) {
        hardware_get_board_info();
        comip_muxpin_pvdd_config();
        comip_init_mfp();
        comip_init_gpio_lp();
        comip_init_i2c();
#if defined(CONFIG_SPI_COMIP) || defined(CONFIG_SPI_COMIP_MODULE)
        comip_init_spi();
#endif
        comip_init_lcd();//yasin
#if defined(CONFIG_TOUCHSCREEN_CYPRESS_CYTTSP5)
        comip_init_cyttsp5();
#endif
        comip_init_codec();
        audio_switch_gpio_config();
        comip_init_gpio_request();
    }
    static void __init comip_init_board(void) {
        comip_set_usb_info(&comip_usb_info);
        comip_init_camera();
        comip_init_devices();
        comip_init_misc();
        comip_init_ts_virtual_key();

        comip_mmc0_info.setflags = comip_set_mmc0_info_ext;
    }

