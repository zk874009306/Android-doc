#ifndef __MPLUS_MODULES_H__
#define __MPLUS_MODULES_H__


struct module_gpio_info {
    int gpio;
    char *name;
};


struct dtt_modules {
    char *name;
    int (*power_on)(void);
    int (*power_off)(void);
    int (*boot_on)(void);
    int (*boot_off)(void);
    int (*debug_on)(void);
    int (*debug_off)(void);
    int (*reset)(void);
    int (*state)(void);
    struct module_gpio_info  *gpio;
    int gpio_num;
    char show_state[10];//default io status
};

struct dtt_modules_pkg {
    struct dtt_modules *dtt_modules_data;
    int mod_total_num;
};


struct dtt_module_platform_data {
    struct dtt_modules *modules;
    int  n_mods;
    char * name;
};

#endif
