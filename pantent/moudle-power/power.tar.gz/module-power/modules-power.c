/*
 * Driver for GPIO control dtt modules power on or off
 *
 * Copyright 2016 zhangkang@datang.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 *
 */


#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/platform_device.h>
#include <linux/sysctl.h>
#include <linux/proc_fs.h>
#include <linux/gpio.h>
#include <plat/mplus_modules.h>


struct dtt_modules *module_data;
int module_num;


static ssize_t module_power_show(struct kobject *kobj, struct kobj_attribute *attr, char * buf)
{
    int i;

    for (i = 0; i < module_num; i++) {
        if (!strcmp(kobj->name, module_data[i].name))
            return sprintf(buf, "%s\n", module_data[i].show_state);
    }

    return 0;
}

static ssize_t module_boot_show(struct kobject *kobj, struct kobj_attribute *attr, char * buf)
{
    int i;

    for (i = 0; i < module_num; i++) {
        if (!strcmp(kobj->name, module_data[i].name))
            return sprintf(buf, "%s\n", module_data[i].show_state);
    }

    return 0;
}

static ssize_t module_debug_show(struct kobject *kobj, struct kobj_attribute *attr, char * buf)
{
    int i;

    for (i = 0; i < module_num; i++) {
        if (!strcmp(kobj->name, module_data[i].name))
            return sprintf(buf, "%s\n", module_data[i].show_state);
    }

    return 0;
}

static ssize_t module_state_show(struct kobject *kobj, struct kobj_attribute *attr, char * buf)
{
    int i;

    for (i = 0; i < module_num; i++) {
        if (!strcmp(kobj->name, module_data[i].name)) {
            if(module_data[i].state() == 0){
                return sprintf(buf, "%s\n", "true");
            }else{
                return sprintf(buf, "%s\n", "false");
            }
        }
    }
    return 0;
}


static ssize_t module_power_store(struct kobject *kobj, struct kobj_attribute *attr, const char * buf, size_t n)
{
    char poweron[] =  "enable";
    char poweroff[] = "disable";
    int ret = 0, i = 0;

    if (!strncmp(poweron, buf, 6)) {
        ret = 1;
        printk("enable ok\n");
    }

    if (!strncmp(poweroff, buf, 7)) {
        ret = 0;
        printk("disable ok\n");
    }

    if (ret == 1) {

        for (i = 0; i < module_num; i++) {
            if (!strcmp(kobj->name, module_data[i].name)) {
                memset(module_data[i].show_state, 0 , sizeof(module_data[i].show_state));
                sprintf(module_data[i].show_state, "%s", poweron);
                module_data[i].power_on();
                printk("power on %s module OK\n", module_data[i].name);
            }
        }
    }

    if (ret == 0) {
        for (i = 0; i < module_num; i++) {
            if (!strcmp(kobj->name, module_data[i].name)) {
                memset(module_data[i].show_state, 0 , sizeof(module_data[i].show_state));
                sprintf(module_data[i].show_state, "%s", poweroff);
                module_data[i].power_off();
                printk("power off %s module OK\n", module_data[i].name);
            }
        }

    }
    printk("%s\n", kobj->name);

    return n;
}

static ssize_t module_boot_store(struct kobject *kobj, struct kobj_attribute *attr, const char * buf, size_t n)
{
    char booton[] =  "enable";
    char bootoff[] = "disable";
    int ret = 0, i = 0;

    if (!strncmp(booton, buf, 6)) {
        ret = 1;
        printk("enable ok\n");
    }

    if (!strncmp(bootoff, buf, 7)) {
        ret = 0;
        printk("disable ok\n");
    }

    if (ret == 1) {

        for (i = 0; i < module_num; i++) {
            if (!strcmp(kobj->name, module_data[i].name)) {
                memset(module_data[i].show_state, 0 , sizeof(module_data[i].show_state));
                sprintf(module_data[i].show_state, "%s", booton);
                module_data[i].boot_on();
                printk("power on %s module OK\n", module_data[i].name);
            }
        }
    }

    if (ret == 0) {
        for (i = 0; i < module_num; i++) {
            if (!strcmp(kobj->name, module_data[i].name)) {
                memset(module_data[i].show_state, 0 , sizeof(module_data[i].show_state));
                sprintf(module_data[i].show_state, "%s", bootoff);
                module_data[i].boot_off();
                printk("power off %s module OK\n", module_data[i].name);
            }
        }

    }
    printk("%s\n", kobj->name);

    return n;
}

static ssize_t module_debug_store(struct kobject *kobj, struct kobj_attribute *attr, const char * buf, size_t n)
{
    char debugon[] =  "enable";
    char debugoff[] = "disable";
    int ret = 0, i = 0;

    if (!strncmp(debugon, buf, 6)) {
        ret = 1;
        printk("enable ok\n");
    }

    if (!strncmp(debugoff, buf, 7)) {
        ret = 0;
        printk("disable ok\n");
    }

    if (ret == 1) {

        for (i = 0; i < module_num; i++) {
            if (!strcmp(kobj->name, module_data[i].name)) {
                memset(module_data[i].show_state, 0 , sizeof(module_data[i].show_state));
                sprintf(module_data[i].show_state, "%s", debugon);
                module_data[i].debug_on();
                printk("power on %s module OK\n", module_data[i].name);
            }
        }
    }

    if (ret == 0) {
        for (i = 0; i < module_num; i++) {
            if (!strcmp(kobj->name, module_data[i].name)) {
                memset(module_data[i].show_state, 0 , sizeof(module_data[i].show_state));
                sprintf(module_data[i].show_state, "%s", debugoff);
                module_data[i].debug_off();
                printk("power off %s module OK\n", module_data[i].name);
            }
        }

    }
    printk("%s\n", kobj->name);

    return n;
}

static ssize_t module_reset_store(struct kobject *kobj, struct kobj_attribute *attr, const char * buf, size_t n)
{
    char reset[] = "reset";
    int ret = 0 , i = 0;


    if (!strncmp(reset, buf, 5)) {
        ret = 1;
        printk("%s will be reset\n", kobj->name);
    } else {
        printk("%s input paramater is error\n", kobj->name);
        return n;
    }
    if (1 == ret) {
        for  (i = 0; i < module_num; i++) {
            if ((NULL != module_data[i].reset)  &&  (!strcmp(kobj->name, module_data[i].name))) {
                module_data[i].reset();
                printk("reset OK %s\n", kobj->name);
            }
        }
        return n;
    }
}

static ssize_t module_state_store(struct kobject *kobj, struct kobj_attribute *attr, const char * buf, size_t n)
{
    char state[] = "wakeup";
    int ret = 0, i = 0;

    if (!strncmp(state, buf, 6)) {
        ret = 1;
        printk("%s will be wakeup\n", kobj->name);
    } else {
        printk("%s input paramater is error\n", kobj->name);
        return n;
    }
    if (1 == ret) {
        for (i = 0; i < module_num; i++) {
            if ((NULL != module_data[i].state)  &&  (!strcmp(kobj->name, module_data[i].name))) {
                module_data[i].state();
                printk("wakeup OK %s\n", kobj->name);
            }
        }
        return n;
    }

}

static struct kobject *dtt_kobj = NULL;

static struct kobj_attribute module_attr[] = {
    __ATTR(power, 0666, module_power_show, module_power_store),
    __ATTR(reset, 0666, NULL, module_reset_store), // "reset"
    __ATTR(state, 0666, module_state_show, module_state_store), // "wakeup"
    __ATTR(boot, 0666,  module_boot_show, module_boot_store), //boot
    __ATTR(debug, 0666, module_debug_show, module_debug_store), //debug

};
static int module_gpio_init(struct module_gpio_info *gpio, int num)
{
    int i , retval;

    for (i = 0; i < num ; i++) {
        retval = gpio_request(gpio[i].gpio, gpio[i].name);
        if (retval < 0) {
            pr_err("%s gpio request rst error\n", gpio[i].name);
            return retval;
        }
    }
    return 0;
}

static int module_gpio_exit(struct module_gpio_info gpio[], int num)
{
    int i;
    for (i = 0; i < num ; i++) {
        gpio_free(gpio[i].gpio);
    }
    return 0;
}


static int __init module_sysfs_probe(struct platform_device *pdev)
{
    struct dtt_modules_pkg *pdata_pkg = pdev->dev.platform_data;
    struct dtt_modules *pdata = pdata_pkg->dtt_modules_data;
    struct dtt_modules *module;
    struct module_gpio_info *gpio_info;
    int gpio_num, ret, cur_module_num;
    int i = 0;
    struct kobject *mod_kobj = NULL;

    printk("module sysfs probe ok\n");
    module = &pdata[pdev->id];
    module_data = pdata;
    module_num = pdata_pkg->mod_total_num;
    cur_module_num = pdev->id;
    printk("all module_num = %d cur_mod_num+1 = %d\n", module_num, cur_module_num + 1);
    mod_kobj = kobject_create_and_add(module->name, dtt_kobj);
    if (mod_kobj == NULL) {
        printk(KERN_ERR " %s kobject_create_and_add failed.\n", module->name);
        return ret;
    }

    gpio_info = &module->gpio[0];
    gpio_num =  module->gpio_num;

    module_gpio_init(gpio_info, gpio_num);
    for (i = 0; i < ARRAY_SIZE(module_attr); i++) {
        ret =  sysfs_create_file(mod_kobj, &module_attr[i].attr);
        if (ret) {
            printk(KERN_ERR "sysfs_init: sysfs_create_file %s failed.\n", module->name);
            return ret;
        }
    }

    if (!strcmp(module_data[cur_module_num].show_state, "enable")) {
        module_data[cur_module_num].power_on();
        printk("default power on %s module OK\n", module_data[cur_module_num].name);
    } else {
        module_data[cur_module_num].power_off();
        printk("default power off %s module OK\n", module_data[cur_module_num].name);
    }

#if 0
    if (!strcmp(module_data[cur_module_num].name, "boot")) {
        module_data[cur_module_num].boot_off();
        printk("default power on %s module OK\n", module_data[cur_module_num].name);
    }

    if (!strcmp(module_data[cur_module_num].name, "debug")) {
        module_data[cur_module_num].boot_off();
        printk("default power on %s module OK\n", module_data[cur_module_num].name);
    }
#endif

    printk("module sysfs probe exit ok\n");

    return 0;
}


static int __exit module_sysfs_remove(struct platform_device *pdev)
{
    struct dtt_modules_pkg *pdata_pkg = pdev->dev.platform_data;
    struct dtt_modules *module = pdata_pkg->dtt_modules_data;

    struct module_gpio_info *gpio_info;
    int gpio_num;

    gpio_info = module->gpio;
    gpio_num =  module->gpio_num;

    module_gpio_exit(gpio_info, gpio_num);
    return 0;
}

static struct platform_driver modules_device_driver = {
    .remove     = __exit_p(module_sysfs_remove),
    .driver     = {
        .name   = "modules-sysfs",
        .owner  = THIS_MODULE,
    }
};

static int __init mplus_modules_init(void)
{
    int ret;
    dtt_kobj = kobject_create_and_add("dtt", NULL);
    if (dtt_kobj == NULL) {
        printk(KERN_ERR "dtt kobject_create_and_add failed.\n");
        return ret;
    }

    return platform_driver_probe(&modules_device_driver, module_sysfs_probe);
}

static void __exit mplus_modules_exit(void)
{
    platform_driver_unregister(&modules_device_driver);
}

module_init(mplus_modules_init);
module_exit(mplus_modules_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("zhangkang <zhangkang@datang.com>");
MODULE_DESCRIPTION("Modules power control driver for CPU GPIOs");
MODULE_ALIAS("platform:mplus-modules");
